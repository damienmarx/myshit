import sys
import json
import logging
import importlib
import readline
from typing import Dict, Any, List

class NightfuryFramework:
    def __init__(self):
        self.config = self.load_config()
        self.setup_logging()
        self.modules = {}
        self.current_module = None
        self.logger = logging.getLogger("NIGHTFURY")
        self.project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def load_config(self) -> Dict[str, Any]:
        config_path = 'nightfury_config.json'
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                try:
                    return json.load(f)
                except:
                    return {}
        return {}

    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[
                logging.FileHandler("nightfury.log"),
                logging.StreamHandler()
            ]
        )

    def log(self, message: str, level: str = "info"):
        getattr(self.logger, level.lower())(message)

    def load_modules(self):
        modules_path = os.path.join(self.project_root, 'modules')
        if not os.path.exists(modules_path):
            os.makedirs(modules_path)
            return

        if self.project_root not in sys.path:
            sys.path.append(self.project_root)

        for root, _, files in os.walk(modules_path):
            for file in files:
                if file.endswith('.py') and not file.startswith('__'):
                    rel_path = os.path.relpath(os.path.join(root, file), self.project_root)
                    module_path = rel_path.replace(os.path.sep, '.')[:-3]
                    try:
                        mod = importlib.import_module(module_path)
                        for name, obj in mod.__dict__.items():
                            if isinstance(obj, type) and name != 'BaseModule':
                                if any(base.__name__ == 'BaseModule' for base in obj.__bases__):
                                    module_instance = obj(self)
                                    m_name = getattr(module_instance, 'name', file[:-3])
                                    # Use category/name format like MSF
                                    category = os.path.basename(root)
                                    full_name = f"{category}/{m_name}"
                                    self.modules[full_name] = module_instance
                    except Exception as e:
                        self.log(f"Failed to load {module_path}: {e}", "error")

    def print_banner(self):
        banner = r"""
    ███╗   ██╗██╗ ██████╗ ██╗  ██╗████████╗███████╗██╗   ██╗██████╗ ██╗   ██╗
    ████╗  ██║██║██╔════╝ ██║  ██║╚══██╔══╝██╔════╝██║   ██║██╔══██╗╚██╗ ██╔╝
    ██╔██╗ ██║██║██║  ███╗███████║   ██║   █████╗  ██║   ██║██████╔╝ ╚████╔╝ 
    ██║╚██╗██║██║██║   ██║██╔══██║   ██║   ██╔══╝  ██║   ██║██╔══██╗  ╚██╔╝  
    ██║ ╚████║██║╚██████╔╝██║  ██║   ██║   ██║     ╚██████╔╝██║  ██║   ██║   
    ╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝      ╚═════╝ ╚═╝  ╚═╝   ╚═╝   
                                                                             
                         HYPERION - RUNEHALL EDITION                       
        """
        print("\033[1;35m" + banner + "\033[0m")
        print(f"       =[ Nightfury v10.1-RUNEHALL                     ]")
        print(f" + -- --=[ {len(self.modules)} specialized modules loaded             ]\n")

    def start_cli(self, args=None):
        self.load_modules()
        
        if args and len(args) > 0:
            self.handle_batch_mode(args)
            return

        self.print_banner()
        
        # Setup tab completion
        def completer(text, state):
            options = [cmd for cmd in ['help', 'use', 'set', 'show', 'run', 'exploit', 'back', 'exit', 'quit', 'list'] if cmd.startswith(text)]
            if self.current_module:
                options.extend([opt for opt in self.current_module.options if opt.startswith(text)])
            if text.startswith('exploit/') or text.startswith('recon/') or text.startswith('c2/'):
                options.extend([m for m in self.modules if m.startswith(text)])
            