        operation_name = self.operation_name_input.text() or "Unnamed Operation"
        target = self.target_input.text() or "localhost"
        operation_type = self.operation_type.currentText()
        
        self.data_collector.start_operation(operation_name, target, operation_type)
        
        self.log_message("INFO", f"Operation started: {operation_name}")
        self.log_message("INFO", f"Target: {target}")
        self.log_message("INFO", f"Type: {operation_type}")
        
        if self.ai_checkbox.isChecked() and self.gemini:
            self.log_message("INFO", "Gemini AI analysis enabled")
        
        self.statusBar.showMessage(f"Running: {operation_name}")
        
        # Simulate operation
        self.simulate_operation()
    
    def simulate_operation(self):
        """Simulate an operation with sample findings"""
        findings = [
            ("high", "SQL Injection in Login Form", "Vulnerable parameter detected in authentication endpoint", "payload: ' OR '1'='1"),
            ("high", "Authentication Bypass", "Session token validation flaw detected", "session_id parameter"),
            ("medium", "Insufficient Rate Limiting", "No rate limiting on API endpoints", "1000 requests/minute possible"),
            ("medium", "Weak Encryption", "Sensitive data transmitted over HTTP", "Payment information exposed"),
            ("low", "Information Disclosure", "Version information leaked in headers", "Server: Apache/2.4.41"),
            ("low", "Missing Security Headers", "HSTS and CSP headers not configured", "X-Frame-Options missing")
        ]
        
        for i, (severity, title, description, evidence) in enumerate(findings):
            self.data_collector.add_finding(severity, title, description, evidence)
            self.add_result_row(severity, title, description, evidence)
            self.progress_bar.setValue(int((i + 1) / len(findings) * 100))
        
        self.data_collector.end_operation("completed")
        self.statusBar.showMessage("Operation completed")
        self.log_message("INFO", "Operation completed successfully")
        self.update_statistics()
        
        # Run AI analysis if enabled
        if self.ai_checkbox.isChecked() and self.gemini:
            self.run_ai_analysis()
    
    def run_ai_analysis(self):
        """Run Gemini AI analysis on findings"""
        if not self.gemini or not self.data_collector.current_operation:
            return
        
        self.log_message("INFO", "Running Gemini AI analysis...")
        
        try:
            findings = self.data_collector.current_operation.get("findings", [])
            analysis = self.gemini.analyze_findings(findings)
            
            self.ai_analysis_text.setText(analysis)
            self.data_collector.current_operation["ai_analysis"] = analysis
            
            self.log_message("INFO", "Gemini AI analysis completed")
        except Exception as e:
            self.log_message("ERROR", f"AI analysis error: {str(e)}")
    
    def ai_analyze_findings(self):
        """Analyze findings with Gemini AI"""
        if not self.gemini or not self.data_collector.current_operation:
            QMessageBox.warning(self, "Error", "No operation data or Gemini AI not configured")
            return
        
        findings = self.data_collector.current_operation.get("findings", [])
        if not findings:
            QMessageBox.warning(self, "Error", "No findings to analyze")
            return
        
        self.log_message("INFO", "Requesting Gemini AI analysis...")
        
        try:
            analysis = self.gemini.analyze_findings(findings)
            self.ai_analysis_text.setText(analysis)
            self.log_message("INFO", "Analysis complete")
        except Exception as e:
            self.log_message("ERROR", f"Error: {str(e)}")
    
    def ai_generate_summary(self):
        """Generate executive summary with Gemini AI"""
        if not self.gemini or not self.data_collector.current_operation:
            QMessageBox.warning(self, "Error", "No operation data or Gemini AI not configured")
            return
        
        self.log_message("INFO", "Generating executive summary...")
        
        try:
            summary = self.gemini.generate_executive_summary(self.data_collector.current_operation)
            self.ai_analysis_text.setText(summary)
            self.log_message("INFO", "Summary generated")
        except Exception as e:
            self.log_message("ERROR", f"Error: {str(e)}")
    
    def ai_remediation(self):
        """Generate remediation steps with Gemini AI"""
        if not self.gemini or not self.data_collector.current_operation:
            QMessageBox.warning(self, "Error", "No operation data or Gemini AI not configured")
            return
        
        findings = self.data_collector.current_operation.get("findings", [])
        if not findings:
            QMessageBox.warning(self, "Error", "No findings")
            return
        
        self.log_message("INFO", "Generating remediation steps...")
        
        try:
            remediation = self.gemini.generate_remediation_steps(findings[0])
            self.ai_analysis_text.setText(remediation)
            self.log_message("INFO", "Remediation steps generated")
        except Exception as e:
            self.log_message("ERROR", f"Error: {str(e)}")
    
    def ai_threat_model(self):
        """Generate threat model with Gemini AI"""
        if not self.gemini:
            QMessageBox.warning(self, "Error", "Gemini AI not configured")
            return
        
        target = self.target_input.text() or "Unknown"
        
        self.log_message("INFO", "Generating threat model...")
        
        try:
            threat_model = self.gemini.generate_threat_model({
                "target": target,
                "type": self.operation_type.currentText()
            })
            self.ai_analysis_text.setText(threat_model)
            self.log_message("INFO", "Threat model generated")
        except Exception as e:
            self.log_message("ERROR", f"Error: {str(e)}")
    
    def ai_chat(self):
        """Chat with Gemini AI"""
        if not self.gemini:
            QMessageBox.warning(self, "Error", "Gemini AI not configured")
            return
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Chat with Gemini AI")
        dialog.setGeometry(200, 200, 600, 400)
        
        layout = QVBoxLayout()
        
        chat_display = QTextEdit()
        chat_display.setReadOnly(True)
        layout.addWidget(chat_display)
        
        input_field = QLineEdit()
        input_field.setPlaceholderText("Ask Gemini AI about security...")
        layout.addWidget(input_field)
        
        def send_message():
            message = input_field.text()
            if message:
                chat_display.append(f"You: {message}")
                response = self.gemini.chat(message)
                chat_display.append(f"Gemini: {response}\n")
                input_field.clear()
        
        send_button = QPushButton("Send")
        send_button.clicked.connect(send_message)
        layout.addWidget(send_button)
        
        dialog.setLayout(layout)
        dialog.exec_()
    
    def add_result_row(self, severity: str, title: str, description: str, evidence: str):
        """Add a result row to the table"""
        row_position = self.results_table.rowCount()
        self.results_table.insertRow(row_position)
        
        self.results_table.setItem(row_position, 0, QTableWidgetItem(datetime.now().strftime("%H:%M:%S")))
        self.results_table.setItem(row_position, 1, QTableWidgetItem(severity.upper()))
        self.results_table.setItem(row_position, 2, QTableWidgetItem(title))
        self.results_table.setItem(row_position, 3, QTableWidgetItem(description))
        self.results_table.setItem(row_position, 4, QTableWidgetItem(evidence))
        
        color_map = {
            "high": QColor(255, 107, 107),
            "medium": QColor(255, 165, 0),
            "low": QColor(78, 205, 196),
            "info": QColor(0, 102, 204)
        }
        
        for col in range(5):
            item = self.results_table.item(row_position, col)
            if item:
                item.setBackground(color_map.get(severity.lower(), QColor(255, 255, 255)))
    
    def log_message(self, level: str, message: str):
        """Add a log message"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}"
        self.logs_text.append(log_entry)
        
        if self.data_collector.current_operation:
            self.data_collector.add_log(level, message)
    
    def update_statistics(self):
        """Update statistics display"""
        if not self.data_collector.current_operation:
            return
        
        findings = self.data_collector.current_operation["findings"]
        
        high = len([f for f in findings if f["severity"] == "high"])
        medium = len([f for f in findings if f["severity"] == "medium"])
        low = len([f for f in findings if f["severity"] == "low"])
        
        self.total_findings_label.setText(str(len(findings)))
        self.high_severity_label.setText(str(high))
        self.medium_severity_label.setText(str(medium))
        self.low_severity_label.setText(str(low))
    
    def pause_operation(self):
        """Pause current operation"""
        self.statusBar.showMessage("Operation paused")
        self.log_message("INFO", "Operation paused")
    
    def stop_operation(self):
        """Stop current operation"""
        self.data_collector.end_operation("stopped")
        self.statusBar.showMessage("Operation stopped")
        self.log_message("INFO", "Operation stopped")
    
    def save_report(self):
        """Save current operation report"""
        filepath = self.data_collector.save_operation()
        self.log_message("INFO", f"Report saved to: {filepath}")
        QMessageBox.information(self, "Report Saved", f"Report saved to:\n{filepath}")
    
    def new_operation(self):
        """Start a new operation"""
        self.operation_name_input.clear()
        self.target_input.clear()
        self.results_table.setRowCount(0)
        self.logs_text.clear()
        self.ai_analysis_text.clear()
        self.progress_bar.setValue(0)
        self.statusBar.showMessage("Ready for new operation")
    
    def open_report(self):
        """Open a saved report"""
        filepath, _ = QFileDialog.getOpenFileName(self, "Open Report", "./nightfury_reports", "JSON Files (*.json)")
        if filepath:
            self.log_message("INFO", f"Opened report: {filepath}")
    
    def run_quick_recon(self):
        """Run quick reconnaissance"""
        self.operation_name_input.setText("Quick Reconnaissance")
        self.operation_type.setCurrentText("Reconnaissance")
        self.start_operation()
    
    def run_full_recon(self):
        """Run full reconnaissance"""
        self.operation_name_input.setText("Full Reconnaissance")
        self.operation_type.setCurrentText("Reconnaissance")
        self.start_operation()
    
    def run_exploitation(self):
        """Run exploitation"""
        self.operation_name_input.setText("Exploitation Test")
        self.operation_type.setCurrentText("Exploitation")
        self.start_operation()
    
    def run_advanced_chain(self):
        """Run advanced exploitation chain"""
        self.operation_name_input.setText("Advanced Exploitation Chain")
        self.operation_type.setCurrentText("Full Penetration Test")
        self.start_operation()
    
    def verify_installation(self):
        """Verify framework installation"""
        self.log_message("INFO", "Verifying installation...")
        QMessageBox.information(self, "Installation", "Run: python verify_installation.py")
    
    def show_settings(self):
        """Show settings dialog"""
        QMessageBox.information(self, "Settings", "Settings dialog coming soon")
    
    def show_documentation(self):
        """Show documentation"""
        QMessageBox.information(self, "Documentation", "See RUNEHALL_QUICK_REFERENCE.md and GEMINI_SETUP.md")
    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.information(self, "About", 
            "NightFury Framework v2.0 - Gemini AI Edition\n\n"
            "Advanced Penetration Testing Platform\n"
            "Powered by Google Gemini AI\n\n"
            "For authorized security testing only")
    
    def apply_stylesheet(self):
        """Apply custom stylesheet"""
        stylesheet = """
            QMainWindow {
                background-color: #f5f5f5;
            }
            QLabel {
                color: #333;
            }
            QLineEdit, QComboBox, QSpinBox {
                padding: 5px;
                border: 1px solid #ddd;
                border-radius: 3px;
            }
            QPushButton {
                padding: 8px;
                border-radius: 3px;
                font-weight: bold;
            }
            QTableWidget {
                background-color: white;
                alternate-background-color: #f9f9f9;
            }
            QTextEdit {
                background-color: #1e1e1e;
                color: #00ff00;
                font-family: Courier New;
            }
        """
        self.setStyleSheet(stylesheet)


def main():
    """Main entry point"""
    if not PYQT_AVAILABLE:
        print("[!] PyQt5 is required. Install with:")
        print("    pip install PyQt5 PyQt5-sip")
        sys.exit(1)
    
    app = QApplication(sys.argv)
    window = NightFuryGeminiGUI()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
