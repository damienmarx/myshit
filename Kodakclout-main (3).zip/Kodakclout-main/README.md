# 🎰 Cloutscape Casino

Premium OSRS-inspired casino platform with provably fair games.

## 🎮 Games Available

- **Flower Poker** - 5x5 grid matching game
- **Keno** - Classic 80-ball number picking
- **Dice** - Roll and predict outcomes
- **Crash** - Watch multipliers climb, cash out before crash
- **Plinko** - Ball drops through pegs into multiplier buckets
- **Roulette** - Classic wheel betting
- **Lucky Wheel** - Spin for instant prizes
- **Hot/Cold** - 50/50 prediction game

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- MySQL 8.0+
- pnpm (will be installed automatically)

### Local Development

1. **Clone and configure:**
   ```bash
   git clone https://github.com/damienmarx/Kodakclout.git
   cd Kodakclout
   cp .env.example .env
   # Edit .env with your database credentials
   ```

2. **Setup database:**
   ```bash
   mysql -u root -p < schema.sql
   ```

3. **Start the app:**
   ```bash
   ./start.sh
   ```

4. **Access:** http://localhost:8080

### Production with Cloudflare Tunnel

1. **Start the app:**
   ```bash
   ./start.sh &
   ```

2. **Start Cloudflare tunnel:**
   ```bash
   ./start-tunnel.sh
   ```

3. **Access:** https://cloutscape.org

## 🔐 Authentication

### Local Auth (Username/Password)
- Register with username, optional email, and password
- Login with username or email

### Discord OAuth (Fallback)
1. Create app at https://discord.com/developers/applications
2. Get Client ID and Client Secret
3. Add redirect URI: `https://cloutscape.org/api/oauth/discord/callback`
4. Update `.env` with credentials

## 📁 Project Structure

```
├── client/           # React frontend
│   ├── src/
│   │   ├── components/   # Game components
│   │   ├── pages/        # Route pages
│   │   └── lib/          # Utilities
├── server/           # Express + tRPC backend
│   ├── routers/      # API routes
│   └── _core/        # Core utilities
├── c2-dashboard/     # Admin dashboard
├── drizzle/          # Database schema
├── shared/           # Shared constants
└── backup/           # Archived files
```

## ⚙️ Environment Variables

```env
# Required
DATABASE_URL=mysql://user:pass@localhost:3306/kodakclout
COOKIE_SECRET=your-32-char-secret

# Discord OAuth (optional)
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=
DISCORD_REDIRECT_URI=https://cloutscape.org/api/oauth/discord/callback
```

## 🛠️ Commands

```bash
pnpm dev          # Development mode
pnpm build        # Build for production
pnpm start        # Start production server
pnpm db:push      # Run database migrations
```

## 📜 License

MIT License - Cloutscape.org
