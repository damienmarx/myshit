#!/usr/bin/env python3
"""
NIGHTFURY C2 DASHBOARD
======================
Web-based Command & Control Center for Cloutscape/Degens.Den deployment.
Provides easy configuration, monitoring, and deployment management.

Author: Nightfury Engine
Version: 1.0.0
"""

import os
import sys
import json
import subprocess
import threading
import time
import secrets
import re
from datetime import datetime
from pathlib import Path
from functools import wraps

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_socketio import SocketIO, emit

# Configuration
BASE_DIR = Path(__file__).parent.parent
C2_DIR = Path(__file__).parent
ENV_FILE = BASE_DIR / '.env'
ENV_EXAMPLE = BASE_DIR / '.env.example'
CLOUDFLARED_CONFIG = BASE_DIR / 'cloudflared-config.yml'
ECOSYSTEM_CONFIG = BASE_DIR / 'ecosystem.config.cjs'
LOG_DIR = Path('/var/log/degens-den')
BACKUP_DIR = BASE_DIR / 'backups'

# Flask App
app = Flask(__name__)
app.secret_key = os.environ.get('C2_SECRET_KEY', secrets.token_hex(32))
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Default C2 credentials (change these!)
C2_USERNAME = os.environ.get('C2_USERNAME', 'admin')
C2_PASSWORD = os.environ.get('C2_PASSWORD', 'nightfury2024')

# ==================== AUTHENTICATION ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == C2_USERNAME and password == C2_PASSWORD:
            session['logged_in'] = True
            session['username'] = username
            flash('Welcome to Nightfury C2 Dashboard!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'info')
    return redirect(url_for('login'))

# ==================== UTILITY FUNCTIONS ====================

def run_command(cmd, timeout=60):
    """Run a shell command and return output"""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return {
            'success': result.returncode == 0,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'returncode': result.returncode
        }
    except subprocess.TimeoutExpired:
        return {'success': False, 'error': 'Command timed out'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def parse_env_file(filepath):
    """Parse .env file into dictionary"""
    env_vars = {}
    if filepath.exists():
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, value = line.partition('=')
                    env_vars[key.strip()] = value.strip()
    return env_vars

def save_env_file(filepath, env_vars):
    """Save dictionary to .env file with comments preserved"""
    lines = []
    existing_keys = set()
    
    # Read existing file to preserve comments and order
    if filepath.exists():
        with open(filepath, 'r') as f:
            for line in f:
                if line.strip().startswith('#') or not line.strip():
                    lines.append(line.rstrip())
                elif '=' in line:
                    key = line.split('=')[0].strip()
                    existing_keys.add(key)
                    if key in env_vars:
                        lines.append(f"{key}={env_vars[key]}")
                    else:
                        lines.append(line.rstrip())
    
    # Add new keys
    for key, value in env_vars.items():
        if key not in existing_keys:
            lines.append(f"{key}={value}")
    
    with open(filepath, 'w') as f:
        f.write('\n'.join(lines) + '\n')

def get_system_status():
    """Get comprehensive system status"""
    status = {
        'app': {'status': 'unknown', 'details': ''},
        'mysql': {'status': 'unknown', 'details': ''},
        'cloudflared': {'status': 'unknown', 'details': ''},
        'pm2': {'status': 'unknown', 'details': ''},
        'port': {'status': 'unknown', 'details': ''},
        'domain': {'status': 'unknown', 'details': ''}
    }
    
    # Check PM2 process
    pm2_result = run_command("pm2 jlist 2>/dev/null")
    if pm2_result['success'] and pm2_result['stdout']:
        try:
            processes = json.loads(pm2_result['stdout'])
            for proc in processes:
                if proc.get('name') == 'degens-den':
                    pm2_status = proc.get('pm2_env', {}).get('status', 'unknown')
                    status['pm2'] = {
                        'status': 'online' if pm2_status == 'online' else 'offline',
                        'details': f"PID: {proc.get('pid', 'N/A')}, Memory: {proc.get('monit', {}).get('memory', 0) // 1024 // 1024}MB"
                    }
                    break
        except:
            pass
    
    # Check application health
    app_result = run_command("curl -s -o /dev/null -w '%{http_code}' http://localhost:8080/ 2>/dev/null")
    if app_result['success']:
        code = app_result['stdout'].strip()
        status['app'] = {
            'status': 'online' if code in ['200', '302', '304'] else 'offline',
            'details': f"HTTP {code}"
        }
    
    # Check MySQL
    mysql_result = run_command("systemctl is-active mysql 2>/dev/null || service mysql status 2>/dev/null | grep -q running && echo active")
    status['mysql'] = {
        'status': 'online' if 'active' in mysql_result.get('stdout', '') else 'offline',
        'details': 'Running' if 'active' in mysql_result.get('stdout', '') else 'Stopped'
    }
    
    # Check Cloudflared
    cf_result = run_command("pgrep -x cloudflared")
    status['cloudflared'] = {
        'status': 'online' if cf_result['success'] else 'offline',
        'details': f"PID: {cf_result['stdout'].strip()}" if cf_result['success'] else 'Not running'
    }
    
    # Check port 8080
    port_result = run_command("lsof -i :8080 | grep LISTEN | head -1")
    status['port'] = {
        'status': 'in_use' if port_result['success'] else 'free',
        'details': port_result['stdout'].strip()[:50] if port_result['success'] else 'Port 8080 is free'
    }
    
    # Check domain (with timeout)
    domain_result = run_command("curl -s -o /dev/null -w '%{http_code}' --max-time 5 https://cloutscape.org/ 2>/dev/null")
    if domain_result['success']:
        code = domain_result['stdout'].strip()
        status['domain'] = {
            'status': 'online' if code in ['200', '302', '304'] else 'unreachable',
            'details': f"HTTPS {code}"
        }
    
    return status

def generate_secret(length=64):
    """Generate a secure random secret"""
    return secrets.token_hex(length // 2)

# ==================== ROUTES ====================

@app.route('/')
@login_required
def dashboard():
    """Main dashboard"""
    status = get_system_status()
    env_vars = parse_env_file(ENV_FILE)
    return render_template('dashboard.html', status=status, env_vars=env_vars)

@app.route('/env')
@login_required
def env_manager():
    """Environment variables manager"""
    env_vars = parse_env_file(ENV_FILE)
    env_example = parse_env_file(ENV_EXAMPLE)
    return render_template('env_manager.html', env_vars=env_vars, env_example=env_example)

@app.route('/api/env', methods=['GET'])
@login_required
def get_env():
    """Get all environment variables"""
    env_vars = parse_env_file(ENV_FILE)
    # Mask sensitive values
    masked = {}
    sensitive_keys = ['PASSWORD', 'SECRET', 'TOKEN', 'KEY']
    for key, value in env_vars.items():
        if any(s in key.upper() for s in sensitive_keys):
            masked[key] = value[:4] + '****' + value[-4:] if len(value) > 8 else '****'
        else:
            masked[key] = value
    return jsonify({'success': True, 'env': masked, 'raw': env_vars})

@app.route('/api/env', methods=['POST'])
@login_required
def update_env():
    """Update environment variables"""
    try:
        data = request.json
        env_vars = parse_env_file(ENV_FILE)
        
        for key, value in data.items():
            if value is not None:
                env_vars[key] = str(value)
        
        save_env_file(ENV_FILE, env_vars)
        return jsonify({'success': True, 'message': 'Environment updated'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/env/generate-secret', methods=['POST'])
@login_required
def generate_secret_endpoint():
    """Generate a new secret"""
    key = request.json.get('key', 'SECRET')
    length = request.json.get('length', 64)
    secret = generate_secret(length)
    return jsonify({'success': True, 'key': key, 'secret': secret})

@app.route('/tunnel')
@login_required
def tunnel_config():
    """Cloudflare tunnel configuration"""
    config = {}
    if CLOUDFLARED_CONFIG.exists():
        with open(CLOUDFLARED_CONFIG, 'r') as f:
            config['content'] = f.read()
    return render_template('tunnel.html', config=config)

@app.route('/api/tunnel/config', methods=['GET'])
@login_required
def get_tunnel_config():
    """Get tunnel configuration"""
    if CLOUDFLARED_CONFIG.exists():
        with open(CLOUDFLARED_CONFIG, 'r') as f:
            return jsonify({'success': True, 'config': f.read()})
    return jsonify({'success': False, 'error': 'Config file not found'})

@app.route('/api/tunnel/config', methods=['POST'])
@login_required
def save_tunnel_config():
    """Save tunnel configuration"""
    try:
        config = request.json.get('config', '')
        with open(CLOUDFLARED_CONFIG, 'w') as f:
            f.write(config)
        return jsonify({'success': True, 'message': 'Tunnel config saved'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/tunnel/start', methods=['POST'])
@login_required
def start_tunnel():
    """Start Cloudflare tunnel"""
    token = request.json.get('token', os.environ.get('CLOUDFLARE_TUNNEL_TOKEN', ''))
    if token:
        result = run_command(f"nohup cloudflared tunnel run --token {token} > /var/log/degens-den/cloudflared.log 2>&1 &")
    else:
        result = run_command(f"nohup cloudflared tunnel --config {CLOUDFLARED_CONFIG} run > /var/log/degens-den/cloudflared.log 2>&1 &")
    return jsonify(result)

@app.route('/api/tunnel/stop', methods=['POST'])
@login_required
def stop_tunnel():
    """Stop Cloudflare tunnel"""
    result = run_command("pkill -x cloudflared")
    return jsonify({'success': True, 'message': 'Tunnel stopped'})

@app.route('/deploy')
@login_required
def deploy_page():
    """Deployment controls"""
    return render_template('deploy.html')

@app.route('/api/deploy/full', methods=['POST'])
@login_required
def full_deploy():
    """Run full deployment"""
    def run_deploy():
        socketio.emit('deploy_log', {'message': '🐉 Starting Nightfury Engine deployment...\n', 'type': 'info'})
        process = subprocess.Popen(
            ['bash', str(BASE_DIR / 'nightfury-engine.sh')],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            cwd=str(BASE_DIR)
        )
        for line in process.stdout:
            socketio.emit('deploy_log', {'message': line, 'type': 'log'})
        process.wait()
        if process.returncode == 0:
            socketio.emit('deploy_log', {'message': '\n✅ Deployment completed successfully!', 'type': 'success'})
        else:
            socketio.emit('deploy_log', {'message': f'\n❌ Deployment failed with code {process.returncode}', 'type': 'error'})
    
    thread = threading.Thread(target=run_deploy)
    thread.start()
    return jsonify({'success': True, 'message': 'Deployment started'})

@app.route('/api/deploy/restart', methods=['POST'])
@login_required
def restart_app():
    """Restart the application"""
    result = run_command("pm2 restart degens-den")
    return jsonify(result)

@app.route('/api/deploy/rebuild', methods=['POST'])
@login_required
def rebuild_app():
    """Rebuild and restart"""
    def run_rebuild():
        socketio.emit('deploy_log', {'message': '🔄 Starting rebuild...\n', 'type': 'info'})
        commands = [
            ('Stopping application...', 'pm2 stop degens-den 2>/dev/null || true'),
            ('Cleaning build...', f'cd {BASE_DIR} && rm -rf dist/ client/dist/'),
            ('Installing dependencies...', f'cd {BASE_DIR} && pnpm install'),
            ('Building...', f'cd {BASE_DIR} && NODE_ENV=production pnpm run build'),
            ('Starting application...', 'pm2 start ecosystem.config.cjs --env production')
        ]
        for step, cmd in commands:
            socketio.emit('deploy_log', {'message': f'\n{step}\n', 'type': 'info'})
            result = run_command(cmd, timeout=300)
            if not result['success']:
                socketio.emit('deploy_log', {'message': f'❌ Failed: {result.get("stderr", result.get("error", "Unknown error"))}', 'type': 'error'})
                return
            socketio.emit('deploy_log', {'message': result.get('stdout', 'Done'), 'type': 'log'})
        socketio.emit('deploy_log', {'message': '\n✅ Rebuild completed!', 'type': 'success'})
    
    thread = threading.Thread(target=run_rebuild)
    thread.start()
    return jsonify({'success': True, 'message': 'Rebuild started'})

@app.route('/api/deploy/stop', methods=['POST'])
@login_required
def stop_app():
    """Stop the application"""
    result = run_command("pm2 stop degens-den")
    return jsonify(result)

@app.route('/logs')
@login_required
def logs_page():
    """Logs viewer"""
    return render_template('logs.html')

@app.route('/api/logs/<log_type>')
@login_required
def get_logs(log_type):
    """Get logs"""
    log_files = {
        'app': '/var/log/degens-den/out.log',
        'error': '/var/log/degens-den/error.log',
        'cloudflared': '/var/log/degens-den/cloudflared.log',
        'deploy': str(BASE_DIR / 'nightfury_deploy.log')
    }
    
    filepath = log_files.get(log_type)
    if not filepath or not Path(filepath).exists():
        return jsonify({'success': False, 'error': 'Log file not found'})
    
    lines = request.args.get('lines', 100, type=int)
    result = run_command(f"tail -n {lines} {filepath}")
    return jsonify({'success': True, 'logs': result.get('stdout', ''), 'file': filepath})

@app.route('/api/status')
@login_required
def get_status():
    """Get system status"""
    return jsonify(get_system_status())

@app.route('/api/backup', methods=['POST'])
@login_required
def create_backup():
    """Create database backup"""
    result = run_command(f"bash {BASE_DIR}/scripts/db-backup.sh")
    return jsonify(result)

@app.route('/api/health')
def health_check():
    """Health check endpoint (no auth required)"""
    return jsonify({'status': 'ok', 'timestamp': datetime.now().isoformat()})

# ==================== WEBSOCKET EVENTS ====================

@socketio.on('connect')
def handle_connect():
    if session.get('logged_in'):
        emit('connected', {'message': 'Connected to C2 Dashboard'})

@socketio.on('request_status')
def handle_status_request():
    emit('status_update', get_system_status())

# ==================== MAIN ====================

if __name__ == '__main__':
    # Create log directory
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    
    # Create .env if not exists
    if not ENV_FILE.exists() and ENV_EXAMPLE.exists():
        import shutil
        shutil.copy(ENV_EXAMPLE, ENV_FILE)
    
    print("""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║    🐉 NIGHTFURY C2 DASHBOARD                                      ║
║                                                                   ║
║    URL: http://localhost:5000                                     ║
║    Default Login: admin / nightfury2024                           ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
    """)
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=False, allow_unsafe_werkzeug=True)
