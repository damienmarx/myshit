#!/bin/bash
# ==============================================================================
# NIGHTFURY C2 DASHBOARD - Background Startup
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/var/log/degens-den/c2-dashboard.log"

mkdir -p /var/log/degens-den

echo "[INFO] Starting C2 Dashboard in background..."
nohup bash "$SCRIPT_DIR/start-c2.sh" > "$LOG_FILE" 2>&1 &

echo "[SUCCESS] C2 Dashboard started"
echo "  URL: http://localhost:5000"
echo "  Log: $LOG_FILE"
echo "  PID: $!"
