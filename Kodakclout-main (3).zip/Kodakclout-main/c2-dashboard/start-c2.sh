#!/bin/bash
# ==============================================================================
# NIGHTFURY C2 DASHBOARD - Startup Script
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

echo "========================================"
echo "  🐉 NIGHTFURY C2 DASHBOARD"
echo "========================================"
echo ""

# Check if Python is available
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] Python3 is required"
    exit 1
fi

# Create virtual environment if not exists
if [ ! -d "$SCRIPT_DIR/venv" ]; then
    echo "[INFO] Creating virtual environment..."
    python3 -m venv "$SCRIPT_DIR/venv"
fi

# Activate virtual environment
source "$SCRIPT_DIR/venv/bin/activate"

# Install dependencies
echo "[INFO] Installing dependencies..."
pip install -q -r "$SCRIPT_DIR/requirements.txt"

# Set environment variables
export FLASK_APP="$SCRIPT_DIR/app.py"
export FLASK_ENV=production

# Default credentials (can be overridden)
export C2_USERNAME="${C2_USERNAME:-admin}"
export C2_PASSWORD="${C2_PASSWORD:-nightfury2024}"

echo ""
echo "╔═══════════════════════════════════════════════════════════════════╗"
echo "║                                                                   ║"
echo "║    🐉 NIGHTFURY C2 DASHBOARD                                      ║"
echo "║                                                                   ║"
echo "║    URL: http://localhost:5000                                     ║"
echo "║    Login: $C2_USERNAME / $C2_PASSWORD                             ║"
echo "║                                                                   ║"
echo "╚═══════════════════════════════════════════════════════════════════╝"
echo ""

# Start the dashboard
cd "$SCRIPT_DIR"
python3 app.py
