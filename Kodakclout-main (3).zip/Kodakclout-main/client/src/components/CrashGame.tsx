/**
 * Crash Game Component
 * Watch the multiplier climb and cash out before it crashes
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { TrendingUp, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface CrashGameState {
  betAmount: number;
  balance: number;
  gameStatus: 'idle' | 'running' | 'crashed' | 'cashed-out';
  multiplier: number;
  crashPoint: number;
  cashedOutAt: number | null;
  winAmount: number;
  history: number[];
}

export function CrashGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<CrashGameState>({
    betAmount: 100,
    balance: wallet.balance,
    gameStatus: 'idle',
    multiplier: 1.0,
    crashPoint: 0,
    cashedOutAt: null,
    winAmount: 0,
    history: [],
  });

  useEffect(() => {
    if (gameState.gameStatus !== 'running') return;

    const interval = setInterval(() => {
      setGameState((prev) => {
        if (prev.gameStatus !== 'running') return prev;

        const newMultiplier = prev.multiplier + 0.05;

        // Check if crashed
        if (newMultiplier >= prev.crashPoint) {
          return {
            ...prev,
            gameStatus: 'crashed',
            multiplier: prev.crashPoint,
          };
        }

        return {
          ...prev,
          multiplier: parseFloat(newMultiplier.toFixed(2)),
        };
      });
    }, 100);

    return () => clearInterval(interval);
  }, [gameState.gameStatus]);

  const handleStartGame = async () => {
    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('crash', gameState.betAmount);
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
      return;
    }

    const crashPoint = parseFloat((1 + Math.random() * 10).toFixed(2));

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'running',
      multiplier: 1.0,
      crashPoint,
      cashedOutAt: null,
      winAmount: 0,
      balance: prev.balance - prev.betAmount,
    }));
  };

  const handleCashOut = async () => {
    if (gameState.gameStatus !== 'running') return;

    const winAmount = gameState.betAmount * gameState.multiplier;

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'cashed-out',
      cashedOutAt: prev.multiplier,
      winAmount,
      balance: prev.balance + winAmount,
      history: [prev.crashPoint, ...prev.history.slice(0, 9)],
    }));

    // Record win
    setTimeout(async () => {
      try {
        await wallet.recordWin('crash', gameState.betAmount, gameState.multiplier, winAmount, {
          crashPoint: gameState.crashPoint,
          cashedOutAt: gameState.multiplier,
        });
        toast.success(`Cashed out at ${gameState.multiplier.toFixed(2)}x for ${winAmount.toFixed(0)} GP! 🎉`);
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }, 100);
  };

  const handlePlayAgain = async () => {
    // Record loss if crashed
    if (gameState.gameStatus === 'crashed') {
      try {
        await wallet.recordLoss('crash', gameState.betAmount, {
          crashPoint: gameState.crashPoint,
        });
        toast.info(`Lost ${gameState.betAmount} GP`);
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'idle',
      multiplier: 1.0,
      crashPoint: 0,
      cashedOutAt: null,
      winAmount: 0,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Wallet Balance" value={`${wallet.balance.toLocaleString()} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Current Multiplier" value={`${gameState.multiplier.toFixed(2)}x`} highlight={gameState.gameStatus === 'running'} />
        <OSRSStatBox label="Game Balance" value={`${gameState.balance.toLocaleString()} GP`} />
      </div>

      {/* Crash Game */}
      <OSRSPanel title="CRASH">
        <div className="space-y-6">
          {/* Game Display */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart Area */}
            <div className="bg-black/50 border-2 border-osrs-gold/30 rounded-lg p-6 aspect-video flex flex-col justify-between">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-osrs-gold font-bold">MULTIPLIER CHART</h3>
                <TrendingUp className={cn(
                  'w-6 h-6',
                  gameState.gameStatus === 'crashed' ? 'text-red-500' : 'text-green-500'
                )} />
              </div>

              {/* Simple chart representation */}
              <div className="flex-1 flex items-end gap-1">
                {Array.from({ length: 20 }).map((_, i) => {
                  const height = Math.min(100, (i + 1) * 5);
                  const isAboveCrash = (i + 1) * 0.5 > gameState.crashPoint;

                  return (
                    <div
                      key={i}
                      className={cn(
                        'flex-1 rounded-t-sm transition-all',
                        isAboveCrash ? 'bg-red-600/50' : 'bg-green-600/50'
                      )}
                      style={{ height: `${height}%` }}
                    />
                  );
                })}
              </div>

              {/* Status */}
              <div className="mt-4 text-center">
                {gameState.gameStatus === 'running' && (
                  <p className="text-green-400 font-bold animate-pulse">CLIMBING...</p>
                )}
                {gameState.gameStatus === 'crashed' && (
                  <div className="flex items-center justify-center gap-2 text-red-500 font-bold">
                    <AlertTriangle className="w-5 h-5" />
                    CRASHED AT {gameState.crashPoint.toFixed(2)}x
                  </div>
                )}
                {gameState.gameStatus === 'cashed-out' && (
                  <p className="text-green-400 font-bold">CASHED OUT AT {gameState.cashedOutAt?.toFixed(2)}x</p>
                )}
                {gameState.gameStatus === 'idle' && (
                  <p className="text-gray-400">Ready to play</p>
                )}
              </div>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              {/* Multiplier Display */}
              <div className="bg-osrs-gold/10 border-2 border-osrs-gold rounded-lg p-6 text-center">
                <p className="text-osrs-gold font-bold text-sm mb-2">CURRENT MULTIPLIER</p>
                <p className="text-6xl font-black text-osrs-gold">
                  {gameState.multiplier.toFixed(2)}x
                </p>
              </div>

              {/* Bet Amount */}
              <div>
                <label className="text-osrs-gold font-bold text-sm block mb-2">BET AMOUNT</label>
                <input
                  type="number"
                  value={gameState.betAmount}
                  onChange={(e) =>
                    setGameState((prev) => ({
                      ...prev,
                      betAmount: Math.min(10000, Math.max(10, parseInt(e.target.value) || 10)),
                    }))
                  }
                  disabled={gameState.gameStatus !== 'idle'}
                  className="w-full bg-black/50 border border-yellow-600/30 text-white px-3 py-2 rounded-sm"
                />
              </div>

              {/* Win Amount (if cashed out) */}
              {gameState.gameStatus === 'cashed-out' && (
                <div className="bg-green-600/10 border-2 border-green-600 rounded-lg p-4 text-center">
                  <p className="text-green-400 font-bold text-sm mb-1">YOU CASHED OUT</p>
                  <p className="text-2xl font-black text-green-400">
                    +{gameState.winAmount.toFixed(0)} GP
                  </p>
                </div>
              )}

              {/* Crash Info (if crashed) */}
              {gameState.gameStatus === 'crashed' && (
                <div className="bg-red-600/10 border-2 border-red-600 rounded-lg p-4 text-center">
                  <p className="text-red-400 font-bold text-sm mb-1">GAME CRASHED</p>
                  <p className="text-xl font-black text-red-400">
                    Crash Point: {gameState.crashPoint.toFixed(2)}x
                  </p>
                </div>
              )}

              {/* Recent Crashes */}
              {gameState.history.length > 0 && (
                <div>
                  <p className="text-osrs-gold font-bold text-sm mb-2">RECENT CRASHES</p>
                  <div className="grid grid-cols-5 gap-2">
                    {gameState.history.map((crash, idx) => (
                      <div
                        key={idx}
                        className="bg-black/50 border border-osrs-gold/20 rounded p-2 text-center text-xs font-bold text-gray-400"
                      >
                        {crash.toFixed(2)}x
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton onClick={handleStartGame} disabled={wallet.placeBetLoading} className="flex-1">
            {wallet.placeBetLoading ? 'PLACING BET...' : 'START GAME'}
          </OSRSButton>
        )}
        {gameState.gameStatus === 'running' && (
          <OSRSButton onClick={handleCashOut} variant="gold" className="flex-1">
            CASH OUT NOW ({gameState.multiplier.toFixed(2)}x)
          </OSRSButton>
        )}
        {(gameState.gameStatus === 'crashed' || gameState.gameStatus === 'cashed-out') && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
