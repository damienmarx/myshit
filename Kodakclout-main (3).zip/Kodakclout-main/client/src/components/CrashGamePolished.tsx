/**
 * Polished Crash Game Component
 * Real-time multiplier display with cash-out mechanics
 */

import React, { useState, useEffect } from 'react';
import { useWallet } from '@/hooks/useWallet';
import { toast } from 'sonner';

interface GameState {
  betAmount: number;
  multiplier: number;
  gameStatus: 'idle' | 'running' | 'crashed' | 'won';
  hasPlaced: boolean;
  cashOutMultiplier: number | null;
  gameHistory: number[];
}

export function CrashGamePolished() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    betAmount: 100,
    multiplier: 1.0,
    gameStatus: 'idle',
    hasPlaced: false,
    cashOutMultiplier: null,
    gameHistory: [],
  });

  const [gameRunning, setGameRunning] = useState(false);

  useEffect(() => {
    if (gameState.gameStatus === 'running' && gameRunning) {
      const interval = setInterval(() => {
        setGameState((prev) => {
          const newMultiplier = prev.multiplier + 0.01;
          
          // Random crash chance (increases with multiplier)
          const crashChance = Math.pow(newMultiplier, 1.5) / 1000;
          if (Math.random() < crashChance) {
            setGameRunning(false);
            toast.error(`CRASHED at ${prev.multiplier.toFixed(2)}x`);
            return {
              ...prev,
              gameStatus: 'crashed',
              gameHistory: [...prev.gameHistory, prev.multiplier],
            };
          }

          return {
            ...prev,
            multiplier: newMultiplier,
          };
        });
      }, 100);

      return () => clearInterval(interval);
    }
  }, [gameState.gameStatus, gameRunning]);

  const handleBetAmountChange = (amount: number) => {
    if (amount > 0 && amount <= wallet.balance) {
      setGameState((prev) => ({ ...prev, betAmount: amount }));
    }
  };

  const handlePlaceBet = async () => {
    if (wallet.balance < gameState.betAmount) {
      toast.error('Insufficient balance');
      return;
    }

    try {
      await wallet.placeBet('crash', gameState.betAmount);

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'running',
        hasPlaced: true,
        multiplier: 1.0,
      }));
      setGameRunning(true);
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
    }
  };

  const handleCashOut = async () => {
    if (!gameState.hasPlaced) return;

    setGameRunning(false);
    const winAmount = gameState.betAmount * gameState.multiplier;

    try {
      await wallet.recordWin('crash', gameState.betAmount, gameState.multiplier, winAmount, {
        multiplier: gameState.multiplier,
      });
      toast.success(`CASHED OUT at ${gameState.multiplier.toFixed(2)}x! Won ${winAmount.toFixed(0)} GP!`);

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'won',
        cashOutMultiplier: prev.multiplier,
        gameHistory: [...prev.gameHistory, prev.multiplier],
      }));
    } catch (error) {
      toast.error('Failed to cash out');
      console.error(error);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      betAmount: gameState.betAmount,
      multiplier: 1.0,
      gameStatus: 'idle',
      hasPlaced: false,
      cashOutMultiplier: null,
      gameHistory: gameState.gameHistory,
    });
    setGameRunning(false);
  };

  return (
    <div className="space-y-8">
      {/* Game Display */}
      <div className="glass-panel-gold p-12 text-center">
        <div className="text-7xl font-black text-yellow-600 mb-4 animate-glow-pulse">
          {gameState.multiplier.toFixed(2)}x
        </div>
        <div className="text-2xl font-bold text-gray-400 mb-6">
          {gameState.gameStatus === 'running'
            ? 'GAME RUNNING - CASH OUT ANYTIME'
            : gameState.gameStatus === 'crashed'
            ? 'GAME CRASHED'
            : gameState.gameStatus === 'won'
            ? `CASHED OUT AT ${gameState.cashOutMultiplier?.toFixed(2)}x`
            : 'PLACE YOUR BET'}
        </div>

        {/* Crash Animation */}
        {gameState.gameStatus === 'crashed' && (
          <div className="text-6xl animate-bounce">💥</div>
        )}
      </div>

      {/* Bet Amount */}
      {gameState.gameStatus === 'idle' && (
        <div className="glass-panel-gold p-6">
          <h3 className="osrs-panel-title mb-4">SELECT BET AMOUNT</h3>
          <div className="grid grid-cols-4 gap-3 mb-4">
            {[100, 500, 1000, 5000].map((amount) => (
              <button
                key={amount}
                onClick={() => handleBetAmountChange(amount)}
                disabled={amount > wallet.balance}
                className={`p-3 rounded-lg border-2 transition-all font-bold ${
                  gameState.betAmount === amount
                    ? 'glass-panel-gold border-yellow-600/60 text-yellow-600'
                    : 'glass-panel border-yellow-600/30 text-gray-400 hover:border-yellow-600/60'
                }`}
              >
                {amount}
              </button>
            ))}
          </div>
          <input
            type="number"
            value={gameState.betAmount}
            onChange={(e) => handleBetAmountChange(parseInt(e.target.value) || 0)}
            min="1"
            max={wallet.balance}
            className="input-luxury w-full"
            placeholder="Enter custom bet amount"
          />
        </div>
      )}

      {/* Game History */}
      {gameState.gameHistory.length > 0 && (
        <div className="glass-panel p-6">
          <h3 className="osrs-panel-title mb-4">RECENT CRASHES</h3>
          <div className="grid grid-cols-10 gap-2">
            {gameState.gameHistory.slice(-10).map((crash, idx) => (
              <div
                key={idx}
                className="glass-panel p-2 text-center rounded-lg border border-yellow-600/30"
              >
                <div className="text-sm font-bold text-yellow-600">{crash.toFixed(2)}x</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <button onClick={handlePlaceBet} className="btn-luxury flex-1 py-4 text-lg">
            PLACE BET
          </button>
        )}
        {gameState.gameStatus === 'running' && (
          <button onClick={handleCashOut} className="btn-luxury-crimson flex-1 py-4 text-lg">
            CASH OUT NOW
          </button>
        )}
        {(gameState.gameStatus === 'crashed' || gameState.gameStatus === 'won') && (
          <button onClick={handlePlayAgain} className="btn-luxury flex-1 py-4 text-lg">
            PLAY AGAIN
          </button>
        )}
      </div>
    </div>
  );
}
