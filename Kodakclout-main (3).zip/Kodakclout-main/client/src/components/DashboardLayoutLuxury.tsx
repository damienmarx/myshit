/**
 * Luxury Dashboard Layout Component
 * Stake/Runehall-inspired design with glassmorphism and 7DEGEN7DEN7 branding
 */

import React, { useState } from 'react';
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarTrigger } from './ui/sidebar';
import { cn } from '@/lib/utils';
import { Wallet, Flame, Trophy, Users, MessageSquare, Cloud, Settings, LogOut } from 'lucide-react';

interface DashboardLayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
  userBalance?: number;
  userName?: string;
}

const menuItems = [
  { id: 'home', label: 'Dashboard', icon: Flame },
  { id: 'games', label: 'Games', icon: Trophy },
  { id: 'wallet', label: 'Wallet', icon: Wallet },
  { id: 'leaderboard', label: 'Leaderboard', icon: Users },
  { id: 'rain', label: 'Rain', icon: Cloud },
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function DashboardLayoutLuxury({
  children,
  currentPage,
  onNavigate,
  userBalance = 0,
  userName = 'Player',
}: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <Sidebar className="glass-panel-gold border-r-2 border-yellow-600/30 w-64">
        <SidebarHeader className="p-6 border-b-2 border-yellow-600/30">
          <div className="space-y-2">
            <div className="brand-text text-2xl">7DEGEN</div>
            <div className="brand-subtitle text-sm">DEN</div>
            <div className="text-xs text-gray-500 mt-4">
              Welcome, <span className="text-yellow-600">{userName}</span>
            </div>
          </div>
        </SidebarHeader>

        <SidebarContent className="p-4 space-y-2">
          <SidebarMenu>
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;

              return (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    onClick={() => onNavigate(item.id)}
                    className={cn(
                      'w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300',
                      isActive
                        ? 'glass-panel-gold border-2 border-yellow-600/60 text-yellow-600'
                        : 'hover:glass-panel border border-yellow-600/20 text-gray-400 hover:text-yellow-600'
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-semibold">{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              );
            })}
          </SidebarMenu>

          {/* Wallet Info */}
          <div className="glass-panel mt-8 p-4 border-t-2 border-yellow-600/30">
            <div className="text-xs uppercase tracking-widest text-gray-400 mb-2">Balance</div>
            <div className="text-2xl font-black text-yellow-600">{userBalance.toLocaleString()} GP</div>
            <div className="text-xs text-gray-500 mt-2">Total Wagered: 50,000 GP</div>
          </div>

          {/* Logout */}
          <button className="w-full mt-6 btn-luxury-crimson flex items-center justify-center gap-2">
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </SidebarContent>
      </Sidebar>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="glass-panel-gold border-b-2 border-yellow-600/30 px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <SidebarTrigger className="btn-luxury p-2" />
            <h1 className="text-2xl font-bold text-yellow-600">
              {menuItems.find((item) => item.id === currentPage)?.label || 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="stat-box">
              <div className="stat-box-label">Current Balance</div>
              <div className="stat-box-value">{userBalance.toLocaleString()} GP</div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
