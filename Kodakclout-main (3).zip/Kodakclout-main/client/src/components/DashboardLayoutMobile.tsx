/**
 * Mobile-Responsive Dashboard Layout
 * Touch-friendly navigation with drawer sidebar
 */

import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Wallet, Flame, Trophy, Users, MessageSquare, Cloud, Settings, LogOut, Menu, X } from 'lucide-react';

interface DashboardLayoutMobileProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
  userBalance?: number;
  userName?: string;
}

const menuItems = [
  { id: 'home', label: 'Dashboard', icon: Flame },
  { id: 'games', label: 'Games', icon: Trophy },
  { id: 'wallet', label: 'Wallet', icon: Wallet },
  { id: 'leaderboard', label: 'Leaderboard', icon: Users },
  { id: 'rain', label: 'Rain', icon: Cloud },
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function DashboardLayoutMobile({
  children,
  currentPage,
  onNavigate,
  userBalance = 0,
  userName = 'Player',
}: DashboardLayoutMobileProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setSidebarOpen(false);
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Drawer on Mobile */}
      <aside
        className={cn(
          'glass-panel-gold border-r-2 border-yellow-600/30 w-full md:w-64 fixed md:static h-full z-50 transition-transform duration-300 overflow-y-auto',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        )}
      >
        {/* Header */}
        <div className="p-4 md:p-6 border-b-2 border-yellow-600/30 sticky top-0 bg-background/95 backdrop-blur">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="brand-text text-xl md:text-2xl">7DEGEN</div>
              <div className="brand-subtitle text-xs md:text-sm">DEN</div>
            </div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="md:hidden p-2 hover:bg-yellow-600/20 rounded-lg transition"
            >
              <X className="w-5 h-5 text-yellow-600" />
            </button>
          </div>
          <div className="text-xs text-gray-500">
            Welcome, <span className="text-yellow-600 font-bold">{userName}</span>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="p-3 md:p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 md:px-4 py-3 rounded-lg transition-all duration-200 text-sm md:text-base font-semibold',
                  isActive
                    ? 'glass-panel-gold border-2 border-yellow-600/60 text-yellow-600'
                    : 'hover:glass-panel border border-yellow-600/20 text-gray-400 hover:text-yellow-600'
                )}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Wallet Info */}
        <div className="p-3 md:p-4 border-t-2 border-yellow-600/30 mt-auto sticky bottom-0 bg-background/95 backdrop-blur space-y-3">
          <div className="glass-panel p-3 md:p-4 border-t-2 border-yellow-600/30">
            <div className="text-xs uppercase tracking-widest text-gray-400 mb-2">Balance</div>
            <div className="text-xl md:text-2xl font-black text-yellow-600">
              {userBalance.toLocaleString()} GP
            </div>
            <div className="text-xs text-gray-500 mt-1">Total Wagered: 50,000 GP</div>
          </div>

          {/* Logout Button */}
          <button className="btn-luxury-crimson w-full flex items-center justify-center gap-2 text-sm py-2">
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="glass-panel-gold border-b-2 border-yellow-600/30 px-4 md:px-8 py-3 md:py-4 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3 flex-1">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden p-2 hover:bg-yellow-600/20 rounded-lg transition"
            >
              <Menu className="w-5 h-5 text-yellow-600" />
            </button>
            <h1 className="text-lg md:text-2xl font-bold text-yellow-600 truncate">
              {menuItems.find((item) => item.id === currentPage)?.label || 'Dashboard'}
            </h1>
          </div>

          {/* Balance Display */}
          <div className="hidden sm:block stat-box text-xs md:text-sm">
            <div className="stat-box-label">Balance</div>
            <div className="stat-box-value text-lg md:text-2xl">{userBalance.toLocaleString()} GP</div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto p-3 md:p-8 bg-background">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
