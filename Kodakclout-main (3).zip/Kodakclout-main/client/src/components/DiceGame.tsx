/**
 * Dice Game Component
 * Quick-play dice rolling with multiple bet types
 */

import React, { useState } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { Dices } from 'lucide-react';
import { toast } from 'sonner';

type DiceBetType = 'high' | 'low' | 'odd' | 'even' | 'specific';

interface DiceGameState {
  betAmount: number;
  balance: number;
  gameStatus: 'idle' | 'rolling' | 'finished';
  result: number | null;
  betType: DiceBetType;
  specificNumber: number;
  won: boolean;
  winAmount: number;
  history: Array<{ result: number; won: boolean }>;
}

export function DiceGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<DiceGameState>({
    betAmount: 100,
    balance: wallet.balance,
    gameStatus: 'idle',
    result: null,
    betType: 'high',
    specificNumber: 3,
    won: false,
    winAmount: 0,
    history: [],
  });

  const handleRoll = async () => {
    if (gameState.gameStatus !== 'idle') return;

    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('flower_poker', gameState.betAmount);
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
      return;
    }

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'rolling',
      balance: prev.balance - prev.betAmount,
    }));

    // Simulate rolling animation
    for (let i = 0; i < 10; i++) {
      await new Promise((resolve) => setTimeout(resolve, 50));
      setGameState((prev) => ({
        ...prev,
        result: Math.floor(Math.random() * 6) + 1,
      }));
    }

    // Final result
    const result = Math.floor(Math.random() * 6) + 1;

    // Check if won
    let won = false;
    switch (gameState.betType) {
      case 'high':
        won = result > 3;
        break;
      case 'low':
        won = result <= 3;
        break;
      case 'odd':
        won = result % 2 === 1;
        break;
      case 'even':
        won = result % 2 === 0;
        break;
      case 'specific':
        won = result === gameState.specificNumber;
        break;
    }

    const winAmount = won ? gameState.betAmount * 2 : 0;

    setGameState((prev) => ({
      ...prev,
      result,
      gameStatus: 'finished',
      won,
      winAmount,
      balance: prev.balance + winAmount,
      history: [{ result, won }, ...prev.history.slice(0, 9)],
    }));

    // Record result
    setTimeout(async () => {
      try {
        if (won) {
          await wallet.recordWin('flower_poker', gameState.betAmount, 2, winAmount, {
            result,
            betType: gameState.betType,
          });
          toast.success(`Won ${winAmount.toFixed(0)} GP! 🎉`);
        } else {
          await wallet.recordLoss('flower_poker', gameState.betAmount, {
            result,
            betType: gameState.betType,
          });
          toast.info(`Lost ${gameState.betAmount} GP`);
        }
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }, 100);
  };

  const handlePlayAgain = () => {
    setGameState((prev) => ({
      ...prev,
      gameStatus: 'idle',
      result: null,
      won: false,
      winAmount: 0,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Wallet Balance" value={`${wallet.balance.toLocaleString()} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Payout" value={`${gameState.betAmount * 2} GP`} />
        <OSRSStatBox label="Game Balance" value={`${gameState.balance.toLocaleString()} GP`} />
      </div>

      {/* Dice Game */}
      <OSRSPanel title="DICE ROLL">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Dice Display */}
          <div className="flex-1 flex items-center justify-center">
            <div className="relative w-48 h-48">
              {gameState.result !== null && (
                <div
                  className={cn(
                    'absolute inset-0 flex items-center justify-center rounded-lg border-4 transition-all',
                    gameState.gameStatus === 'rolling' && 'animate-spin',
                    gameState.won ? 'border-green-600 bg-green-600/10' : 'border-red-600 bg-red-600/10'
                  )}
                >
                  <div className="text-center">
                    <p className="text-6xl font-black text-osrs-gold mb-2">{gameState.result}</p>
                    <p className={cn('font-bold', gameState.won ? 'text-green-400' : 'text-red-400')}>
                      {gameState.won ? 'WIN!' : 'LOSE'}
                    </p>
                  </div>
                </div>
              )}
              {gameState.result === null && (
                <div className="absolute inset-0 flex items-center justify-center rounded-lg border-4 border-osrs-gold/30 bg-black/50">
                  <Dices className="w-16 h-16 text-osrs-gold/50" />
                </div>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="flex-1 space-y-4">
            {/* Bet Type Selection */}
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">BET TYPE</label>
              <div className="space-y-2">
                <button
                  onClick={() => setGameState((prev) => ({ ...prev, betType: 'high' }))}
                  disabled={gameState.gameStatus !== 'idle'}
                  className={cn(
                    'w-full py-2 rounded-sm border-2 font-bold transition-colors disabled:opacity-50',
                    gameState.betType === 'high'
                      ? 'border-osrs-gold bg-osrs-gold/20 text-osrs-gold'
                      : 'border-osrs-gold/30 bg-black/50 text-gray-400 hover:border-osrs-gold/60'
                  )}
                >
                  HIGH (4-6) - 2x Payout
                </button>
                <button
                  onClick={() => setGameState((prev) => ({ ...prev, betType: 'low' }))}
                  disabled={gameState.gameStatus !== 'idle'}
                  className={cn(
                    'w-full py-2 rounded-sm border-2 font-bold transition-colors disabled:opacity-50',
                    gameState.betType === 'low'
                      ? 'border-osrs-gold bg-osrs-gold/20 text-osrs-gold'
                      : 'border-osrs-gold/30 bg-black/50 text-gray-400 hover:border-osrs-gold/60'
                  )}
                >
                  LOW (1-3) - 2x Payout
                </button>
                <button
                  onClick={() => setGameState((prev) => ({ ...prev, betType: 'odd' }))}
                  disabled={gameState.gameStatus !== 'idle'}
                  className={cn(
                    'w-full py-2 rounded-sm border-2 font-bold transition-colors disabled:opacity-50',
                    gameState.betType === 'odd'
                      ? 'border-osrs-gold bg-osrs-gold/20 text-osrs-gold'
                      : 'border-osrs-gold/30 bg-black/50 text-gray-400 hover:border-osrs-gold/60'
                  )}
                >
                  ODD - 2x Payout
                </button>
                <button
                  onClick={() => setGameState((prev) => ({ ...prev, betType: 'even' }))}
                  disabled={gameState.gameStatus !== 'idle'}
                  className={cn(
                    'w-full py-2 rounded-sm border-2 font-bold transition-colors disabled:opacity-50',
                    gameState.betType === 'even'
                      ? 'border-osrs-gold bg-osrs-gold/20 text-osrs-gold'
                      : 'border-osrs-gold/30 bg-black/50 text-gray-400 hover:border-osrs-gold/60'
                  )}
                >
                  EVEN - 2x Payout
                </button>
              </div>
            </div>

            {/* Bet Amount */}
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">BET AMOUNT</label>
              <input
                type="number"
                value={gameState.betAmount}
                onChange={(e) =>
                  setGameState((prev) => ({
                    ...prev,
                    betAmount: Math.min(10000, Math.max(10, parseInt(e.target.value) || 10)),
                  }))
                }
                disabled={gameState.gameStatus !== 'idle'}
                className="w-full bg-black/50 border border-yellow-600/30 text-white px-3 py-2 rounded-sm"
              />
            </div>

            {/* Recent Rolls */}
            {gameState.history.length > 0 && (
              <div>
                <p className="text-osrs-gold font-bold text-sm mb-2">RECENT ROLLS</p>
                <div className="grid grid-cols-5 gap-2">
                  {gameState.history.map((roll, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        'p-2 rounded-sm border-2 text-center font-bold',
                        roll.won
                          ? 'border-green-600 bg-green-600/10 text-green-400'
                          : 'border-red-600 bg-red-600/10 text-red-400'
                      )}
                    >
                      {roll.result}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton onClick={handleRoll} disabled={wallet.placeBetLoading} className="flex-1">
            {wallet.placeBetLoading ? 'PLACING BET...' : 'ROLL DICE'}
          </OSRSButton>
        )}
        {gameState.gameStatus === 'finished' && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            ROLL AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
