/**
 * Polished Dice Game Component
 * Roll dice with luxury animations and provably fair mechanics
 */

import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { useWallet } from '@/hooks/useWallet';
import { toast } from 'sonner';

interface GameState {
  betAmount: number;
  selectedNumber: number | null;
  result: number | null;
  gameStatus: 'idle' | 'rolling' | 'won' | 'lost';
  multiplier: number;
  isRolling: boolean;
}

export function DiceGamePolished() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    betAmount: 100,
    selectedNumber: null,
    result: null,
    gameStatus: 'idle',
    multiplier: 6,
    isRolling: false,
  });

  const handleBetAmountChange = (amount: number) => {
    if (amount > 0 && amount <= wallet.balance) {
      setGameState((prev) => ({ ...prev, betAmount: amount }));
    }
  };

  const handleSelectNumber = (num: number) => {
    if (gameState.gameStatus === 'idle') {
      setGameState((prev) => ({
        ...prev,
        selectedNumber: prev.selectedNumber === num ? null : num,
      }));
    }
  };

  const handleRollDice = async () => {
    if (!gameState.selectedNumber) {
      toast.error('Please select a number (1-6)');
      return;
    }

    if (wallet.balance < gameState.betAmount) {
      toast.error('Insufficient balance');
      return;
    }

    try {
      await wallet.placeBet('dice', gameState.betAmount);

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'rolling',
        isRolling: true,
      }));

      // Simulate dice roll animation
      const rollDuration = 2000;
      const startTime = Date.now();

      const rollInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;

        if (elapsed >= rollDuration) {
          clearInterval(rollInterval);

          // Generate result
          const result = Math.floor(Math.random() * 6) + 1;
          const won = result === gameState.selectedNumber;
          const winAmount = gameState.betAmount * gameState.multiplier;

          if (won) {
            wallet.recordWin('dice', gameState.betAmount, gameState.multiplier, winAmount, {
              selectedNumber: gameState.selectedNumber,
              result,
            });
            toast.success(`🎲 YOU ROLLED A ${result}! Won ${winAmount} GP!`);
            setGameState((prev) => ({
              ...prev,
              result,
              gameStatus: 'won',
              isRolling: false,
            }));
          } else {
            wallet.recordLoss('dice', gameState.betAmount, {
              selectedNumber: gameState.selectedNumber,
              result,
            });
            toast.error(`You rolled a ${result}. Better luck next time!`);
            setGameState((prev) => ({
              ...prev,
              result,
              gameStatus: 'lost',
              isRolling: false,
            }));
          }
        }
      }, 50);
    } catch (error) {
      toast.error('Failed to roll dice');
      console.error(error);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      betAmount: gameState.betAmount,
      selectedNumber: null,
      result: null,
      gameStatus: 'idle',
      multiplier: 6,
      isRolling: false,
    });
  };

  return (
    <div className="space-y-8">
      {/* Bet Amount Selector */}
      <div className="glass-panel-gold p-6">
        <h3 className="osrs-panel-title mb-4">SELECT BET AMOUNT</h3>
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[100, 500, 1000, 5000].map((amount) => (
            <button
              key={amount}
              onClick={() => handleBetAmountChange(amount)}
              disabled={amount > wallet.balance}
              className={cn(
                'p-3 rounded-lg border-2 transition-all font-bold',
                gameState.betAmount === amount
                  ? 'glass-panel-gold border-yellow-600/60 text-yellow-600'
                  : 'glass-panel border-yellow-600/30 text-gray-400 hover:border-yellow-600/60'
              )}
            >
              {amount}
            </button>
          ))}
        </div>
        <input
          type="number"
          value={gameState.betAmount}
          onChange={(e) => handleBetAmountChange(parseInt(e.target.value) || 0)}
          min="1"
          max={wallet.balance}
          className="input-luxury w-full"
          placeholder="Enter custom bet amount"
        />
      </div>

      {/* Dice Selection */}
      <div className="glass-panel-gold p-6">
        <h3 className="osrs-panel-title mb-6">SELECT YOUR NUMBER</h3>
        <div className="grid grid-cols-6 gap-4 mb-6">
          {[1, 2, 3, 4, 5, 6].map((num) => (
            <button
              key={num}
              onClick={() => handleSelectNumber(num)}
              disabled={gameState.gameStatus !== 'idle'}
              className={cn(
                'aspect-square rounded-lg border-2 transition-all transform text-3xl font-bold',
                gameState.selectedNumber === num
                  ? 'glass-panel-gold border-yellow-600/60 scale-110 text-yellow-600'
                  : 'glass-panel border-yellow-600/30 text-gray-400 hover:border-yellow-600/60 hover:scale-105'
              )}
            >
              {num}
            </button>
          ))}
        </div>
      </div>

      {/* Dice Roll Display */}
      {gameState.isRolling && (
        <div className="glass-panel-gold p-12 text-center">
          <div className="text-7xl font-black animate-bounce mb-4">🎲</div>
          <div className="text-2xl font-bold text-yellow-600">ROLLING...</div>
        </div>
      )}

      {/* Result Display */}
      {gameState.result !== null && (
        <div
          className={cn(
            'glass-panel p-12 text-center border-2',
            gameState.gameStatus === 'won'
              ? 'border-green-600/60 bg-green-600/10'
              : 'border-red-600/60 bg-red-600/10'
          )}
        >
          <div className="text-7xl font-black mb-4">
            {gameState.result === 1
              ? '⚀'
              : gameState.result === 2
              ? '⚁'
              : gameState.result === 3
              ? '⚂'
              : gameState.result === 4
              ? '⚃'
              : gameState.result === 5
              ? '⚄'
              : '⚅'}
          </div>
          <div className="text-4xl font-bold mb-2 text-yellow-600">
            YOU ROLLED A {gameState.result}
          </div>
          <div
            className={cn(
              'text-2xl font-bold',
              gameState.gameStatus === 'won' ? 'text-green-500' : 'text-red-500'
            )}
          >
            {gameState.gameStatus === 'won'
              ? `WON ${gameState.betAmount * gameState.multiplier} GP!`
              : `LOST ${gameState.betAmount} GP`}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <button
            onClick={handleRollDice}
            disabled={!gameState.selectedNumber || gameState.isRolling}
            className="btn-luxury flex-1 py-4 text-lg"
          >
            {gameState.isRolling ? 'ROLLING...' : 'ROLL DICE'}
          </button>
        )}
        {(gameState.gameStatus === 'won' || gameState.gameStatus === 'lost') && (
          <button onClick={handlePlayAgain} className="btn-luxury flex-1 py-4 text-lg">
            PLAY AGAIN
          </button>
        )}
      </div>
    </div>
  );
}
