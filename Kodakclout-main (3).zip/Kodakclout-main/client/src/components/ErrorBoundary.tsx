import React, { ReactNode } from 'react';
import { GuardianOverlay } from './GuardianOverlay';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary - Catches unhandled React errors and displays GuardianOverlay
 * Prevents stack traces from leaking to the client in production
 */
export default class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('[ErrorBoundary]', error, errorInfo);
    }
    
    // In production, send sanitized error to server for monitoring
    if (process.env.NODE_ENV === 'production') {
      fetch('/api/errors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: 'Client error occurred',
          timestamp: new Date().toISOString(),
        }),
      }).catch(() => {
        // Silently fail if error logging fails
      });
    }
  }

  handleReconnect = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return <GuardianOverlay onReconnect={this.handleReconnect} />;
    }

    return this.props.children;
  }
}
