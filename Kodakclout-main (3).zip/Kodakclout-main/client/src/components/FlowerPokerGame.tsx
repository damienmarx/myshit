/**
 * Flower Poker Game Component
 * 5x5 grid with 8 flower types, planting animations, and win condition logic
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox, OSRSProgressBar } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

type FlowerType = 'red' | 'blue' | 'yellow' | 'purple' | 'orange' | 'rainbow' | 'black' | 'white' | null;

interface GridCell {
  flower: FlowerType;
  isAnimating: boolean;
}

interface GameState {
  grid: GridCell[][];
  selectedFlower: FlowerType;
  betAmount: number;
  potentialWin: number;
  gameStatus: 'idle' | 'playing' | 'won' | 'lost';
}

const FLOWER_COLORS: Record<string, string> = {
  red: '#DC143C',
  blue: '#4169E1',
  yellow: '#FFD700',
  purple: '#9370DB',
  orange: '#FF8C00',
  rainbow: 'linear-gradient(45deg, #DC143C, #FFD700, #4169E1)',
  black: '#1a1a1a',
  white: '#FFFFFF',
};

const FLOWER_EMOJIS: Record<string, string> = {
  red: '🌹',
  blue: '🌺',
  yellow: '🌻',
  purple: '🌷',
  orange: '🧡',
  rainbow: '🌈',
  black: '🖤',
  white: '🤍',
};

/**
 * Check for winning patterns (5 in a row horizontally, vertically, or diagonally)
 */
function checkWinCondition(grid: GridCell[][]): boolean {
  const size = 5;

  // Check horizontal
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size - 4; col++) {
      const flower = grid[row][col].flower;
      if (flower && grid[row].slice(col, col + 5).every((cell) => cell.flower === flower)) {
        return true;
      }
    }
  }

  // Check vertical
  for (let col = 0; col < size; col++) {
    for (let row = 0; row < size - 4; row++) {
      const flower = grid[row][col].flower;
      if (
        flower &&
        Array.from({ length: 5 }).every((_, i) => grid[row + i][col].flower === flower)
      ) {
        return true;
      }
    }
  }

  // Check diagonal (top-left to bottom-right)
  for (let row = 0; row < size - 4; row++) {
    for (let col = 0; col < size - 4; col++) {
      const flower = grid[row][col].flower;
      if (
        flower &&
        Array.from({ length: 5 }).every((_, i) => grid[row + i][col + i].flower === flower)
      ) {
        return true;
      }
    }
  }

  // Check diagonal (top-right to bottom-left)
  for (let row = 0; row < size - 4; row++) {
    for (let col = 4; col < size; col++) {
      const flower = grid[row][col].flower;
      if (
        flower &&
        Array.from({ length: 5 }).every((_, i) => grid[row + i][col - i].flower === flower)
      ) {
        return true;
      }
    }
  }

  return false;
}

export function FlowerPokerGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    grid: Array(5)
      .fill(null)
      .map(() => Array(5).fill({ flower: null, isAnimating: false })),
    selectedFlower: 'red',
    betAmount: 100,
    potentialWin: 0,
    gameStatus: 'idle',
  });

  const flowerTypes: FlowerType[] = ['red', 'blue', 'yellow', 'purple', 'orange', 'rainbow', 'black', 'white'];

  const handleCellClick = (row: number, col: number) => {
    if (gameState.gameStatus !== 'playing' || gameState.grid[row][col].flower !== null) {
      return;
    }

    const newGrid = gameState.grid.map((r) => [...r]);
    newGrid[row][col] = { flower: gameState.selectedFlower, isAnimating: true };

    // Remove animation class after animation completes
    setTimeout(() => {
      setGameState((prev) => ({
        ...prev,
        grid: newGrid.map((r) =>
          r.map((cell) => ({ ...cell, isAnimating: false }))
        ),
      }));
    }, 600);

    // Check win condition
    if (checkWinCondition(newGrid)) {
      setGameState((prev) => ({
        ...prev,
        grid: newGrid,
        gameStatus: 'won',
        potentialWin: prev.betAmount * 2,
      }));
    } else {
      // Check if grid is full
      const isFull = newGrid.every((row) => row.every((cell) => cell.flower !== null));
      if (isFull) {
        setGameState((prev) => ({
          ...prev,
          grid: newGrid,
          gameStatus: 'lost',
        }));
      } else {
        setGameState((prev) => ({
          ...prev,
          grid: newGrid,
        }));
      }
    }
  };

  const handleStartGame = async () => {
    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('flower_poker', gameState.betAmount);
      toast.success(`Bet placed: ${gameState.betAmount} GP`);

      setGameState({
        grid: Array(5)
          .fill(null)
          .map(() => Array(5).fill({ flower: null, isAnimating: false })),
        selectedFlower: 'red',
        betAmount: 100,
        potentialWin: 0,
        gameStatus: 'playing',
      });
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
    }
  };

  const handleCashOut = async () => {
    try {
      if (gameState.gameStatus === 'won') {
        // Record win
        const multiplier = gameState.potentialWin / gameState.betAmount;
        await wallet.recordWin('flower_poker', gameState.betAmount, multiplier, gameState.potentialWin, {
          grid: gameState.grid,
          selectedFlower: gameState.selectedFlower,
        });
        toast.success(`Won ${gameState.potentialWin} GP! 🎉`);
      } else if (gameState.gameStatus === 'lost') {
        // Record loss
        await wallet.recordLoss('flower_poker', gameState.betAmount, {
          grid: gameState.grid,
          selectedFlower: gameState.selectedFlower,
        });
        toast.info(`Lost ${gameState.betAmount} GP`);
      }

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'idle',
      }));
    } catch (error) {
      toast.error('Failed to record game result');
      console.error(error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Balance" value={`${wallet.balance} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Potential Win" value={`${gameState.potentialWin} GP`} highlight={gameState.gameStatus === 'won'} />
        <OSRSStatBox label="Status" value={gameState.gameStatus.toUpperCase()} />
      </div>

      {/* Game Grid */}
      <OSRSPanel title="FLOWER POKER GRID">
        <div className="grid grid-cols-5 gap-2 mb-6">
          {gameState.grid.map((row, rowIdx) =>
            row.map((cell, colIdx) => (
              <button
                key={`${rowIdx}-${colIdx}`}
                onClick={() => handleCellClick(rowIdx, colIdx)}
                disabled={gameState.gameStatus !== 'playing' || cell.flower !== null}
                className={cn(
                  'aspect-square rounded-sm border-2 border-yellow-600/50 transition-all duration-300',
                  'hover:border-yellow-600 hover:shadow-lg',
                  'disabled:cursor-not-allowed disabled:opacity-75',
                  cell.isAnimating && 'animate-bounce',
                  cell.flower ? 'bg-black/80' : 'bg-black/40'
                )}
                style={{
                  background: cell.flower ? FLOWER_COLORS[cell.flower] : 'rgba(0,0,0,0.4)',
                }}
              >
                <span className="text-2xl">{cell.flower ? FLOWER_EMOJIS[cell.flower] : '❌'}</span>
              </button>
            ))
          )}
        </div>

        {/* Flower Selection */}
        <div className="mb-6">
          <p className="text-yellow-600 font-bold mb-3">SELECT FLOWER TYPE</p>
          <div className="grid grid-cols-4 gap-2">
            {flowerTypes.map((flower) => (
              <button
                key={flower}
                onClick={() => setGameState((prev) => ({ ...prev, selectedFlower: flower as FlowerType }))}
                className={cn(
                  'p-3 rounded-sm border-2 transition-all',
                  gameState.selectedFlower === flower
                    ? 'border-yellow-600 bg-yellow-600/20'
                    : 'border-yellow-600/30 bg-black/40 hover:border-yellow-600/60'
                )}
              >
                <span className="text-2xl block">{FLOWER_EMOJIS[flower as string] || ''}</span>
                <span className="text-xs text-gray-400 capitalize">{flower}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Progress Bar */}
        <OSRSProgressBar
          value={gameState.grid.flat().filter((cell) => cell.flower !== null).length}
          max={25}
          label="Grid Filled"
          showPercent
        />
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton onClick={handleStartGame} disabled={wallet.placeBetLoading} className="flex-1">
            {wallet.placeBetLoading ? 'PLACING BET...' : 'START GAME'}
          </OSRSButton>
        )}
        {gameState.gameStatus === 'playing' && (
          <OSRSButton onClick={handleCashOut} variant="crimson" disabled={wallet.recordLossLoading} className="flex-1">
            {wallet.recordLossLoading ? 'PROCESSING...' : 'CASH OUT'}
          </OSRSButton>
        )}
        {gameState.gameStatus === 'won' && (
          <>
            <OSRSButton onClick={handleStartGame} disabled={wallet.placeBetLoading} className="flex-1">
              {wallet.placeBetLoading ? 'PLACING BET...' : 'PLAY AGAIN'}
            </OSRSButton>
            <OSRSButton onClick={handleCashOut} variant="gold" disabled={wallet.recordWinLoading} className="flex-1">
              {wallet.recordWinLoading ? 'COLLECTING...' : 'COLLECT WINNINGS'}
            </OSRSButton>
          </>
        )}
        {gameState.gameStatus === 'lost' && (
          <OSRSButton onClick={handleStartGame} disabled={wallet.placeBetLoading} className="flex-1">
            {wallet.placeBetLoading ? 'PLACING BET...' : 'TRY AGAIN'}
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
