/**
 * Global Chat Component
 * Real-time chat with multiple channels, user presence, and moderation
 */

import React, { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { Send, Users, MessageCircle, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface ChatMessage {
  id: number;
  userId: number;
  username: string;
  message: string;
  channel: 'lobby' | 'game';
  gameId?: number;
  createdAt: string;
  isOwn?: boolean;
}

interface ChatUser {
  id: number;
  username: string;
  status: 'online' | 'away' | 'offline';
}

const CHANNELS = [
  { id: 'lobby', name: 'Lobby', icon: '🎮' },
  { id: 'game', name: 'Game Chat', icon: '💬' },
];

export function GlobalChat() {
  const [activeChannel, setActiveChannel] = useState<'lobby' | 'game'>('lobby');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [onlineUsers, setOnlineUsers] = useState<ChatUser[]>([]);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load initial messages
  useEffect(() => {
    loadMessages();
    loadOnlineUsers();

    // Simulate real-time updates
    const interval = setInterval(() => {
      loadMessages();
    }, 2000);

    return () => clearInterval(interval);
  }, [activeChannel]);

  const loadMessages = async () => {
    try {
      setLoading(true);
      // Simulated message data - in production, this would be from tRPC
      const mockMessages: ChatMessage[] = [
        {
          id: 1,
          userId: 1,
          username: 'DegenKing',
          message: 'Just won 50k on Flower Poker! 🌹',
          channel: activeChannel,
          createdAt: new Date(Date.now() - 300000).toISOString(),
        },
        {
          id: 2,
          userId: 2,
          username: 'LuckyStrike',
          message: 'Anyone want to play Crash?',
          channel: activeChannel,
          createdAt: new Date(Date.now() - 180000).toISOString(),
        },
        {
          id: 3,
          userId: 3,
          username: 'You',
          message: 'Let\'s go! 💥',
          channel: activeChannel,
          createdAt: new Date(Date.now() - 60000).toISOString(),
          isOwn: true,
        },
        {
          id: 4,
          userId: 4,
          username: 'FlowerMaster',
          message: 'Rain event in 5 minutes! Get ready! 🌧️',
          channel: activeChannel,
          createdAt: new Date(Date.now() - 30000).toISOString(),
        },
      ];

      setMessages(mockMessages);
    } catch (error) {
      toast.error('Failed to load messages');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const loadOnlineUsers = async () => {
    try {
      // Simulated online users - in production, this would be from tRPC
      const mockUsers: ChatUser[] = [
        { id: 1, username: 'DegenKing', status: 'online' },
        { id: 2, username: 'LuckyStrike', status: 'online' },
        { id: 3, username: 'You', status: 'online' },
        { id: 4, username: 'FlowerMaster', status: 'online' },
        { id: 5, username: 'CrashMaster', status: 'away' },
      ];

      setOnlineUsers(mockUsers);
    } catch (error) {
      console.error('Failed to load online users', error);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!inputValue.trim()) {
      toast.error('Message cannot be empty');
      return;
    }

    if (inputValue.length > 500) {
      toast.error('Message is too long (max 500 characters)');
      return;
    }

    try {
      // Add message optimistically
      const newMessage: ChatMessage = {
        id: messages.length + 1,
        userId: 3,
        username: 'You',
        message: inputValue,
        channel: activeChannel,
        createdAt: new Date().toISOString(),
        isOwn: true,
      };

      setMessages((prev) => [...prev, newMessage]);
      setInputValue('');

      // In production, this would be a tRPC call
      // await trpc.chat.sendMessage.mutate({
      //   message: inputValue,
      //   channel: activeChannel,
      // });

      toast.success('Message sent');
    } catch (error) {
      toast.error('Failed to send message');
      console.error(error);
    }
  };

  const handleDeleteMessage = (messageId: number) => {
    setMessages((prev) => prev.filter((msg) => msg.id !== messageId));
    toast.success('Message deleted');
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="glass-panel-gold border-b-2 border-yellow-600/30 px-4 md:px-6 py-4 sticky top-0 z-20">
        <h1 className="text-2xl md:text-3xl font-bold text-gradient-gold">💬 Global Chat</h1>
        <p className="text-sm text-gray-400 mt-1">Connect with the community in real-time</p>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex gap-4 overflow-hidden p-4 md:p-6">
        {/* Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Channel Tabs */}
          <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
            {CHANNELS.map((channel) => (
              <button
                key={channel.id}
                onClick={() => setActiveChannel(channel.id as 'lobby' | 'game')}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all whitespace-nowrap',
                  activeChannel === channel.id
                    ? 'glass-panel-gold border-yellow-600/60 text-yellow-600'
                    : 'glass-panel border-yellow-600/30 text-gray-400 hover:border-yellow-600/60'
                )}
              >
                <span>{channel.icon}</span>
                <span className="font-semibold">{channel.name}</span>
              </button>
            ))}
          </div>

          {/* Messages Container */}
          <div className="flex-1 glass-panel-gold p-4 md:p-6 overflow-y-auto space-y-3 min-h-0">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-gray-400">Loading messages...</div>
              </div>
            ) : messages.length === 0 ? (
              <div className="flex items-center justify-center h-full text-gray-400">
                No messages yet. Start the conversation!
              </div>
            ) : (
              <>
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={cn(
                      'flex gap-3 p-3 rounded-lg transition-all',
                      msg.isOwn
                        ? 'bg-yellow-600/10 border-l-2 border-yellow-600'
                        : 'bg-black/30 border-l-2 border-yellow-600/30'
                    )}
                  >
                    {/* Avatar */}
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-gradient-to-br from-yellow-600 to-yellow-800 flex items-center justify-center flex-shrink-0 text-xs md:text-sm font-bold text-black">
                      {msg.username.charAt(0).toUpperCase()}
                    </div>

                    {/* Message Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-yellow-600 text-sm md:text-base">
                            {msg.username}
                          </span>
                          <span className="text-xs text-gray-500">
                            {new Date(msg.createdAt).toLocaleTimeString()}
                          </span>
                        </div>

                        {msg.isOwn && (
                          <button
                            onClick={() => handleDeleteMessage(msg.id)}
                            className="p-1 hover:bg-red-600/20 rounded transition text-red-500 hover:text-red-400"
                            title="Delete message"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <p className="text-gray-200 text-sm md:text-base break-words mt-1">
                        {msg.message}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Input Area */}
          <form onSubmit={handleSendMessage} className="mt-4 flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Type your message... (max 500 characters)"
              maxLength={500}
              className="input-luxury flex-1 text-sm md:text-base"
            />
            <button
              type="submit"
              className="btn-luxury px-4 md:px-6 py-2 md:py-3 flex items-center gap-2 text-sm md:text-base"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </form>

          {/* Character Counter */}
          <div className="text-xs text-gray-500 mt-2">
            {inputValue.length}/500 characters
          </div>
        </div>

        {/* Online Users Sidebar - Hidden on Mobile */}
        <div className="hidden lg:flex lg:w-64 flex-col">
          <div className="glass-panel-gold p-4 md:p-6 rounded-lg flex-1 overflow-y-auto">
            <div className="flex items-center gap-2 mb-4">
              <Users className="w-5 h-5 text-yellow-600" />
              <h3 className="osrs-panel-title text-lg">Online ({onlineUsers.length})</h3>
            </div>

            <div className="space-y-2">
              {onlineUsers.map((user) => (
                <div
                  key={user.id}
                  className="p-3 rounded-lg bg-black/40 border border-yellow-600/20 hover:border-yellow-600/40 transition"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        'w-2 h-2 rounded-full',
                        user.status === 'online'
                          ? 'bg-green-500'
                          : user.status === 'away'
                          ? 'bg-yellow-500'
                          : 'bg-gray-500'
                      )}
                    />
                    <span className="text-sm font-semibold text-gray-300 truncate">
                      {user.username}
                    </span>
                  </div>
                  <span className="text-xs text-gray-500 ml-4">
                    {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
