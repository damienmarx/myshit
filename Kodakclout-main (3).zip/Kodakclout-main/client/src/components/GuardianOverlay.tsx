/**
 * GuardianOverlay - Branded error mask that hides stack traces and technical details
 * Presents errors as "SYSTEM CALIBRATION" messages to maintain immersion
 */

interface GuardianOverlayProps {
  error?: Error | string;
  onReconnect?: () => void;
}

export function GuardianOverlay({ error, onReconnect }: GuardianOverlayProps) {
  const generateRefId = () => {
    return `NF-${Math.random().toString(36).substring(2, 9).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
  };

  const handleReconnect = () => {
    if (onReconnect) {
      onReconnect();
    } else {
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 z-[999] bg-black/95 backdrop-blur-md flex items-center justify-center">
      <div className="p-8 border-t-4 border-b-4 border-yellow-600 bg-gradient-to-br from-gray-900 to-black shadow-lg text-center max-w-md">
        {/* Header */}
        <h2 className="text-yellow-600 font-black tracking-widest text-2xl mb-2">
          SYSTEM CALIBRATION
        </h2>
        <div className="h-1 w-24 bg-gradient-to-r from-yellow-600 to-red-700 mx-auto mb-6"></div>

        {/* Message */}
        <p className="text-gray-300 font-medium mb-2">
          The CloutScape Engine is optimizing your connection.
        </p>
        <p className="text-gray-500 text-sm mb-6">
          This is a temporary disruption. Please stand by.
        </p>

        {/* Reference ID - Animated */}
        <div className="mt-6 animate-pulse">
          <p className="text-red-600 text-xs font-mono tracking-wider">
            REF_ID: {generateRefId()}
          </p>
        </div>

        {/* Reconnect Button */}
        <button
          onClick={handleReconnect}
          className="mt-8 px-6 py-2 bg-yellow-600 text-black font-bold rounded-sm transition-all hover:bg-yellow-500 active:bg-yellow-700 shadow-lg"
          style={{
            textShadow: '1px 1px 2px rgba(0, 0, 0, 0.5)',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)',
          }}
        >
          RECONNECT
        </button>

        {/* Decorative elements */}
        <div className="mt-8 flex justify-center gap-2">
          <div className="w-2 h-2 bg-yellow-600 rounded-full animate-bounce"></div>
          <div className="w-2 h-2 bg-yellow-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          <div className="w-2 h-2 bg-yellow-600 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
        </div>
      </div>
    </div>
  );
}
