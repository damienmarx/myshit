/**
 * Hot & Cold Game Component
 * Simple 50/50 chance game with provably fair mechanics
 */

import React, { useState } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { toast } from 'sonner';

interface GameState {
  betAmount: number;
  selectedChoice: 'hot' | 'cold' | null;
  result: 'hot' | 'cold' | null;
  gameStatus: 'idle' | 'playing' | 'won' | 'lost';
  multiplier: number;
}

export function HotColdGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    betAmount: 100,
    selectedChoice: null,
    result: null,
    gameStatus: 'idle',
    multiplier: 2,
  });

  const handleBetAmountChange = (amount: number) => {
    if (amount > 0 && amount <= wallet.balance) {
      setGameState((prev) => ({ ...prev, betAmount: amount }));
    }
  };

  const handleSelectChoice = (choice: 'hot' | 'cold') => {
    if (gameState.gameStatus === 'idle') {
      setGameState((prev) => ({ ...prev, selectedChoice: choice }));
    }
  };

  const handlePlayGame = async () => {
    if (!gameState.selectedChoice) {
      toast.error('Please select HOT or COLD');
      return;
    }

    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('hot_cold', gameState.betAmount);

      // Simulate game result (50/50)
      const result = Math.random() > 0.5 ? 'hot' : 'cold';
      const won = result === gameState.selectedChoice;

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'playing',
      }));

      // Delay reveal for dramatic effect
      setTimeout(async () => {
        if (won) {
          const winAmount = gameState.betAmount * gameState.multiplier;
          await wallet.recordWin('hot_cold', gameState.betAmount, gameState.multiplier, winAmount, {
            choice: gameState.selectedChoice,
            result,
          });
          toast.success(`🔥 HOT WIN! You won ${winAmount} GP!`);
          setGameState((prev) => ({
            ...prev,
            result,
            gameStatus: 'won',
          }));
        } else {
          await wallet.recordLoss('hot_cold', gameState.betAmount, {
            choice: gameState.selectedChoice,
            result,
          });
          toast.error(`❄️ COLD LOSS! The result was ${result.toUpperCase()}`);
          setGameState((prev) => ({
            ...prev,
            result,
            gameStatus: 'lost',
          }));
        }
      }, 1500);
    } catch (error) {
      toast.error('Failed to play game');
      console.error(error);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      betAmount: gameState.betAmount,
      selectedChoice: null,
      result: null,
      gameStatus: 'idle',
      multiplier: 2,
    });
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-3 gap-4">
        <OSRSStatBox label="Balance" value={`${wallet.balance} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Multiplier" value={`${gameState.multiplier}x`} />
      </div>

      {/* Bet Amount Selector */}
      <OSRSPanel title="SELECT BET AMOUNT">
        <div className="grid grid-cols-4 gap-2 mb-4">
          {[100, 500, 1000, 5000].map((amount) => (
            <button
              key={amount}
              onClick={() => handleBetAmountChange(amount)}
              disabled={amount > wallet.balance}
              className={`p-3 rounded-sm border-2 transition-all font-bold ${
                gameState.betAmount === amount
                  ? 'border-yellow-600 bg-yellow-600/20 text-yellow-600'
                  : 'border-yellow-600/30 bg-black/40 text-gray-400 hover:border-yellow-600/60'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {amount}
            </button>
          ))}
        </div>
        <input
          type="number"
          value={gameState.betAmount}
          onChange={(e) => handleBetAmountChange(parseInt(e.target.value) || 0)}
          min="1"
          max={wallet.balance}
          className="w-full p-2 rounded-sm bg-black/60 border-2 border-yellow-600/30 text-white placeholder-gray-600 focus:border-yellow-600 focus:outline-none"
          placeholder="Enter custom bet amount"
        />
      </OSRSPanel>

      {/* Game Choices */}
      <OSRSPanel title="CHOOSE YOUR PREDICTION">
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* HOT Button */}
          <button
            onClick={() => handleSelectChoice('hot')}
            disabled={gameState.gameStatus !== 'idle'}
            className={`p-8 rounded-lg border-4 transition-all transform ${
              gameState.selectedChoice === 'hot'
                ? 'border-red-600 bg-red-600/20 scale-105'
                : 'border-red-600/30 bg-black/40 hover:border-red-600/60'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <div className="text-6xl mb-3">🔥</div>
            <div className="text-2xl font-bold text-red-500">HOT</div>
            <div className="text-xs text-gray-400 mt-2">50% Chance</div>
          </button>

          {/* COLD Button */}
          <button
            onClick={() => handleSelectChoice('cold')}
            disabled={gameState.gameStatus !== 'idle'}
            className={`p-8 rounded-lg border-4 transition-all transform ${
              gameState.selectedChoice === 'cold'
                ? 'border-blue-600 bg-blue-600/20 scale-105'
                : 'border-blue-600/30 bg-black/40 hover:border-blue-600/60'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <div className="text-6xl mb-3">❄️</div>
            <div className="text-2xl font-bold text-blue-500">COLD</div>
            <div className="text-xs text-gray-400 mt-2">50% Chance</div>
          </button>
        </div>

        {/* Result Display */}
        {gameState.result && (
          <div className={`p-6 rounded-lg text-center mb-6 ${
            gameState.gameStatus === 'won'
              ? 'bg-green-600/20 border-2 border-green-600'
              : 'bg-red-600/20 border-2 border-red-600'
          }`}>
            <div className="text-4xl mb-3">{gameState.result === 'hot' ? '🔥' : '❄️'}</div>
            <div className={`text-2xl font-bold ${gameState.gameStatus === 'won' ? 'text-green-500' : 'text-red-500'}`}>
              {gameState.result.toUpperCase()}
            </div>
            <div className="text-sm text-gray-400 mt-2">
              {gameState.gameStatus === 'won' ? 'YOU WON!' : 'YOU LOST!'}
            </div>
          </div>
        )}
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton
            onClick={handlePlayGame}
            disabled={!gameState.selectedChoice || wallet.placeBetLoading}
            className="flex-1"
          >
            {wallet.placeBetLoading ? 'PLACING BET...' : 'PLAY NOW'}
          </OSRSButton>
        )}
        {(gameState.gameStatus === 'won' || gameState.gameStatus === 'lost') && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
