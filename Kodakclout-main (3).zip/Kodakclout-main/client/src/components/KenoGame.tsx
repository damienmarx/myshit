/**
 * Keno Game Component
 * 80-ball Keno with ticket selection and real-time drawing
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox, OSRSProgressBar } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { Trophy, RefreshCw, Lock } from 'lucide-react';
import { toast } from 'sonner';

interface KenoGameState {
  selectedNumbers: number[];
  drawnNumbers: number[];
  betAmount: number;
  potentialWin: number;
  gameStatus: 'idle' | 'playing' | 'drawing' | 'finished';
  matches: number;
  multiplier: number;
}

const KENO_MULTIPLIERS: Record<number, number> = {
  1: 1,
  2: 1.5,
  3: 2,
  4: 3,
  5: 5,
  6: 10,
  7: 20,
  8: 50,
  9: 100,
  10: 500,
};

export function KenoGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<KenoGameState>({
    selectedNumbers: [],
    drawnNumbers: [],
    betAmount: 100,
    potentialWin: 0,
    gameStatus: 'idle',
    matches: 0,
    multiplier: 0,
  });

  const handleNumberClick = (number: number) => {
    if (gameState.gameStatus !== 'idle') return;

    setGameState((prev) => {
      const isSelected = prev.selectedNumbers.includes(number);
      const newSelected = isSelected
        ? prev.selectedNumbers.filter((n) => n !== number)
        : prev.selectedNumbers.length < 10
          ? [...prev.selectedNumbers, number]
          : prev.selectedNumbers;

      // Calculate potential win based on matches
      const potentialWin = newSelected.length > 0 ? prev.betAmount * (KENO_MULTIPLIERS[newSelected.length] || 1) : 0;

      return {
        ...prev,
        selectedNumbers: newSelected,
        potentialWin,
      };
    });
  };

  const handlePlayGame = async () => {
    if (gameState.selectedNumbers.length === 0) return;

    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('hot_cold', gameState.betAmount);
      toast.success(`Bet placed: ${gameState.betAmount} GP`);
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
      return;
    }

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'drawing',
      drawnNumbers: [],
    }));

    // Simulate drawing numbers one by one
    const drawn: number[] = [];
    const allNumbers = Array.from({ length: 40 }, (_, i) => i + 1);

    for (let i = 0; i < 20; i++) {
      await new Promise((resolve) => setTimeout(resolve, 300));

      const randomIndex = Math.floor(Math.random() * allNumbers.length);
      const drawnNumber = allNumbers[randomIndex];
      allNumbers.splice(randomIndex, 1);
      drawn.push(drawnNumber);

      const matches = gameState.selectedNumbers.filter((n) => drawn.includes(n)).length;
      const multiplier = KENO_MULTIPLIERS[matches] || 0;

      setGameState((prev) => ({
        ...prev,
        drawnNumbers: drawn,
        matches,
        multiplier,
        potentialWin: prev.betAmount * multiplier,
      }));
    }

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'finished',
    }));

    // Record result after drawing completes
    setTimeout(async () => {
      try {
        if (gameState.matches > 0) {
          const multiplier = KENO_MULTIPLIERS[gameState.matches] || 0;
          await wallet.recordWin('hot_cold', gameState.betAmount, multiplier, gameState.betAmount * multiplier, {
            selectedNumbers: gameState.selectedNumbers,
            drawnNumbers: drawn,
            matches: gameState.matches,
          });
          toast.success(`Won ${(gameState.betAmount * multiplier).toFixed(0)} GP! 🎉`);
        } else {
          await wallet.recordLoss('hot_cold', gameState.betAmount, {
            selectedNumbers: gameState.selectedNumbers,
            drawnNumbers: drawn,
            matches: 0,
          });
          toast.info(`Lost ${gameState.betAmount} GP`);
        }
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }, 100);
  };

  const handlePlayAgain = () => {
    setGameState({
      selectedNumbers: [],
      drawnNumbers: [],
      betAmount: 100,
      potentialWin: 0,
      gameStatus: 'idle',
      matches: 0,
      multiplier: 0,
    });
  };

  const handleQuickPick = () => {
    const randomNumbers = Array.from({ length: 10 }, () => Math.floor(Math.random() * 40) + 1);
    const potentialWin = gameState.betAmount * (KENO_MULTIPLIERS[10] || 1);

    setGameState((prev) => ({
      ...prev,
      selectedNumbers: randomNumbers,
      potentialWin,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Balance" value={`${wallet.balance} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Potential Win" value={`${gameState.potentialWin.toFixed(0)} GP`} highlight={gameState.matches > 0} />
        <OSRSStatBox label="Matches" value={`${gameState.matches} / ${gameState.selectedNumbers.length}`} />
      </div>

      {/* Keno Grid */}
      <OSRSPanel title="KENO TICKET (SELECT UP TO 10 NUMBERS)">
        <div className="grid grid-cols-8 gap-2 mb-6">
          {Array.from({ length: 40 }, (_, i) => i + 1).map((number) => {
            const isSelected = gameState.selectedNumbers.includes(number);
            const isDrawn = gameState.drawnNumbers.includes(number);
            const isMatch = isSelected && isDrawn;

            return (
              <button
                key={number}
                onClick={() => handleNumberClick(number)}
                disabled={gameState.gameStatus !== 'idle' || (gameState.selectedNumbers.length >= 10 && !isSelected)}
                className={cn(
                  'aspect-square rounded-sm border-2 font-bold text-sm transition-all duration-200',
                  'hover:shadow-lg disabled:cursor-not-allowed',
                  isMatch && 'bg-osrs-gold/30 border-osrs-gold text-osrs-gold animate-pulse',
                  isDrawn && !isMatch && 'bg-gray-600/30 border-gray-600 text-gray-400',
                  isSelected && !isDrawn && 'bg-osrs-gold/20 border-osrs-gold text-osrs-gold',
                  !isSelected && !isDrawn && 'bg-black/40 border-yellow-600/30 hover:border-yellow-600/60'
                )}
              >
                {number}
              </button>
            );
          })}
        </div>

        {/* Bet Controls */}
        <div className="mb-6 space-y-4">
          <div>
            <label className="text-yellow-600 font-bold text-sm block mb-2">BET AMOUNT</label>
            <div className="flex gap-2">
              <input
                type="range"
                min="10"
                max="10000"
                step="10"
                value={gameState.betAmount}
                onChange={(e) =>
                  setGameState((prev) => ({
                    ...prev,
                    betAmount: parseInt(e.target.value),
                    potentialWin: parseInt(e.target.value) * prev.multiplier,
                  }))
                }
                disabled={gameState.gameStatus !== 'idle'}
                className="flex-1"
              />
              <input
                type="number"
                value={gameState.betAmount}
                onChange={(e) =>
                  setGameState((prev) => ({
                    ...prev,
                    betAmount: Math.min(10000, Math.max(10, parseInt(e.target.value) || 10)),
                  }))
                }
                disabled={gameState.gameStatus !== 'idle'}
                className="w-24 bg-black/50 border border-yellow-600/30 text-white px-2 py-1 rounded-sm"
              />
            </div>
          </div>

          {/* Quick Pick */}
          {gameState.gameStatus === 'idle' && (
            <button
              onClick={handleQuickPick}
              className="w-full py-2 bg-black/50 border border-yellow-600/30 text-yellow-600 font-bold rounded-sm hover:bg-black/70 transition-colors"
            >
              QUICK PICK (10 RANDOM)
            </button>
          )}
        </div>

        {/* Progress Bar */}
        {gameState.drawnNumbers.length > 0 && (
          <OSRSProgressBar
            value={gameState.drawnNumbers.length}
            max={20}
            label="Numbers Drawn"
            showPercent
          />
        )}
      </OSRSPanel>

      {/* Results */}
      {gameState.gameStatus === 'finished' && (
        <div className={cn(
          'p-6 rounded-lg border-2',
          gameState.matches >= 5
            ? 'bg-green-600/10 border-green-600 text-green-400'
            : gameState.matches >= 3
              ? 'bg-yellow-600/10 border-yellow-600 text-yellow-400'
              : 'bg-red-600/10 border-red-600 text-red-400'
        )}>
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-6 h-6" />
            <h3 className="text-xl font-bold">
              {gameState.matches >= 5 ? 'BIG WIN!' : gameState.matches >= 3 ? 'NICE WIN!' : 'TRY AGAIN'}
            </h3>
          </div>
          <p className="text-lg font-bold">
            {gameState.matches} Matches × {gameState.multiplier.toFixed(1)}x = {gameState.potentialWin.toFixed(0)} GP
          </p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <>
            <OSRSButton
              onClick={handlePlayGame}
              disabled={gameState.selectedNumbers.length === 0 || wallet.placeBetLoading}
              className="flex-1"
            >
              {wallet.placeBetLoading ? 'PLACING BET...' : `PLAY (${gameState.selectedNumbers.length}/10)`}
            </OSRSButton>
            <OSRSButton onClick={handlePlayAgain} variant="secondary" className="flex-1">
              CLEAR
            </OSRSButton>
          </>
        )}
        {(gameState.gameStatus === 'drawing' || gameState.gameStatus === 'finished') && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
