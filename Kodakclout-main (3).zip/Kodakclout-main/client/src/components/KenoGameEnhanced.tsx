/**
 * Keno Game Component
 * Select up to 10 numbers from 80, with provably fair draw mechanics
 */

import React, { useState } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { toast } from 'sonner';

interface GameState {
  betAmount: number;
  selectedNumbers: Set<number>;
  drawnNumbers: Set<number>;
  matchedNumbers: number;
  gameStatus: 'idle' | 'drawing' | 'won' | 'lost';
  multiplier: number;
  winAmount: number;
}

// Payout multipliers based on matches
const PAYOUT_TABLE: Record<number, number> = {
  0: 0,
  1: 0,
  2: 1,
  3: 2,
  4: 4,
  5: 10,
  6: 20,
  7: 50,
  8: 100,
  9: 200,
  10: 500,
};

export function KenoGameEnhanced() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    betAmount: 100,
    selectedNumbers: new Set(),
    drawnNumbers: new Set(),
    matchedNumbers: 0,
    gameStatus: 'idle',
    multiplier: 1,
    winAmount: 0,
  });

  const handleBetAmountChange = (amount: number) => {
    if (amount > 0 && amount <= wallet.balance) {
      setGameState((prev) => ({ ...prev, betAmount: amount }));
    }
  };

  const handleSelectNumber = (num: number) => {
    if (gameState.gameStatus !== 'idle') return;
    if (gameState.selectedNumbers.size >= 10 && !gameState.selectedNumbers.has(num)) {
      toast.error('Maximum 10 numbers can be selected');
      return;
    }

    const newSelected = new Set(gameState.selectedNumbers);
    if (newSelected.has(num)) {
      newSelected.delete(num);
    } else {
      newSelected.add(num);
    }

    setGameState((prev) => ({
      ...prev,
      selectedNumbers: newSelected,
    }));
  };

  const handleClearSelection = () => {
    setGameState((prev) => ({
      ...prev,
      selectedNumbers: new Set(),
    }));
  };

  const handlePlayKeno = async () => {
    if (gameState.selectedNumbers.size === 0) {
      toast.error('Please select at least 1 number');
      return;
    }

    if (wallet.balance < gameState.betAmount) {
      toast.error('Insufficient balance');
      return;
    }

    try {
      await wallet.placeBet('keno', gameState.betAmount);

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'drawing',
      }));

      // Simulate drawing 20 numbers from 80
      const drawDuration = 2000;
      const startTime = Date.now();
      const drawnNumbers = new Set<number>();

      const drawInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;

        // Draw numbers progressively
        while (drawnNumbers.size < 20) {
          const num = Math.floor(Math.random() * 80) + 1;
          if (!drawnNumbers.has(num)) {
            drawnNumbers.add(num);
          }
        }

        setGameState((prev) => ({
          ...prev,
          drawnNumbers: new Set(drawnNumbers),
        }));

        if (elapsed >= drawDuration) {
          clearInterval(drawInterval);

          // Calculate matches
          let matches = 0;
          gameState.selectedNumbers.forEach((num) => {
            if (drawnNumbers.has(num)) {
              matches++;
            }
          });

          const multiplier = PAYOUT_TABLE[matches] || 0;
          const winAmount = gameState.betAmount * multiplier;
          const won = winAmount > 0;

          if (won) {
            wallet.recordWin('keno', gameState.betAmount, multiplier, winAmount, {
              selectedNumbers: Array.from(gameState.selectedNumbers),
              drawnNumbers: Array.from(drawnNumbers),
              matches,
            });
            toast.success(`🎯 ${matches} MATCHES! Won ${winAmount} GP!`);
          } else {
            wallet.recordLoss('keno', gameState.betAmount, {
              selectedNumbers: Array.from(gameState.selectedNumbers),
              drawnNumbers: Array.from(drawnNumbers),
              matches,
            });
            toast.error(`Only ${matches} matches. Better luck next time!`);
          }

          setGameState((prev) => ({
            ...prev,
            matchedNumbers: matches,
            multiplier,
            winAmount,
            gameStatus: won ? 'won' : 'lost',
          }));
        }
      }, 50);
    } catch (error) {
      toast.error('Failed to play Keno');
      console.error(error);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      betAmount: gameState.betAmount,
      selectedNumbers: new Set(),
      drawnNumbers: new Set(),
      matchedNumbers: 0,
      gameStatus: 'idle',
      multiplier: 1,
      winAmount: 0,
    });
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Balance" value={`${wallet.balance} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Selected" value={`${gameState.selectedNumbers.size}/10`} />
        <OSRSStatBox label="Matches" value={`${gameState.matchedNumbers}`} highlight={gameState.matchedNumbers > 0} />
      </div>

      {/* Bet Amount Selector */}
      <OSRSPanel title="SELECT BET AMOUNT">
        <div className="grid grid-cols-4 gap-2 mb-4">
          {[50, 100, 500, 1000].map((amount) => (
            <button
              key={amount}
              onClick={() => handleBetAmountChange(amount)}
              disabled={amount > wallet.balance}
              className={`p-3 rounded-sm border-2 transition-all font-bold ${
                gameState.betAmount === amount
                  ? 'border-yellow-600 bg-yellow-600/20 text-yellow-600'
                  : 'border-yellow-600/30 bg-black/40 text-gray-400 hover:border-yellow-600/60'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {amount}
            </button>
          ))}
        </div>
      </OSRSPanel>

      {/* Number Selection Grid */}
      <OSRSPanel title="SELECT UP TO 10 NUMBERS (1-80)">
        <div className="grid grid-cols-10 gap-2 mb-6 max-h-96 overflow-y-auto">
          {Array.from({ length: 80 }).map((_, idx) => {
            const num = idx + 1;
            const isSelected = gameState.selectedNumbers.has(num);
            const isDrawn = gameState.drawnNumbers.has(num);
            const isMatched = isSelected && isDrawn;

            return (
              <button
                key={num}
                onClick={() => handleSelectNumber(num)}
                disabled={gameState.gameStatus !== 'idle'}
                className={`p-2 rounded-sm border-2 text-xs font-bold transition-all ${
                  isMatched
                    ? 'border-green-600 bg-green-600/40 text-green-400'
                    : isSelected
                    ? 'border-yellow-600 bg-yellow-600/30 text-yellow-400'
                    : isDrawn
                    ? 'border-blue-600 bg-blue-600/20 text-blue-400'
                    : 'border-gray-600/30 bg-black/40 text-gray-400 hover:border-gray-600/60'
                } disabled:opacity-50`}
              >
                {num}
              </button>
            );
          })}
        </div>
        <button
          onClick={handleClearSelection}
          disabled={gameState.gameStatus !== 'idle' || gameState.selectedNumbers.size === 0}
          className="w-full p-2 rounded-sm border-2 border-red-600/30 bg-black/40 text-red-400 hover:border-red-600/60 disabled:opacity-50"
        >
          Clear Selection
        </button>
      </OSRSPanel>

      {/* Payout Table */}
      <OSRSPanel title="PAYOUT TABLE">
        <div className="grid grid-cols-5 gap-2 text-xs">
          {Object.entries(PAYOUT_TABLE).map(([matches, payout]) => (
            <div
              key={matches}
              className={`p-2 rounded-sm text-center border-2 ${
                parseInt(matches) === gameState.matchedNumbers
                  ? 'border-green-600 bg-green-600/20'
                  : 'border-yellow-600/30 bg-black/40'
              }`}
            >
              <div className="font-bold">{matches}</div>
              <div className="text-gray-400">{payout}x</div>
            </div>
          ))}
        </div>
      </OSRSPanel>

      {/* Result Display */}
      {gameState.gameStatus !== 'idle' && (
        <div className={`p-6 rounded-lg text-center ${
          gameState.gameStatus === 'won'
            ? 'bg-green-600/20 border-2 border-green-600'
            : 'bg-red-600/20 border-2 border-red-600'
        }`}>
          <div className="text-3xl font-bold mb-2">{gameState.matchedNumbers} MATCHES</div>
          <div className={`text-2xl font-bold ${gameState.gameStatus === 'won' ? 'text-green-500' : 'text-red-500'}`}>
            {gameState.gameStatus === 'won' ? `WON ${gameState.winAmount} GP!` : 'BETTER LUCK NEXT TIME'}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton
            onClick={handlePlayKeno}
            disabled={gameState.selectedNumbers.size === 0}
            className="flex-1"
          >
            PLAY KENO
          </OSRSButton>
        )}
        {(gameState.gameStatus === 'won' || gameState.gameStatus === 'lost') && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
