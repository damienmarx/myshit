/**
 * Leaderboard Component
 * Display rankings by earnings, wins, win rate, and activity
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSStatBox } from './OSRSComponents';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner';

interface LeaderboardEntry {
  rank: number;
  userId: number;
  username: string;
  totalEarnings?: number;
  totalWins?: number;
  totalGamesPlayed?: number;
  winRate?: number;
  rainParticipations?: number;
}

interface GlobalStats {
  totalPlayers: number;
  totalGamesPlayed: number;
  totalEarningsDistributed: number;
  averageWinRate: number;
}

export function Leaderboard() {
  const [topEarners, setTopEarners] = useState<LeaderboardEntry[]>([]);
  const [topWinners, setTopWinners] = useState<LeaderboardEntry[]>([]);
  const [highestWinRate, setHighestWinRate] = useState<LeaderboardEntry[]>([]);
  const [mostActive, setMostActive] = useState<LeaderboardEntry[]>([]);
  const [rainLeaderboard, setRainLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [globalStats, setGlobalStats] = useState<GlobalStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboardData();
  }, []);

  const loadLeaderboardData = async () => {
    try {
      setLoading(true);
      // In a real implementation, these would be API calls
      // For now, we'll use placeholder data
      const mockData: LeaderboardEntry[] = [
        {
          rank: 1,
          userId: 1,
          username: 'DegenKing',
          totalEarnings: 500000,
          totalWins: 245,
          totalGamesPlayed: 500,
          winRate: 49,
          rainParticipations: 15,
        },
        {
          rank: 2,
          userId: 2,
          username: 'LuckyStrike',
          totalEarnings: 350000,
          totalWins: 180,
          totalGamesPlayed: 400,
          winRate: 45,
          rainParticipations: 12,
        },
        {
          rank: 3,
          userId: 3,
          username: 'FlowerMaster',
          totalEarnings: 280000,
          totalWins: 150,
          totalGamesPlayed: 350,
          winRate: 43,
          rainParticipations: 10,
        },
      ];

      setTopEarners(mockData);
      setTopWinners(mockData.sort((a, b) => (b.totalWins || 0) - (a.totalWins || 0)));
      setHighestWinRate(mockData.sort((a, b) => (b.winRate || 0) - (a.winRate || 0)));
      setMostActive(mockData.sort((a, b) => (b.totalGamesPlayed || 0) - (a.totalGamesPlayed || 0)));
      setRainLeaderboard(mockData.sort((a, b) => (b.rainParticipations || 0) - (a.rainParticipations || 0)));

      setGlobalStats({
        totalPlayers: 1250,
        totalGamesPlayed: 125000,
        totalEarningsDistributed: 5000000,
        averageWinRate: 48,
      });
    } catch (error) {
      toast.error('Failed to load leaderboard data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const renderLeaderboardTable = (data: LeaderboardEntry[], columns: string[]) => (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b-2 border-yellow-600/30">
            <th className="p-2 text-left text-yellow-600">#</th>
            <th className="p-2 text-left text-yellow-600">Player</th>
            {columns.includes('earnings') && <th className="p-2 text-right text-yellow-600">Earnings</th>}
            {columns.includes('wins') && <th className="p-2 text-right text-yellow-600">Wins</th>}
            {columns.includes('games') && <th className="p-2 text-right text-yellow-600">Games</th>}
            {columns.includes('winrate') && <th className="p-2 text-right text-yellow-600">Win Rate</th>}
            {columns.includes('rain') && <th className="p-2 text-right text-yellow-600">Rain Events</th>}
          </tr>
        </thead>
        <tbody>
          {data.map((entry, idx) => (
            <tr
              key={entry.userId}
              className={`border-b border-yellow-600/10 hover:bg-yellow-600/5 transition-all ${
                idx === 0 ? 'bg-yellow-600/10' : idx === 1 ? 'bg-gray-600/5' : idx === 2 ? 'bg-orange-600/5' : ''
              }`}
            >
              <td className="p-2 text-yellow-600 font-bold">
                {entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : entry.rank}
              </td>
              <td className="p-2 text-white">{entry.username}</td>
              {columns.includes('earnings') && (
                <td className="p-2 text-right text-green-500">{entry.totalEarnings?.toLocaleString()} GP</td>
              )}
              {columns.includes('wins') && (
                <td className="p-2 text-right text-blue-500">{entry.totalWins}</td>
              )}
              {columns.includes('games') && (
                <td className="p-2 text-right text-purple-500">{entry.totalGamesPlayed}</td>
              )}
              {columns.includes('winrate') && (
                <td className="p-2 text-right text-orange-500">{entry.winRate}%</td>
              )}
              {columns.includes('rain') && (
                <td className="p-2 text-right text-cyan-500">{entry.rainParticipations}</td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Global Statistics */}
      {globalStats && (
        <div className="grid grid-cols-4 gap-4">
          <OSRSStatBox label="Total Players" value={globalStats.totalPlayers.toLocaleString()} />
          <OSRSStatBox label="Total Games" value={globalStats.totalGamesPlayed.toLocaleString()} />
          <OSRSStatBox label="Total Distributed" value={`${globalStats.totalEarningsDistributed.toLocaleString()} GP`} />
          <OSRSStatBox label="Avg Win Rate" value={`${globalStats.averageWinRate}%`} />
        </div>
      )}

      {/* Leaderboard Tabs */}
      <Tabs defaultValue="earnings" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-black/60 border-2 border-yellow-600/30 rounded-sm p-1">
          <TabsTrigger value="earnings" className="data-[state=active]:bg-yellow-600/20">
            💰 Earnings
          </TabsTrigger>
          <TabsTrigger value="wins" className="data-[state=active]:bg-yellow-600/20">
            🏆 Wins
          </TabsTrigger>
          <TabsTrigger value="winrate" className="data-[state=active]:bg-yellow-600/20">
            📈 Win Rate
          </TabsTrigger>
          <TabsTrigger value="active" className="data-[state=active]:bg-yellow-600/20">
            🎮 Activity
          </TabsTrigger>
          <TabsTrigger value="rain" className="data-[state=active]:bg-yellow-600/20">
            🌧️ Rain
          </TabsTrigger>
        </TabsList>

        <TabsContent value="earnings">
          <OSRSPanel title="TOP EARNERS">
            {renderLeaderboardTable(topEarners, ['earnings', 'wins', 'games', 'winrate'])}
          </OSRSPanel>
        </TabsContent>

        <TabsContent value="wins">
          <OSRSPanel title="TOP WINNERS">
            {renderLeaderboardTable(topWinners, ['wins', 'earnings', 'games', 'winrate'])}
          </OSRSPanel>
        </TabsContent>

        <TabsContent value="winrate">
          <OSRSPanel title="HIGHEST WIN RATE">
            {renderLeaderboardTable(highestWinRate, ['winrate', 'wins', 'earnings', 'games'])}
          </OSRSPanel>
        </TabsContent>

        <TabsContent value="active">
          <OSRSPanel title="MOST ACTIVE PLAYERS">
            {renderLeaderboardTable(mostActive, ['games', 'wins', 'earnings', 'winrate'])}
          </OSRSPanel>
        </TabsContent>

        <TabsContent value="rain">
          <OSRSPanel title="RAIN LEADERBOARD">
            {renderLeaderboardTable(rainLeaderboard, ['rain', 'earnings', 'wins', 'games'])}
          </OSRSPanel>
        </TabsContent>
      </Tabs>
    </div>
  );
}
