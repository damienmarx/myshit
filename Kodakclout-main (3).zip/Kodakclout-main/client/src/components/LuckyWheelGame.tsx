/**
 * Lucky Wheel Game Component
 * Spinning wheel with prize distribution
 */

import React, { useState } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { RotateCw } from 'lucide-react';
import { toast } from 'sonner';

interface Prize {
  id: number;
  label: string;
  multiplier: number;
  color: string;
}

interface LuckyWheelGameState {
  betAmount: number;
  balance: number;
  gameStatus: 'idle' | 'spinning' | 'finished';
  rotation: number;
  selectedPrize: Prize | null;
  winAmount: number;
  spins: number;
}

const PRIZES: Prize[] = [
  { id: 1, label: '2x', multiplier: 2, color: 'from-red-600 to-red-700' },
  { id: 2, label: '5x', multiplier: 5, color: 'from-blue-600 to-blue-700' },
  { id: 3, label: '1.5x', multiplier: 1.5, color: 'from-yellow-600 to-yellow-700' },
  { id: 4, label: '10x', multiplier: 10, color: 'from-purple-600 to-purple-700' },
  { id: 5, label: '3x', multiplier: 3, color: 'from-green-600 to-green-700' },
  { id: 6, label: '0.5x', multiplier: 0.5, color: 'from-pink-600 to-pink-700' },
  { id: 7, label: '7x', multiplier: 7, color: 'from-indigo-600 to-indigo-700' },
  { id: 8, label: '2.5x', multiplier: 2.5, color: 'from-cyan-600 to-cyan-700' },
];

export function LuckyWheelGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<LuckyWheelGameState>({
    betAmount: 100,
    balance: wallet.balance,
    gameStatus: 'idle',
    rotation: 0,
    selectedPrize: null,
    winAmount: 0,
    spins: 0,
  });

  const handleSpin = async () => {
    if (gameState.gameStatus !== 'idle') return;

    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('crash', gameState.betAmount);
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
      return;
    }

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'spinning',
      balance: prev.balance - prev.betAmount,
    }));

    // Random spin (5-8 full rotations + random offset)
    const fullRotations = 5 + Math.random() * 3;
    const randomOffset = Math.random() * 360;
    const totalRotation = fullRotations * 360 + randomOffset;

    // Determine which prize was selected
    const normalizedRotation = (360 - (totalRotation % 360)) % 360;
    const prizeIndex = Math.floor((normalizedRotation + 22.5) / 45) % PRIZES.length;
    const selectedPrize = PRIZES[prizeIndex];
    const winAmount = gameState.betAmount * selectedPrize.multiplier;

    // Animate rotation
    setGameState((prev) => ({
      ...prev,
      rotation: totalRotation,
    }));

    // Wait for animation to complete
    await new Promise((resolve) => setTimeout(resolve, 3000));

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'finished',
      selectedPrize,
      winAmount,
      balance: prev.balance + winAmount,
      spins: prev.spins + 1,
    }));

    // Record result
    setTimeout(async () => {
      try {
        if (winAmount > gameState.betAmount) {
          await wallet.recordWin('crash', gameState.betAmount, selectedPrize.multiplier, winAmount, {
            selectedPrize,
          });
          toast.success(`Won ${winAmount.toFixed(0)} GP! 🎉`);
        } else if (winAmount > 0) {
          await wallet.recordWin('crash', gameState.betAmount, selectedPrize.multiplier, winAmount, {
            selectedPrize,
          });
          toast.info(`Won ${winAmount.toFixed(0)} GP`);
        } else {
          await wallet.recordLoss('crash', gameState.betAmount, {
            selectedPrize,
          });
          toast.info(`Lost ${gameState.betAmount} GP`);
        }
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }, 100);
  };

  const handlePlayAgain = () => {
    setGameState((prev) => ({
      ...prev,
      gameStatus: 'idle',
      selectedPrize: null,
      winAmount: 0,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Wallet Balance" value={`${wallet.balance.toLocaleString()} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Total Spins" value={gameState.spins.toString()} />
        <OSRSStatBox label="Game Balance" value={`${gameState.balance.toLocaleString()} GP`} />
      </div>

      {/* Lucky Wheel */}
      <OSRSPanel title="LUCKY WHEEL">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Wheel */}
          <div className="flex-1 flex items-center justify-center">
            <div className="relative w-80 h-80">
              {/* Pointer */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 z-10">
                <div className="w-0 h-0 border-l-4 border-r-4 border-t-6 border-l-transparent border-r-transparent border-t-osrs-gold" />
              </div>

              {/* Wheel */}
              <div
                className="absolute inset-0 rounded-full border-8 border-osrs-gold/50 shadow-2xl shadow-osrs-gold/30"
                style={{
                  transform: `rotate(${gameState.rotation}deg)`,
                  transition: gameState.gameStatus === 'spinning' ? 'transform 3s cubic-bezier(0.25, 0.46, 0.45, 0.94)' : 'none',
                }}
              >
                {PRIZES.map((prize, idx) => {
                  const angle = (idx / PRIZES.length) * 360;
                  const isSelected = gameState.selectedPrize?.id === prize.id;

                  return (
                    <div
                      key={prize.id}
                      className={cn(
                        'absolute inset-0 rounded-full flex items-center justify-center',
                        `bg-gradient-to-br ${prize.color}`,
                        isSelected && 'ring-4 ring-osrs-gold'
                      )}
                      style={{
                        clipPath: `polygon(50% 50%, ${50 + 50 * Math.cos((angle - 22.5) * Math.PI / 180)}% ${50 + 50 * Math.sin((angle - 22.5) * Math.PI / 180)}%, ${50 + 50 * Math.cos((angle + 22.5) * Math.PI / 180)}% ${50 + 50 * Math.sin((angle + 22.5) * Math.PI / 180)}%)`,
                      }}
                    >
                      <div
                        style={{
                          transform: `rotate(${angle + 22.5}deg) translateY(-120px)`,
                        }}
                        className="text-white font-bold text-xl"
                      >
                        {prize.label}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Center Circle */}
              <div className="absolute inset-0 rounded-full bg-black border-4 border-osrs-gold flex items-center justify-center">
                <div className="text-center">
                  {gameState.selectedPrize ? (
                    <>
                      <p className="text-osrs-gold font-bold text-2xl">{gameState.selectedPrize.label}</p>
                      <p className="text-gray-400 text-xs">Prize</p>
                    </>
                  ) : (
                    <p className="text-gray-500 text-sm">SPIN</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex-1 space-y-6">
            {/* Bet Control */}
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">BET AMOUNT</label>
              <div className="flex gap-2">
                <input
                  type="range"
                  min="10"
                  max="10000"
                  step="10"
                  value={gameState.betAmount}
                  onChange={(e) =>
                    setGameState((prev) => ({
                      ...prev,
                      betAmount: parseInt(e.target.value),
                    }))
                  }
                  disabled={gameState.gameStatus !== 'idle'}
                  className="flex-1"
                />
                <input
                  type="number"
                  value={gameState.betAmount}
                  onChange={(e) =>
                    setGameState((prev) => ({
                      ...prev,
                      betAmount: Math.min(10000, Math.max(10, parseInt(e.target.value) || 10)),
                    }))
                  }
                  disabled={gameState.gameStatus !== 'idle'}
                  className="w-24 bg-black/50 border border-yellow-600/30 text-white px-2 py-1 rounded-sm"
                />
              </div>
            </div>

            {/* Prize Info */}
            <div>
              <p className="text-osrs-gold font-bold text-sm mb-2">AVAILABLE PRIZES</p>
              <div className="grid grid-cols-2 gap-2">
                {PRIZES.map((prize) => (
                  <div
                    key={prize.id}
                    className={cn(
                      'p-3 rounded-sm border-2 text-center',
                      gameState.selectedPrize?.id === prize.id
                        ? 'border-osrs-gold bg-osrs-gold/10'
                        : 'border-osrs-gold/20 bg-black/50'
                    )}
                  >
                    <p className="text-osrs-gold font-bold text-lg">{prize.label}</p>
                    <p className="text-gray-400 text-xs">
                      {(gameState.betAmount * prize.multiplier).toFixed(0)} GP
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Result */}
            {gameState.gameStatus === 'finished' && (
              <div className="bg-osrs-gold/10 border-2 border-osrs-gold rounded-lg p-4">
                <p className="text-osrs-gold font-bold text-sm mb-1">YOU WON</p>
                <p className="text-3xl font-black text-osrs-gold">
                  {gameState.winAmount.toFixed(0)} GP
                </p>
              </div>
            )}
          </div>
        </div>
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton onClick={handleSpin} disabled={wallet.placeBetLoading} className="flex-1">
            <RotateCw className="w-4 h-4 mr-2 inline" />
            {wallet.placeBetLoading ? 'PLACING BET...' : 'SPIN WHEEL'}
          </OSRSButton>
        )}
        {gameState.gameStatus === 'finished' && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            SPIN AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
