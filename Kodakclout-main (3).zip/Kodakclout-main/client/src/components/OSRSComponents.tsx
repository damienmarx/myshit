/**
 * OSRS-Inspired UI Components
 * Reusable components styled with Obsidian/Gold/Crimson theme
 */

import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface OSRSPanelProps {
  children: ReactNode;
  className?: string;
  title?: string;
}

/**
 * OSRS Panel - Luxury panel with gold border and obsidian background
 */
export function OSRSPanel({ children, className, title }: OSRSPanelProps) {
  return (
    <div className={cn('osrs-panel p-4', className)}>
      {title && (
        <h3 className="text-yellow-600 font-bold text-lg mb-4 border-b border-yellow-600/30 pb-2">
          {title}
        </h3>
      )}
      {children}
    </div>
  );
}

interface OSRSButtonProps {
  children: ReactNode;
  variant?: 'gold' | 'crimson' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}

/**
 * OSRS Button - Gold or Crimson button with OSRS styling
 */
export function OSRSButton({
  children,
  variant = 'gold',
  size = 'md',
  className,
  ...props
}: OSRSButtonProps) {
  const baseClass = variant === 'crimson' ? 'osrs-button-crimson' : 'osrs-button';
  const sizeClass = {
    sm: 'px-3 py-1 text-sm',
    md: 'px-4 py-2',
    lg: 'px-6 py-3 text-lg',
  }[size];

  return (
    <button className={cn(baseClass, sizeClass, className)} {...props}>
      {children}
    </button>
  );
}

interface OSRSStatBoxProps {
  label: string;
  value: string | number;
  icon?: ReactNode;
  highlight?: boolean;
}

/**
 * OSRS Stat Box - Displays a stat with label and value
 */
export function OSRSStatBox({ label, value, icon, highlight }: OSRSStatBoxProps) {
  return (
    <div className={cn('osrs-panel p-4 text-center', highlight && 'border-red-600')}>
      {icon && <div className="mb-2 text-yellow-600">{icon}</div>}
      <p className="text-gray-400 text-sm mb-1">{label}</p>
      <p className={cn('font-bold text-xl', highlight ? 'text-red-500' : 'text-yellow-600')}>
        {value}
      </p>
    </div>
  );
}

interface OSRSTabsProps {
  tabs: Array<{ label: string; content: ReactNode }>;
  defaultTab?: number;
}

/**
 * OSRS Tabs - Tab navigation with OSRS styling
 */
export function OSRSTabs({ tabs, defaultTab = 0 }: OSRSTabsProps) {
  const [activeTab, setActiveTab] = React.useState(defaultTab);

  return (
    <div>
      <div className="flex gap-2 border-b border-yellow-600/30 mb-4">
        {tabs.map((tab, idx) => (
          <button
            key={idx}
            onClick={() => setActiveTab(idx)}
            className={cn(
              'px-4 py-2 font-bold transition-colors',
              activeTab === idx
                ? 'text-yellow-600 border-b-2 border-yellow-600'
                : 'text-gray-400 hover:text-yellow-600'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div>{tabs[activeTab].content}</div>
    </div>
  );
}

interface OSRSInputProps {
  label?: string;
  placeholder?: string;
  value?: string | number;
  onChange?: (value: string) => void;
  type?: string;
  disabled?: boolean;
  className?: string;
}

/**
 * OSRS Input - Text input with OSRS styling
 */
export function OSRSInput({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  disabled,
  className,
}: OSRSInputProps) {
  return (
    <div className="flex flex-col gap-2">
      {label && <label className="text-yellow-600 font-bold text-sm">{label}</label>}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        disabled={disabled}
        className={cn(
          'bg-black/50 border border-yellow-600/30 text-white px-3 py-2 rounded-sm',
          'focus:border-yellow-600 focus:outline-none transition-colors',
          'placeholder:text-gray-600',
          disabled && 'opacity-50 cursor-not-allowed',
          className
        )}
      />
    </div>
  );
}

interface OSRSBadgeProps {
  children: ReactNode;
  variant?: 'gold' | 'crimson' | 'secondary';
  className?: string;
}

/**
 * OSRS Badge - Small label badge
 */
export function OSRSBadge({ children, variant = 'gold', className }: OSRSBadgeProps) {
  const variantClass = {
    gold: 'bg-yellow-600/20 text-yellow-600 border border-yellow-600/50',
    crimson: 'bg-red-600/20 text-red-500 border border-red-600/50',
    secondary: 'bg-gray-600/20 text-gray-400 border border-gray-600/50',
  }[variant];

  return (
    <span className={cn('px-2 py-1 rounded-sm text-xs font-bold', variantClass, className)}>
      {children}
    </span>
  );
}

interface OSRSProgressBarProps {
  value: number;
  max?: number;
  label?: string;
  showPercent?: boolean;
}

/**
 * OSRS Progress Bar - Progress indicator with gold gradient
 */
export function OSRSProgressBar({
  value,
  max = 100,
  label,
  showPercent = true,
}: OSRSProgressBarProps) {
  const percent = (value / max) * 100;

  return (
    <div className="flex flex-col gap-2">
      {(label || showPercent) && (
        <div className="flex justify-between text-sm">
          {label && <span className="text-gray-400">{label}</span>}
          {showPercent && <span className="text-yellow-600 font-bold">{Math.round(percent)}%</span>}
        </div>
      )}
      <div className="w-full h-6 bg-black/50 border border-yellow-600/30 rounded-sm overflow-hidden">
        <div
          className="h-full gold-gradient transition-all duration-300"
          style={{ width: `${percent}%` }}
        ></div>
      </div>
    </div>
  );
}

// Re-export React for use in components
import React from 'react';
