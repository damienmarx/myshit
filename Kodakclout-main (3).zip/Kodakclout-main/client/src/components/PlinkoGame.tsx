/**
 * Plinko Game Component
 * Physics-based ball drops with multiplier landing zones
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { Zap } from 'lucide-react';
import { toast } from 'sonner';

interface PlinkoGameState {
  betAmount: number;
  balance: number;
  gameStatus: 'idle' | 'dropping' | 'finished';
  ballPosition: number;
  multiplier: number;
  winAmount: number;
  history: number[];
}

const MULTIPLIERS = [0.5, 1, 1.5, 2, 3, 5, 10, 20, 10, 5, 3, 2, 1.5, 1, 0.5];

export function PlinkoGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<PlinkoGameState>({
    betAmount: 100,
    balance: wallet.balance,
    gameStatus: 'idle',
    ballPosition: 7,
    multiplier: 1,
    winAmount: 0,
    history: [],
  });

  const handleDropBall = async () => {
    if (gameState.gameStatus !== 'idle') return;

    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('dice', gameState.betAmount);
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
      return;
    }

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'dropping',
      balance: prev.balance - prev.betAmount,
    }));

    // Simulate ball dropping through pegs
    let position = 7;
    const path = [position];

    // 8 rows of pegs (ball bounces left or right)
    for (let i = 0; i < 8; i++) {
      await new Promise((resolve) => setTimeout(resolve, 150));

      const bounce = Math.random() > 0.5 ? 1 : -1;
      position = Math.max(0, Math.min(14, position + bounce));
      path.push(position);

      setGameState((prev) => ({
        ...prev,
        ballPosition: position,
      }));
    }

    const multiplier = MULTIPLIERS[position];
    const winAmount = gameState.betAmount * multiplier;

    setGameState((prev) => ({
      ...prev,
      gameStatus: 'finished',
      multiplier,
      winAmount,
      balance: prev.balance + winAmount,
      history: [multiplier, ...prev.history.slice(0, 9)],
    }));

    // Record result
    setTimeout(async () => {
      try {
        if (winAmount > gameState.betAmount) {
          await wallet.recordWin('dice', gameState.betAmount, multiplier, winAmount, {
            path,
            multiplier,
          });
          toast.success(`Won ${winAmount.toFixed(0)} GP! 🎉`);
        } else if (winAmount > 0) {
          await wallet.recordWin('dice', gameState.betAmount, multiplier, winAmount, {
            path,
            multiplier,
          });
          toast.info(`Won ${winAmount.toFixed(0)} GP`);
        } else {
          await wallet.recordLoss('dice', gameState.betAmount, {
            path,
            multiplier,
          });
          toast.info(`Lost ${gameState.betAmount} GP`);
        }
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }, 100);
  };

  const handlePlayAgain = () => {
    setGameState((prev) => ({
      ...prev,
      gameStatus: 'idle',
      ballPosition: 7,
      multiplier: 1,
      winAmount: 0,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Wallet Balance" value={`${wallet.balance.toLocaleString()} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Multiplier" value={`${gameState.multiplier.toFixed(2)}x`} highlight={gameState.multiplier > 1} />
        <OSRSStatBox label="Game Balance" value={`${gameState.balance.toLocaleString()} GP`} />
      </div>

      {/* Plinko Board */}
      <OSRSPanel title="PLINKO BOARD">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Game Board */}
          <div className="flex-1">
            <div className="bg-black/50 border-2 border-osrs-gold/30 rounded-lg p-6 aspect-square flex flex-col">
              {/* Pegs Grid */}
              <div className="flex-1 flex flex-col justify-around">
                {Array.from({ length: 8 }).map((_, row) => (
                  <div key={row} className="flex justify-center gap-4">
                    {Array.from({ length: row + 1 }).map((_, col) => (
                      <div
                        key={col}
                        className="w-3 h-3 bg-osrs-gold/50 rounded-full"
                      />
                    ))}
                  </div>
                ))}
              </div>

              {/* Ball */}
              {gameState.gameStatus !== 'idle' && (
                <div className="relative h-8 mb-4">
                  <div
                    className="absolute w-4 h-4 bg-osrs-gold rounded-full shadow-lg shadow-osrs-gold/50 transition-all duration-100"
                    style={{
                      left: `calc(${(gameState.ballPosition / 14) * 100}% - 8px)`,
                    }}
                  />
                </div>
              )}

              {/* Multiplier Zones */}
              <div className="flex justify-between text-xs font-bold">
                {MULTIPLIERS.map((mult, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      'flex-1 text-center py-2 rounded-sm border',
                      gameState.ballPosition === idx && gameState.gameStatus === 'finished'
                        ? 'bg-osrs-gold/30 border-osrs-gold text-osrs-gold'
                        : 'bg-black/50 border-osrs-gold/20 text-gray-400'
                    )}
                  >
                    {mult.toFixed(2)}x
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex-1 space-y-6">
            {/* Bet Control */}
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">BET AMOUNT</label>
              <div className="flex gap-2">
                <input
                  type="range"
                  min="10"
                  max="10000"
                  step="10"
                  value={gameState.betAmount}
                  onChange={(e) =>
                    setGameState((prev) => ({
                      ...prev,
                      betAmount: parseInt(e.target.value),
                    }))
                  }
                  disabled={gameState.gameStatus !== 'idle'}
                  className="flex-1"
                />
                <input
                  type="number"
                  value={gameState.betAmount}
                  onChange={(e) =>
                    setGameState((prev) => ({
                      ...prev,
                      betAmount: Math.min(10000, Math.max(10, parseInt(e.target.value) || 10)),
                    }))
                  }
                  disabled={gameState.gameStatus !== 'idle'}
                  className="w-24 bg-black/50 border border-yellow-600/30 text-white px-2 py-1 rounded-sm"
                />
              </div>
            </div>

            {/* Result Display */}
            {gameState.gameStatus === 'finished' && (
              <div className="bg-osrs-gold/10 border-2 border-osrs-gold rounded-lg p-4">
                <p className="text-osrs-gold font-bold text-sm mb-1">LANDED ON</p>
                <p className="text-4xl font-black text-osrs-gold mb-3">
                  {gameState.multiplier.toFixed(2)}x
                </p>
                <p className="text-gray-400 text-sm mb-2">Win Amount</p>
                <p className="text-2xl font-bold text-white">
                  {gameState.winAmount.toFixed(0)} GP
                </p>
              </div>
            )}

            {/* History */}
            {gameState.history.length > 0 && (
              <div>
                <p className="text-osrs-gold font-bold text-sm mb-2">RECENT DROPS</p>
                <div className="grid grid-cols-5 gap-2">
                  {gameState.history.map((mult, idx) => (
                    <div
                      key={idx}
                      className="bg-black/50 border border-osrs-gold/20 rounded p-2 text-center text-xs font-bold text-gray-400 hover:text-osrs-gold transition-colors"
                    >
                      {mult.toFixed(2)}x
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton onClick={handleDropBall} disabled={wallet.placeBetLoading} className="flex-1">
            <Zap className="w-4 h-4 mr-2 inline" />
            {wallet.placeBetLoading ? 'PLACING BET...' : 'DROP BALL'}
          </OSRSButton>
        )}
        {gameState.gameStatus === 'finished' && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
