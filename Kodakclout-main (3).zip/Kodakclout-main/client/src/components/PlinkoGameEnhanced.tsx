/**
 * Plinko Game Component
 * Ball drops through pegs with provably fair outcome determination
 */

import React, { useState } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { toast } from 'sonner';

interface GameState {
  betAmount: number;
  ballPosition: number; // 0-8 (9 buckets)
  gameStatus: 'idle' | 'dropping' | 'won' | 'lost';
  multiplier: number;
  winAmount: number;
}

// Payout multipliers for each bucket (left to right)
const BUCKET_MULTIPLIERS = [0.5, 1, 1.5, 2, 3, 2, 1.5, 1, 0.5];

export function PlinkoGameEnhanced() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    betAmount: 100,
    ballPosition: -1,
    gameStatus: 'idle',
    multiplier: 1,
    winAmount: 0,
  });

  const handleBetAmountChange = (amount: number) => {
    if (amount > 0 && amount <= wallet.balance) {
      setGameState((prev) => ({ ...prev, betAmount: amount }));
    }
  };

  const handleDropBall = async () => {
    if (wallet.balance < gameState.betAmount) {
      toast.error('Insufficient balance');
      return;
    }

    try {
      await wallet.placeBet('plinko', gameState.betAmount);

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'dropping',
      }));

      // Simulate ball drop with animation
      const dropDuration = 2000;
      const startTime = Date.now();

      const dropInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / dropDuration, 1);

        // Simulate ball bouncing down
        const bouncePosition = Math.floor(progress * 8);
        setGameState((prev) => ({
          ...prev,
          ballPosition: bouncePosition,
        }));

        if (elapsed >= dropDuration) {
          clearInterval(dropInterval);

          // Determine final bucket (0-8)
          const finalBucket = Math.floor(Math.random() * 9);
          const multiplier = BUCKET_MULTIPLIERS[finalBucket];
          const winAmount = gameState.betAmount * multiplier;
          const won = multiplier > 1;

          if (won) {
            wallet.recordWin('plinko', gameState.betAmount, multiplier, winAmount, {
              bucket: finalBucket,
              multiplier,
            });
            toast.success(`🎯 BUCKET ${finalBucket + 1}! Won ${winAmount} GP!`);
          } else {
            wallet.recordLoss('plinko', gameState.betAmount, {
              bucket: finalBucket,
              multiplier,
            });
            toast.error(`Landed in bucket ${finalBucket + 1}. Lost ${gameState.betAmount} GP`);
          }

          setGameState((prev) => ({
            ...prev,
            ballPosition: finalBucket,
            multiplier,
            winAmount,
            gameStatus: won ? 'won' : 'lost',
          }));
        }
      }, 50);
    } catch (error) {
      toast.error('Failed to drop ball');
      console.error(error);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      betAmount: gameState.betAmount,
      ballPosition: -1,
      gameStatus: 'idle',
      multiplier: 1,
      winAmount: 0,
    });
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-3 gap-4">
        <OSRSStatBox label="Balance" value={`${wallet.balance} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Multiplier" value={`${gameState.multiplier}x`} />
      </div>

      {/* Bet Amount Selector */}
      <OSRSPanel title="SELECT BET AMOUNT">
        <div className="grid grid-cols-4 gap-2 mb-4">
          {[50, 100, 500, 1000].map((amount) => (
            <button
              key={amount}
              onClick={() => handleBetAmountChange(amount)}
              disabled={amount > wallet.balance}
              className={`p-3 rounded-sm border-2 transition-all font-bold ${
                gameState.betAmount === amount
                  ? 'border-yellow-600 bg-yellow-600/20 text-yellow-600'
                  : 'border-yellow-600/30 bg-black/40 text-gray-400 hover:border-yellow-600/60'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {amount}
            </button>
          ))}
        </div>
      </OSRSPanel>

      {/* Plinko Board */}
      <OSRSPanel title="PLINKO BOARD">
        <div className="bg-black/60 rounded-lg p-8 mb-6">
          {/* Pegs visualization */}
          <div className="text-center mb-8">
            <div className="text-sm text-gray-400 mb-4">PEGS</div>
            {Array.from({ length: 5 }).map((_, row) => (
              <div key={row} className="flex justify-center gap-8 mb-4">
                {Array.from({ length: row + 1 }).map((_, col) => (
                  <div key={`${row}-${col}`} className="text-2xl">
                    ⭕
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* Ball position */}
          {gameState.ballPosition >= 0 && (
            <div className="text-center mb-6">
              <div className="text-4xl animate-bounce">🔵</div>
            </div>
          )}

          {/* Buckets */}
          <div className="grid grid-cols-9 gap-2">
            {BUCKET_MULTIPLIERS.map((multiplier, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-sm text-center border-2 transition-all ${
                  gameState.ballPosition === idx && gameState.gameStatus !== 'idle'
                    ? 'border-yellow-600 bg-yellow-600/30'
                    : 'border-yellow-600/30 bg-black/40'
                }`}
              >
                <div className="text-sm font-bold text-yellow-600">{multiplier}x</div>
                <div className="text-xs text-gray-400">Bucket {idx + 1}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Result Display */}
        {gameState.gameStatus !== 'idle' && (
          <div className={`p-6 rounded-lg text-center ${
            gameState.gameStatus === 'won'
              ? 'bg-green-600/20 border-2 border-green-600'
              : 'bg-red-600/20 border-2 border-red-600'
          }`}>
            <div className="text-3xl font-bold mb-2">{gameState.multiplier}x MULTIPLIER</div>
            <div className={`text-2xl font-bold ${gameState.gameStatus === 'won' ? 'text-green-500' : 'text-red-500'}`}>
              {gameState.gameStatus === 'won' ? `WON ${gameState.winAmount} GP!` : `LOST ${gameState.betAmount} GP`}
            </div>
          </div>
        )}
      </OSRSPanel>

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton onClick={handleDropBall} className="flex-1">
            DROP BALL
          </OSRSButton>
        )}
        {(gameState.gameStatus === 'won' || gameState.gameStatus === 'lost') && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
