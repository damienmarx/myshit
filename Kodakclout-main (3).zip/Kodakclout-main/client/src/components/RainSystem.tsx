/**
 * Rain System Component
 * Display rain events and participation history
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { toast } from 'sonner';

interface RainEvent {
  id: number;
  totalAmount: number;
  participantCount: number;
  amountPerParticipant: number;
  createdAt: string;
}

interface RainParticipation {
  id: number;
  rainEventId: number;
  amountReceived: number;
  createdAt: string;
}

export function RainSystem() {
  const [rainEvents, setRainEvents] = useState<RainEvent[]>([]);
  const [participationHistory, setParticipationHistory] = useState<RainParticipation[]>([]);
  const [totalRainReceived, setTotalRainReceived] = useState(0);
  const [rainEventsParticipated, setRainEventsParticipated] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRainData();
  }, []);

  const loadRainData = async () => {
    try {
      setLoading(true);
      // In a real implementation, these would be API calls
      // For now, we'll use placeholder data
      setRainEvents([
        {
          id: 1,
          totalAmount: 50000,
          participantCount: 25,
          amountPerParticipant: 2000,
          createdAt: new Date().toISOString(),
        },
      ]);
      setTotalRainReceived(4000);
      setRainEventsParticipated(2);
    } catch (error) {
      toast.error('Failed to load rain data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Rain Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <OSRSStatBox label="Total Rain Received" value={`${totalRainReceived} GP`} />
        <OSRSStatBox label="Rain Events Participated" value={`${rainEventsParticipated}`} />
        <OSRSStatBox label="Average Per Event" value={`${rainEventsParticipated > 0 ? Math.floor(totalRainReceived / rainEventsParticipated) : 0} GP`} />
      </div>

      {/* Recent Rain Events */}
      <OSRSPanel title="RECENT RAIN EVENTS">
        {rainEvents.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            No rain events yet. Check back soon!
          </div>
        ) : (
          <div className="space-y-3">
            {rainEvents.map((event) => (
              <div
                key={event.id}
                className="p-4 rounded-sm border-2 border-yellow-600/30 bg-black/40 hover:border-yellow-600/60 transition-all"
              >
                <div className="flex justify-between items-center mb-2">
                  <div className="text-lg font-bold text-yellow-600">RAIN EVENT #{event.id}</div>
                  <div className="text-sm text-gray-400">
                    {new Date(event.createdAt).toLocaleString()}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-gray-400">Total Amount</div>
                    <div className="text-yellow-600 font-bold">{event.totalAmount} GP</div>
                  </div>
                  <div>
                    <div className="text-gray-400">Participants</div>
                    <div className="text-yellow-600 font-bold">{event.participantCount}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">Per Participant</div>
                    <div className="text-yellow-600 font-bold">{event.amountPerParticipant} GP</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </OSRSPanel>

      {/* Participation History */}
      <OSRSPanel title="YOUR RAIN HISTORY">
        {participationHistory.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            You haven't participated in any rain events yet.
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {participationHistory.map((participation) => (
              <div
                key={participation.id}
                className="p-3 rounded-sm border-2 border-green-600/30 bg-black/40 flex justify-between items-center"
              >
                <div className="text-sm">
                  <div className="text-gray-400">Event #{participation.rainEventId}</div>
                  <div className="text-xs text-gray-500">
                    {new Date(participation.createdAt).toLocaleString()}
                  </div>
                </div>
                <div className="text-green-500 font-bold">+{participation.amountReceived} GP</div>
              </div>
            ))}
          </div>
        )}
      </OSRSPanel>

      {/* Rain Info */}
      <OSRSPanel title="ABOUT RAIN">
        <div className="text-sm text-gray-400 space-y-2">
          <p>
            🌧️ <strong>Rain Events</strong> are random distributions of GP to active players. The more active you are, the better your chances of being included!
          </p>
          <p>
            💰 Rain amounts vary based on the total pool and number of participants. Keep playing to maximize your rain rewards!
          </p>
          <p>
            🎯 Rain events are triggered by admins and announced in the chat. Stay tuned to the lobby for announcements!
          </p>
        </div>
      </OSRSPanel>
    </div>
  );
}
