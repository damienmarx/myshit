/**
 * Roulette Game Component
 * European Roulette with wheel animations and multiple bet types
 */

import React, { useState, useEffect } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { cn } from '@/lib/utils';
import { Zap, RotateCw } from 'lucide-react';
import { toast } from 'sonner';

type BetType = 'number' | 'red' | 'black' | 'even' | 'odd' | 'high' | 'low' | 'dozen' | 'column';

interface Bet {
  type: BetType;
  value: number | string;
  amount: number;
  payout: number;
}

interface RouletteGameState {
  balance: number;
  bets: Bet[];
  betAmount: number;
  selectedBetType: BetType;
  selectedNumber: number;
  spinning: boolean;
  result: number | null;
  winAmount: number;
  gameStatus: 'betting' | 'spinning' | 'finished';
}

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const BLACK_NUMBERS = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35];

const BET_PAYOUTS: Record<BetType, number> = {
  number: 35,
  red: 1,
  black: 1,
  even: 1,
  odd: 1,
  high: 1,
  low: 1,
  dozen: 2,
  column: 2,
};

export function RouletteGame() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<RouletteGameState>({
    balance: wallet.balance,
    bets: [],
    betAmount: 100,
    selectedBetType: 'number',
    selectedNumber: 17,
    spinning: false,
    result: null,
    winAmount: 0,
    gameStatus: 'betting',
  });

  const handlePlaceBet = async (type: BetType, value: number | string) => {
    if (gameState.spinning) return;

    // Check balance
    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance. You have ${wallet.balance} GP but need ${gameState.betAmount} GP`);
      return;
    }

    try {
      // Place bet
      await wallet.placeBet('hot_cold', gameState.betAmount);

      const payout = BET_PAYOUTS[type];
      const newBet: Bet = {
        type,
        value,
        amount: gameState.betAmount,
        payout,
      };

      setGameState((prev) => ({
        ...prev,
        bets: [...prev.bets, newBet],
        balance: prev.balance - gameState.betAmount,
      }));
    } catch (error) {
      toast.error('Failed to place bet');
      console.error(error);
    }
  };

  const handleSpin = async () => {
    if (gameState.bets.length === 0 || gameState.spinning) return;

    setGameState((prev) => ({
      ...prev,
      spinning: true,
      gameStatus: 'spinning',
    }));

    // Simulate wheel spin (3 seconds)
    await new Promise((resolve) => setTimeout(resolve, 3000));

    // Generate random result (0-36)
    const result = Math.floor(Math.random() * 37);

    // Calculate winnings
    let winAmount = 0;
    gameState.bets.forEach((bet) => {
      let won = false;

      switch (bet.type) {
        case 'number':
          won = result === bet.value;
          break;
        case 'red':
          won = RED_NUMBERS.includes(result);
          break;
        case 'black':
          won = BLACK_NUMBERS.includes(result);
          break;
        case 'even':
          won = result > 0 && result % 2 === 0;
          break;
        case 'odd':
          won = result > 0 && result % 2 === 1;
          break;
        case 'high':
          won = result > 18;
          break;
        case 'low':
          won = result > 0 && result <= 18;
          break;
        case 'dozen':
          const dozen = Math.ceil(result / 12);
          won = dozen === bet.value;
          break;
        case 'column':
          won = result > 0 && result % 3 === bet.value;
          break;
      }

      if (won) {
        winAmount += bet.amount * (bet.payout + 1);
      }
    });

    setGameState((prev) => ({
      ...prev,
      result,
      spinning: false,
      gameStatus: 'finished',
      winAmount,
      balance: prev.balance + winAmount,
    }));

    // Record result
    setTimeout(async () => {
      try {
        const totalBet = gameState.bets.reduce((sum, bet) => sum + bet.amount, 0);
        if (winAmount > 0) {
          const multiplier = winAmount / totalBet;
          await wallet.recordWin('hot_cold', totalBet, multiplier, winAmount, {
            bets: gameState.bets,
            result,
          });
          toast.success(`Won ${winAmount.toLocaleString()} GP! 🎉`);
        } else {
          await wallet.recordLoss('hot_cold', totalBet, {
            bets: gameState.bets,
            result,
          });
          toast.info(`Lost ${totalBet.toLocaleString()} GP`);
        }
      } catch (error) {
        toast.error('Failed to record game result');
        console.error(error);
      }
    }, 100);
  };

  const handlePlayAgain = () => {
    setGameState((prev) => ({
      ...prev,
      bets: [],
      result: null,
      winAmount: 0,
      gameStatus: 'betting',
    }));
  };

  const totalBetAmount = gameState.bets.reduce((sum, bet) => sum + bet.amount, 0);

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-4 gap-4">
        <OSRSStatBox label="Wallet Balance" value={`${wallet.balance.toLocaleString()} GP`} />
        <OSRSStatBox label="Game Balance" value={`${gameState.balance.toLocaleString()} GP`} />
        <OSRSStatBox label="Total Bets" value={`${totalBetAmount.toLocaleString()} GP`} />
        <OSRSStatBox label="Potential Win" value={`${(totalBetAmount * 2).toLocaleString()} GP`} highlight={gameState.bets.length > 0} />
      </div>

      {/* Roulette Wheel */}
      <OSRSPanel title="EUROPEAN ROULETTE">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Wheel */}
          <div className="flex-1 flex items-center justify-center">
            <div className="relative w-64 h-64">
              {/* Wheel */}
              <div
                className={cn(
                  'absolute inset-0 rounded-full border-8 border-osrs-gold/50 bg-gradient-to-br from-black to-gray-900 flex items-center justify-center',
                  gameState.spinning && 'animate-spin'
                )}
                style={{
                  animationDuration: gameState.spinning ? '3s' : '0s',
                }}
              >
                <div className="text-center">
                  {gameState.result !== null ? (
                    <>
                      <p className="text-osrs-gold font-bold text-2xl">{gameState.result}</p>
                      <p className={cn(
                        'text-sm font-bold',
                        gameState.result === 0 ? 'text-gray-400' : RED_NUMBERS.includes(gameState.result) ? 'text-red-500' : 'text-gray-400'
                      )}>
                        {gameState.result === 0 ? 'GREEN' : RED_NUMBERS.includes(gameState.result) ? 'RED' : 'BLACK'}
                      </p>
                    </>
                  ) : (
                    <p className="text-gray-500">Ready to spin</p>
                  )}
                </div>
              </div>

              {/* Ball indicator */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 w-4 h-4 bg-osrs-gold rounded-full shadow-lg" />
            </div>
          </div>

          {/* Betting Area */}
          <div className="flex-1 space-y-4">
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">BET AMOUNT</label>
              <input
                type="number"
                value={gameState.betAmount}
                onChange={(e) => setGameState((prev) => ({ ...prev, betAmount: Math.max(10, parseInt(e.target.value) || 10) }))}
                disabled={gameState.gameStatus !== 'betting'}
                className="w-full bg-black/50 border border-yellow-600/30 text-white px-3 py-2 rounded-sm"
              />
            </div>

            {/* Quick Bets */}
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">QUICK BETS</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handlePlaceBet('red', 'red')}
                  disabled={gameState.gameStatus !== 'betting'}
                  className="py-2 bg-red-600/20 border border-red-600 text-red-400 font-bold rounded-sm hover:bg-red-600/30 disabled:opacity-50"
                >
                  RED
                </button>
                <button
                  onClick={() => handlePlaceBet('black', 'black')}
                  disabled={gameState.gameStatus !== 'betting'}
                  className="py-2 bg-gray-600/20 border border-gray-600 text-gray-400 font-bold rounded-sm hover:bg-gray-600/30 disabled:opacity-50"
                >
                  BLACK
                </button>
                <button
                  onClick={() => handlePlaceBet('even', 'even')}
                  disabled={gameState.gameStatus !== 'betting'}
                  className="py-2 bg-osrs-gold/20 border border-osrs-gold text-osrs-gold font-bold rounded-sm hover:bg-osrs-gold/30 disabled:opacity-50"
                >
                  EVEN
                </button>
                <button
                  onClick={() => handlePlaceBet('odd', 'odd')}
                  disabled={gameState.gameStatus !== 'betting'}
                  className="py-2 bg-osrs-gold/20 border border-osrs-gold text-osrs-gold font-bold rounded-sm hover:bg-osrs-gold/30 disabled:opacity-50"
                >
                  ODD
                </button>
              </div>
            </div>

            {/* Number Selection */}
            <div>
              <label className="text-osrs-gold font-bold text-sm block mb-2">STRAIGHT BET (SELECT NUMBER)</label>
              <div className="grid grid-cols-6 gap-1 max-h-48 overflow-y-auto">
                {Array.from({ length: 37 }, (_, i) => i).map((num) => (
                  <button
                    key={num}
                    onClick={() => handlePlaceBet('number', num)}
                    disabled={gameState.gameStatus !== 'betting'}
                    className={cn(
                      'py-1 text-xs font-bold rounded-sm border transition-colors disabled:opacity-50',
                      num === 0
                        ? 'bg-gray-600/20 border-gray-600 text-gray-400 hover:bg-gray-600/30'
                        : RED_NUMBERS.includes(num)
                          ? 'bg-red-600/20 border-red-600 text-red-400 hover:bg-red-600/30'
                          : 'bg-gray-600/20 border-gray-600 text-gray-400 hover:bg-gray-600/30'
                    )}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </OSRSPanel>

      {/* Current Bets */}
      {gameState.bets.length > 0 && (
        <div className="bg-panel-dark border-2 border-osrs-gold/30 rounded-lg p-4">
          <h3 className="text-osrs-gold font-bold mb-3">YOUR BETS</h3>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {gameState.bets.map((bet, idx) => (
              <div key={idx} className="flex justify-between text-sm text-gray-300 p-2 bg-black/50 rounded">
                <span>{bet.type.toUpperCase()} {bet.value}</span>
                <span className="text-osrs-gold font-bold">{bet.amount} GP</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {gameState.gameStatus === 'finished' && (
        <div className={cn(
          'p-6 rounded-lg border-2',
          gameState.winAmount > 0
            ? 'bg-green-600/10 border-green-600 text-green-400'
            : 'bg-red-600/10 border-red-600 text-red-400'
        )}>
          <h3 className="text-xl font-bold mb-2">
            {gameState.winAmount > 0 ? '🎉 YOU WON!' : 'Better luck next time'}
          </h3>
          <p className="text-lg font-bold">
            {gameState.winAmount > 0 ? `+${gameState.winAmount.toLocaleString()} GP` : 'No winning bets'}
          </p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'betting' && (
          <>
            <OSRSButton
              onClick={handleSpin}
              disabled={gameState.bets.length === 0 || gameState.spinning}
              className="flex-1"
            >
              <Zap className="w-4 h-4 mr-2 inline" />
              SPIN
            </OSRSButton>
            <OSRSButton onClick={handlePlayAgain} variant="secondary" className="flex-1">
              CLEAR BETS
            </OSRSButton>
          </>
        )}
        {gameState.gameStatus === 'finished' && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
