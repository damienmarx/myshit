/**
 * Roulette Game Component
 * Classic roulette with 37 numbers (0-36) and provably fair mechanics
 */

import React, { useState } from 'react';
import { OSRSPanel, OSRSButton, OSRSStatBox } from './OSRSComponents';
import { useWallet } from '@/hooks/useWallet';
import { toast } from 'sonner';

interface GameState {
  betAmount: number;
  selectedNumber: number | null;
  selectedColor: 'red' | 'black' | 'green' | null;
  result: number | null;
  gameStatus: 'idle' | 'spinning' | 'won' | 'lost';
  multiplier: number;
  isSpinning: boolean;
}

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const BLACK_NUMBERS = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35];

function getNumberColor(num: number): 'red' | 'black' | 'green' {
  if (num === 0) return 'green';
  return RED_NUMBERS.includes(num) ? 'red' : 'black';
}

export function RouletteGameEnhanced() {
  const wallet = useWallet();
  const [gameState, setGameState] = useState<GameState>({
    betAmount: 100,
    selectedNumber: null,
    selectedColor: null,
    result: null,
    gameStatus: 'idle',
    multiplier: 2,
    isSpinning: false,
  });

  const handleBetAmountChange = (amount: number) => {
    if (amount > 0 && amount <= wallet.balance) {
      setGameState((prev) => ({ ...prev, betAmount: amount }));
    }
  };

  const handleSelectNumber = (num: number) => {
    if (gameState.gameStatus === 'idle') {
      setGameState((prev) => ({
        ...prev,
        selectedNumber: prev.selectedNumber === num ? null : num,
        selectedColor: null,
      }));
    }
  };

  const handleSelectColor = (color: 'red' | 'black' | 'green') => {
    if (gameState.gameStatus === 'idle') {
      setGameState((prev) => ({
        ...prev,
        selectedColor: prev.selectedColor === color ? null : color,
        selectedNumber: null,
      }));
    }
  };

  const handleSpin = async () => {
    if (!gameState.selectedNumber && !gameState.selectedColor) {
      toast.error('Please select a number or color');
      return;
    }

    if (wallet.balance < gameState.betAmount) {
      toast.error(`Insufficient balance`);
      return;
    }

    try {
      await wallet.placeBet('roulette', gameState.betAmount);

      setGameState((prev) => ({
        ...prev,
        gameStatus: 'spinning',
        isSpinning: true,
      }));

      // Simulate spin
      const spinDuration = 3000;
      const startTime = Date.now();

      const spinInterval = setInterval(async () => {
        const elapsed = Date.now() - startTime;
        if (elapsed >= spinDuration) {
          clearInterval(spinInterval);

          // Generate result
          const result = Math.floor(Math.random() * 37);
          const resultColor = getNumberColor(result);

          let won = false;
          if (gameState.selectedNumber !== null) {
            won = result === gameState.selectedNumber;
          } else if (gameState.selectedColor) {
            won = resultColor === gameState.selectedColor;
          }

          if (won) {
            const multiplier = gameState.selectedNumber !== null ? 36 : 2;
            const winAmount = gameState.betAmount * multiplier;
            await wallet.recordWin('roulette', gameState.betAmount, multiplier, winAmount, {
              selectedNumber: gameState.selectedNumber,
              selectedColor: gameState.selectedColor,
              result,
            });
            toast.success(`🎰 WINNING SPIN! Number ${result} (${resultColor.toUpperCase()}) - Won ${winAmount} GP!`);
            setGameState((prev) => ({
              ...prev,
              result,
              gameStatus: 'won',
              isSpinning: false,
              multiplier,
            }));
          } else {
            void wallet.recordLoss('roulette', gameState.betAmount, {
              selectedNumber: gameState.selectedNumber,
              selectedColor: gameState.selectedColor,
              result,
            });
            toast.error(`The wheel landed on ${result} (${resultColor.toUpperCase()})`);
            setGameState((prev) => ({
              ...prev,
              result,
              gameStatus: 'lost',
              isSpinning: false,
            }));
          }
        }
      }, 50);
    } catch (error) {
      toast.error('Failed to spin');
      console.error(error);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      betAmount: gameState.betAmount,
      selectedNumber: null,
      selectedColor: null,
      result: null,
      gameStatus: 'idle',
      multiplier: 2,
      isSpinning: false,
    });
  };

  return (
    <div className="space-y-6">
      {/* Game Info */}
      <div className="grid grid-cols-3 gap-4">
        <OSRSStatBox label="Balance" value={`${wallet.balance} GP`} />
        <OSRSStatBox label="Bet Amount" value={`${gameState.betAmount} GP`} />
        <OSRSStatBox label="Multiplier" value={`${gameState.multiplier}x`} />
      </div>

      {/* Bet Amount Selector */}
      <OSRSPanel title="SELECT BET AMOUNT">
        <div className="grid grid-cols-4 gap-2 mb-4">
          {[100, 500, 1000, 5000].map((amount) => (
            <button
              key={amount}
              onClick={() => handleBetAmountChange(amount)}
              disabled={amount > wallet.balance}
              className={`p-3 rounded-sm border-2 transition-all font-bold ${
                gameState.betAmount === amount
                  ? 'border-yellow-600 bg-yellow-600/20 text-yellow-600'
                  : 'border-yellow-600/30 bg-black/40 text-gray-400 hover:border-yellow-600/60'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {amount}
            </button>
          ))}
        </div>
        <input
          type="number"
          value={gameState.betAmount}
          onChange={(e) => handleBetAmountChange(parseInt(e.target.value) || 0)}
          min="1"
          max={wallet.balance}
          className="w-full p-2 rounded-sm bg-black/60 border-2 border-yellow-600/30 text-white placeholder-gray-600 focus:border-yellow-600 focus:outline-none"
          placeholder="Enter custom bet amount"
        />
      </OSRSPanel>

      {/* Color Selection */}
      <OSRSPanel title="SELECT COLOR">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <button
            onClick={() => handleSelectColor('red')}
            disabled={gameState.gameStatus !== 'idle'}
            className={`p-6 rounded-lg border-4 transition-all ${
              gameState.selectedColor === 'red'
                ? 'border-red-600 bg-red-600/20'
                : 'border-red-600/30 bg-black/40 hover:border-red-600/60'
            } disabled:opacity-50`}
          >
            <div className="text-4xl mb-2">🔴</div>
            <div className="font-bold text-red-500">RED</div>
          </button>
          <button
            onClick={() => handleSelectColor('black')}
            disabled={gameState.gameStatus !== 'idle'}
            className={`p-6 rounded-lg border-4 transition-all ${
              gameState.selectedColor === 'black'
                ? 'border-gray-600 bg-gray-600/20'
                : 'border-gray-600/30 bg-black/40 hover:border-gray-600/60'
            } disabled:opacity-50`}
          >
            <div className="text-4xl mb-2">⚫</div>
            <div className="font-bold text-gray-400">BLACK</div>
          </button>
          <button
            onClick={() => handleSelectColor('green')}
            disabled={gameState.gameStatus !== 'idle'}
            className={`p-6 rounded-lg border-4 transition-all ${
              gameState.selectedColor === 'green'
                ? 'border-green-600 bg-green-600/20'
                : 'border-green-600/30 bg-black/40 hover:border-green-600/60'
            } disabled:opacity-50`}
          >
            <div className="text-4xl mb-2">🟢</div>
            <div className="font-bold text-green-500">GREEN (0)</div>
          </button>
        </div>
      </OSRSPanel>

      {/* Number Selection */}
      <OSRSPanel title="OR SELECT A NUMBER (0-36)">
        <div className="grid grid-cols-10 gap-2 mb-6">
          {Array.from({ length: 37 }).map((_, num) => (
            <button
              key={num}
              onClick={() => handleSelectNumber(num)}
              disabled={gameState.gameStatus !== 'idle'}
              className={`p-2 rounded-sm border-2 text-sm font-bold transition-all ${
                gameState.selectedNumber === num
                  ? 'border-yellow-600 bg-yellow-600/30'
                  : `border-${getNumberColor(num) === 'red' ? 'red' : getNumberColor(num) === 'black' ? 'gray' : 'green'}-600/30 bg-black/40`
              } disabled:opacity-50`}
            >
              {num}
            </button>
          ))}
        </div>
      </OSRSPanel>

      {/* Result Display */}
      {gameState.result !== null && (
        <div className={`p-6 rounded-lg text-center ${
          gameState.gameStatus === 'won'
            ? 'bg-green-600/20 border-2 border-green-600'
            : 'bg-red-600/20 border-2 border-red-600'
        }`}>
          <div className="text-4xl mb-3">
            {gameState.result === 0 ? '🟢' : getNumberColor(gameState.result) === 'red' ? '🔴' : '⚫'}
          </div>
          <div className="text-3xl font-bold mb-2">{gameState.result}</div>
          <div className={`text-2xl font-bold ${gameState.gameStatus === 'won' ? 'text-green-500' : 'text-red-500'}`}>
            {gameState.gameStatus === 'won' ? 'YOU WON!' : 'YOU LOST!'}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        {gameState.gameStatus === 'idle' && (
          <OSRSButton
            onClick={handleSpin}
            disabled={(!gameState.selectedNumber && !gameState.selectedColor) || gameState.isSpinning}
            className="flex-1"
          >
            {gameState.isSpinning ? 'SPINNING...' : 'SPIN THE WHEEL'}
          </OSRSButton>
        )}
        {(gameState.gameStatus === 'won' || gameState.gameStatus === 'lost') && (
          <OSRSButton onClick={handlePlayAgain} className="flex-1">
            PLAY AGAIN
          </OSRSButton>
        )}
      </div>
    </div>
  );
}
