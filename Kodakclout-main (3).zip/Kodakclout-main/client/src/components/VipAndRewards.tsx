/**
 * VIP and Rewards System Component
 * Display VIP tiers, cashback, lossback, daily bonuses, and achievements
 */

import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Crown, Gift, TrendingUp, Zap, Trophy, Calendar } from 'lucide-react';
import { toast } from 'sonner';

interface VipTier {
  tier: number;
  name: string;
  minEarnings: number;
  cashback: number;
  lossback: number;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  reward: number;
  unlocked: boolean;
}

export function VipAndRewards() {
  const [activeTab, setActiveTab] = useState<'vip' | 'rewards' | 'achievements'>('vip');
  const [vipStatus, setVipStatus] = useState({
    tier: { tier: 1, name: 'Bronze', minEarnings: 0, cashback: 0.5, lossback: 0.1 },
    totalEarnings: 50000,
    nextTierEarnings: 100000,
    progressToNextTier: 50,
    benefits: {
      cashback: 0.5,
      lossback: 0.1,
      rainBonus: 1,
      withdrawalFee: 0,
    },
  });
  const [dailyBonusStatus, setDailyBonusStatus] = useState({
    claimed: false,
    streak: 1,
    nextBonus: 2000,
  });
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadVipStatus();
    loadDailyBonusStatus();
    loadAchievements();
  }, []);

  const loadVipStatus = async () => {
    // Simulated VIP status
    setVipStatus({
      tier: { tier: 2, name: 'Silver', minEarnings: 100000, cashback: 1, lossback: 0.15 },
      totalEarnings: 150000,
      nextTierEarnings: 500000,
      progressToNextTier: 10,
      benefits: {
        cashback: 1,
        lossback: 0.15,
        rainBonus: 1.1,
        withdrawalFee: 0,
      },
    });
  };

  const loadDailyBonusStatus = async () => {
    setDailyBonusStatus({
      claimed: false,
      streak: 3,
      nextBonus: 4000,
    });
  };

  const loadAchievements = async () => {
    const mockAchievements: Achievement[] = [
      {
        id: 'first_bet',
        name: 'First Bet',
        description: 'Place your first bet',
        reward: 500,
        unlocked: true,
      },
      {
        id: 'first_win',
        name: 'First Win',
        description: 'Win your first game',
        reward: 1000,
        unlocked: true,
      },
      {
        id: 'big_winner',
        name: 'Big Winner',
        description: 'Win 100,000 GP in a single game',
        reward: 5000,
        unlocked: false,
      },
      {
        id: 'high_roller',
        name: 'High Roller',
        description: 'Wager 1,000,000 GP total',
        reward: 15000,
        unlocked: true,
      },
      {
        id: 'rain_dancer',
        name: 'Rain Dancer',
        description: 'Participate in 10 rain events',
        reward: 5000,
        unlocked: false,
      },
      {
        id: 'chat_master',
        name: 'Chat Master',
        description: 'Send 100 chat messages',
        reward: 2000,
        unlocked: false,
      },
    ];
    setAchievements(mockAchievements);
  };

  const handleClaimDailyBonus = async () => {
    try {
      setLoading(true);
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success(`Claimed daily bonus! Day ${dailyBonusStatus.streak}`);
      setDailyBonusStatus((prev) => ({
        ...prev,
        claimed: true,
        streak: Math.min(prev.streak + 1, 7),
      }));
    } catch (error) {
      toast.error('Failed to claim daily bonus');
    } finally {
      setLoading(false);
    }
  };

  const handleClaimAchievement = async (achievementId: string) => {
    try {
      setLoading(true);
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success('Achievement reward claimed!');
      setAchievements((prev) =>
        prev.map((a) =>
          a.id === achievementId ? { ...a, unlocked: false } : a
        )
      );
    } catch (error) {
      toast.error('Failed to claim achievement');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="glass-panel-gold p-6">
        <div className="flex flex-wrap gap-2 mb-6 border-b-2 border-yellow-600/30 pb-4">
          {[
            { id: 'vip', label: '👑 VIP Status' },
            { id: 'rewards', label: '🎁 Daily Rewards' },
            { id: 'achievements', label: '🏆 Achievements' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                'px-4 py-2 rounded-lg border-2 transition-all font-semibold text-sm md:text-base',
                activeTab === tab.id
                  ? 'glass-panel-gold border-yellow-600/60 text-yellow-600'
                  : 'glass-panel border-yellow-600/30 text-gray-400 hover:border-yellow-600/60'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* VIP Tab */}
        {activeTab === 'vip' && (
          <div className="space-y-6">
            {/* Current Tier */}
            <div className="glass-panel-crimson p-8 text-center">
              <Crown className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-red-500 mb-2">
                {vipStatus.tier.name} VIP
              </h2>
              <p className="text-gray-400 mb-4">
                Total Earnings: {vipStatus.totalEarnings.toLocaleString()} GP
              </p>

              {/* Progress to Next Tier */}
              <div className="mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-400">Progress to {vipStatus.tier.name === 'Diamond' ? 'Max' : 'Next'} Tier</span>
                  <span className="text-yellow-600 font-bold">
                    {vipStatus.progressToNextTier.toFixed(1)}%
                  </span>
                </div>
                <div className="progress-luxury">
                  <div
                    className="progress-luxury-fill"
                    style={{ width: `${vipStatus.progressToNextTier}%` }}
                  />
                </div>
                {vipStatus.tier.name !== 'Diamond' && (
                  <p className="text-xs text-gray-500 mt-2">
                    {(vipStatus.nextTierEarnings - vipStatus.totalEarnings).toLocaleString()} GP to next tier
                  </p>
                )}
              </div>
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass-panel p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  <h3 className="font-bold text-yellow-600">Cashback</h3>
                </div>
                <div className="text-2xl font-black text-green-500">
                  {vipStatus.benefits.cashback}%
                </div>
                <p className="text-xs text-gray-500 mt-2">On every win</p>
              </div>

              <div className="glass-panel p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  <h3 className="font-bold text-yellow-600">Lossback</h3>
                </div>
                <div className="text-2xl font-black text-yellow-500">
                  {(vipStatus.benefits.lossback * 100).toFixed(0)}%
                </div>
                <p className="text-xs text-gray-500 mt-2">On losses</p>
              </div>

              <div className="glass-panel p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Gift className="w-5 h-5 text-blue-500" />
                  <h3 className="font-bold text-yellow-600">Rain Bonus</h3>
                </div>
                <div className="text-2xl font-black text-blue-500">
                  {vipStatus.benefits.rainBonus}x
                </div>
                <p className="text-xs text-gray-500 mt-2">Multiplier</p>
              </div>

              <div className="glass-panel p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Crown className="w-5 h-5 text-purple-500" />
                  <h3 className="font-bold text-yellow-600">Withdrawal Fee</h3>
                </div>
                <div className="text-2xl font-black text-purple-500">
                  {vipStatus.benefits.withdrawalFee}%
                </div>
                <p className="text-xs text-gray-500 mt-2">On withdrawals</p>
              </div>
            </div>

            {/* All VIP Tiers */}
            <div className="glass-panel p-6">
              <h3 className="osrs-panel-title mb-4">VIP Tier Progression</h3>
              <div className="space-y-3">
                {[
                  { name: 'Bronze', earnings: 0, cashback: 0.5, lossback: 0.1 },
                  { name: 'Silver', earnings: 100000, cashback: 1, lossback: 0.15 },
                  { name: 'Gold', earnings: 500000, cashback: 1.5, lossback: 0.2 },
                  { name: 'Platinum', earnings: 1000000, cashback: 2, lossback: 0.25 },
                  { name: 'Diamond', earnings: 5000000, cashback: 3, lossback: 0.3 },
                ].map((tier) => (
                  <div
                    key={tier.name}
                    className={cn(
                      'p-3 rounded-lg border-2 flex items-center justify-between',
                      vipStatus.tier.name === tier.name
                        ? 'glass-panel-gold border-yellow-600/60 bg-yellow-600/10'
                        : 'glass-panel border-yellow-600/30'
                    )}
                  >
                    <div>
                      <div className="font-bold text-yellow-600">{tier.name}</div>
                      <div className="text-xs text-gray-500">
                        {tier.earnings.toLocaleString()} GP required
                      </div>
                    </div>
                    <div className="text-right text-xs">
                      <div className="text-green-500 font-bold">{tier.cashback}% Cashback</div>
                      <div className="text-yellow-500 font-bold">{(tier.lossback * 100).toFixed(0)}% Lossback</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Rewards Tab */}
        {activeTab === 'rewards' && (
          <div className="space-y-6">
            {/* Daily Bonus */}
            <div className="glass-panel-gold p-8 text-center">
              <Calendar className="w-16 h-16 text-yellow-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-yellow-600 mb-2">
                Day {dailyBonusStatus.streak} Bonus
              </h2>
              <div className="text-4xl font-black text-green-500 mb-6">
                {dailyBonusStatus.nextBonus.toLocaleString()} GP
              </div>

              <button
                onClick={handleClaimDailyBonus}
                disabled={dailyBonusStatus.claimed || loading}
                className={cn(
                  'btn-luxury w-full py-4 text-lg',
                  dailyBonusStatus.claimed && 'opacity-50 cursor-not-allowed'
                )}
              >
                {dailyBonusStatus.claimed ? 'Already Claimed Today' : 'Claim Daily Bonus'}
              </button>

              <p className="text-xs text-gray-500 mt-4">
                Come back tomorrow to continue your streak!
              </p>
            </div>

            {/* Bonus Schedule */}
            <div className="glass-panel p-6">
              <h3 className="osrs-panel-title mb-4">7-Day Bonus Schedule</h3>
              <div className="grid grid-cols-7 gap-2">
                {[
                  { day: 1, amount: 1000 },
                  { day: 2, amount: 2000 },
                  { day: 3, amount: 3000 },
                  { day: 4, amount: 4000 },
                  { day: 5, amount: 5000 },
                  { day: 6, amount: 7500 },
                  { day: 7, amount: 10000 },
                ].map((bonus) => (
                  <div
                    key={bonus.day}
                    className={cn(
                      'p-3 rounded-lg border-2 text-center',
                      dailyBonusStatus.streak >= bonus.day
                        ? 'glass-panel-gold border-yellow-600/60 bg-yellow-600/10'
                        : 'glass-panel border-yellow-600/30'
                    )}
                  >
                    <div className="text-xs font-bold text-gray-400 mb-1">Day {bonus.day}</div>
                    <div className="text-sm font-bold text-yellow-600">
                      {bonus.amount.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Achievements Tab */}
        {activeTab === 'achievements' && (
          <div className="space-y-4">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={cn(
                  'p-4 rounded-lg border-2 flex items-center justify-between',
                  achievement.unlocked
                    ? 'glass-panel-gold border-yellow-600/60 bg-yellow-600/10'
                    : 'glass-panel border-yellow-600/30 opacity-60'
                )}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Trophy className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-bold text-yellow-600">{achievement.name}</h3>
                  </div>
                  <p className="text-sm text-gray-400">{achievement.description}</p>
                  <div className="text-xs text-gray-500 mt-2">
                    Reward: {achievement.reward.toLocaleString()} GP
                  </div>
                </div>

                {achievement.unlocked && (
                  <button
                    onClick={() => handleClaimAchievement(achievement.id)}
                    disabled={loading}
                    className="btn-luxury px-4 py-2 text-sm ml-4 flex-shrink-0"
                  >
                    Claim
                  </button>
                )}

                {!achievement.unlocked && (
                  <div className="text-xs text-gray-500 ml-4 flex-shrink-0">
                    Locked
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
