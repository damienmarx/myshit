/**
 * Comprehensive Wallet System Component
 * Deposit, withdraw, transaction history, and balance management
 */

import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { ArrowDownLeft, ArrowUpRight, TrendingUp, History, Plus, Minus } from 'lucide-react';
import { toast } from 'sonner';

interface Transaction {
  id: number;
  type: 'deposit' | 'withdraw' | 'bet' | 'win' | 'rain';
  amount: number;
  balance: number;
  description: string;
  timestamp: string;
  status: 'completed' | 'pending' | 'failed';
}

interface WalletStats {
  totalBalance: number;
  totalDeposited: number;
  totalWithdrawn: number;
  totalWagered: number;
  totalWinnings: number;
  netProfit: number;
}

export function WalletSystem() {
  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw' | 'history'>('overview');
  const [walletStats, setWalletStats] = useState<WalletStats>({
    totalBalance: 250000,
    totalDeposited: 500000,
    totalWithdrawn: 150000,
    totalWagered: 300000,
    totalWinnings: 400000,
    netProfit: 100000,
  });
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadTransactionHistory();
  }, []);

  const loadTransactionHistory = async () => {
    try {
      setLoading(true);
      // Simulated transaction data
      const mockTransactions: Transaction[] = [
        {
          id: 1,
          type: 'win',
          amount: 50000,
          balance: 250000,
          description: 'Won on Flower Poker (5x multiplier)',
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          status: 'completed',
        },
        {
          id: 2,
          type: 'bet',
          amount: -10000,
          balance: 200000,
          description: 'Bet on Crash game',
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          status: 'completed',
        },
        {
          id: 3,
          type: 'rain',
          amount: 5000,
          balance: 210000,
          description: 'Rain event distribution',
          timestamp: new Date(Date.now() - 10800000).toISOString(),
          status: 'completed',
        },
        {
          id: 4,
          type: 'deposit',
          amount: 100000,
          balance: 205000,
          description: 'OSRS gold deposit',
          timestamp: new Date(Date.now() - 86400000).toISOString(),
          status: 'completed',
        },
      ];

      setTransactions(mockTransactions);
    } catch (error) {
      toast.error('Failed to load transaction history');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();

    const amount = parseFloat(depositAmount);

    if (!amount || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (amount > 10000000) {
      toast.error('Maximum deposit is 10M GP');
      return;
    }

    try {
      setLoading(true);

      // Simulate deposit
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setWalletStats((prev) => ({
        ...prev,
        totalBalance: prev.totalBalance + amount,
        totalDeposited: prev.totalDeposited + amount,
      }));

      const newTransaction: Transaction = {
        id: transactions.length + 1,
        type: 'deposit',
        amount,
        balance: walletStats.totalBalance + amount,
        description: `OSRS gold deposit - ${amount} GP`,
        timestamp: new Date().toISOString(),
        status: 'completed',
      };

      setTransactions((prev) => [newTransaction, ...prev]);
      setDepositAmount('');

      toast.success(`Deposited ${amount.toLocaleString()} GP`);
    } catch (error) {
      toast.error('Deposit failed');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();

    const amount = parseFloat(withdrawAmount);

    if (!amount || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (amount > walletStats.totalBalance) {
      toast.error('Insufficient balance');
      return;
    }

    try {
      setLoading(true);

      // Simulate withdrawal
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setWalletStats((prev) => ({
        ...prev,
        totalBalance: prev.totalBalance - amount,
        totalWithdrawn: prev.totalWithdrawn + amount,
      }));

      const newTransaction: Transaction = {
        id: transactions.length + 1,
        type: 'withdraw',
        amount: -amount,
        balance: walletStats.totalBalance - amount,
        description: `OSRS gold withdrawal - ${amount} GP`,
        timestamp: new Date().toISOString(),
        status: 'completed',
      };

      setTransactions((prev) => [newTransaction, ...prev]);
      setWithdrawAmount('');

      toast.success(`Withdrew ${amount.toLocaleString()} GP`);
    } catch (error) {
      toast.error('Withdrawal failed');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
      case 'rain':
      case 'win':
        return <ArrowDownLeft className="w-5 h-5 text-green-500" />;
      case 'withdraw':
      case 'bet':
        return <ArrowUpRight className="w-5 h-5 text-red-500" />;
      default:
        return <History className="w-5 h-5 text-gray-500" />;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'deposit':
      case 'rain':
      case 'win':
        return 'bg-green-600/10 border-green-600/30';
      case 'withdraw':
      case 'bet':
        return 'bg-red-600/10 border-red-600/30';
      default:
        return 'bg-gray-600/10 border-gray-600/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Wallet Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="stat-box">
          <div className="stat-box-label">💰 Total Balance</div>
          <div className="stat-box-value">{walletStats.totalBalance.toLocaleString()} GP</div>
          <div className="text-xs text-gray-500 mt-2">Available to play</div>
        </div>

        <div className="stat-box">
          <div className="stat-box-label">📈 Total Winnings</div>
          <div className="stat-box-value text-green-500">
            +{walletStats.totalWinnings.toLocaleString()} GP
          </div>
          <div className="text-xs text-gray-500 mt-2">From all games</div>
        </div>

        <div className="stat-box">
          <div className="stat-box-label">📊 Net Profit</div>
          <div className={cn('stat-box-value', walletStats.netProfit >= 0 ? 'text-green-500' : 'text-red-500')}>
            {walletStats.netProfit >= 0 ? '+' : ''}{walletStats.netProfit.toLocaleString()} GP
          </div>
          <div className="text-xs text-gray-500 mt-2">Total earnings</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="glass-panel-gold p-6">
        <div className="flex flex-wrap gap-2 mb-6 border-b-2 border-yellow-600/30 pb-4">
          {[
            { id: 'overview', label: '📊 Overview' },
            { id: 'deposit', label: '➕ Deposit' },
            { id: 'withdraw', label: '➖ Withdraw' },
            { id: 'history', label: '📜 History' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                'px-4 py-2 rounded-lg border-2 transition-all font-semibold text-sm md:text-base',
                activeTab === tab.id
                  ? 'glass-panel-gold border-yellow-600/60 text-yellow-600'
                  : 'glass-panel border-yellow-600/30 text-gray-400 hover:border-yellow-600/60'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass-panel p-4">
                <div className="text-sm text-gray-400 mb-2">Total Deposited</div>
                <div className="text-2xl font-bold text-green-500">
                  +{walletStats.totalDeposited.toLocaleString()} GP
                </div>
              </div>
              <div className="glass-panel p-4">
                <div className="text-sm text-gray-400 mb-2">Total Withdrawn</div>
                <div className="text-2xl font-bold text-red-500">
                  -{walletStats.totalWithdrawn.toLocaleString()} GP
                </div>
              </div>
              <div className="glass-panel p-4">
                <div className="text-sm text-gray-400 mb-2">Total Wagered</div>
                <div className="text-2xl font-bold text-yellow-600">
                  {walletStats.totalWagered.toLocaleString()} GP
                </div>
              </div>
              <div className="glass-panel p-4">
                <div className="text-sm text-gray-400 mb-2">Win Rate</div>
                <div className="text-2xl font-bold text-blue-500">
                  {((walletStats.totalWinnings / walletStats.totalWagered) * 100).toFixed(1)}%
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Deposit Tab */}
        {activeTab === 'deposit' && (
          <form onSubmit={handleDeposit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-yellow-600 mb-2">
                Amount to Deposit (GP)
              </label>
              <input
                type="number"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="Enter amount"
                min="0"
                max="10000000"
                className="input-luxury w-full"
              />
              <div className="text-xs text-gray-500 mt-2">Min: 1 GP | Max: 10M GP</div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[10000, 50000, 100000, 500000].map((amount) => (
                <button
                  key={amount}
                  type="button"
                  onClick={() => setDepositAmount(amount.toString())}
                  className="btn-luxury text-xs py-2"
                >
                  {(amount / 1000).toFixed(0)}K
                </button>
              ))}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-luxury w-full py-3 flex items-center justify-center gap-2"
            >
              <Plus className="w-5 h-5" />
              {loading ? 'Processing...' : 'Deposit Now'}
            </button>
          </form>
        )}

        {/* Withdraw Tab */}
        {activeTab === 'withdraw' && (
          <form onSubmit={handleWithdraw} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-yellow-600 mb-2">
                Amount to Withdraw (GP)
              </label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="Enter amount"
                min="0"
                max={walletStats.totalBalance}
                className="input-luxury w-full"
              />
              <div className="text-xs text-gray-500 mt-2">
                Available: {walletStats.totalBalance.toLocaleString()} GP
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[10000, 50000, 100000, 500000].map((amount) => (
                <button
                  key={amount}
                  type="button"
                  onClick={() => setWithdrawAmount(amount.toString())}
                  disabled={amount > walletStats.totalBalance}
                  className={cn('btn-luxury text-xs py-2', amount > walletStats.totalBalance && 'opacity-50 cursor-not-allowed')}
                >
                  {(amount / 1000).toFixed(0)}K
                </button>
              ))}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-luxury-crimson w-full py-3 flex items-center justify-center gap-2"
            >
              <Minus className="w-5 h-5" />
              {loading ? 'Processing...' : 'Withdraw Now'}
            </button>
          </form>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="space-y-3">
            {loading ? (
              <div className="text-center text-gray-400 py-8">Loading transactions...</div>
            ) : transactions.length === 0 ? (
              <div className="text-center text-gray-400 py-8">No transactions yet</div>
            ) : (
              transactions.map((tx) => (
                <div
                  key={tx.id}
                  className={cn(
                    'p-4 rounded-lg border-2 flex items-center justify-between',
                    getTransactionColor(tx.type)
                  )}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {getTransactionIcon(tx.type)}
                    <div className="min-w-0">
                      <div className="font-semibold text-sm md:text-base truncate">
                        {tx.description}
                      </div>
                      <div className="text-xs text-gray-500">
                        {new Date(tx.timestamp).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right ml-4 flex-shrink-0">
                    <div
                      className={cn(
                        'font-bold text-sm md:text-base',
                        tx.amount > 0 ? 'text-green-500' : 'text-red-500'
                      )}
                    >
                      {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString()} GP
                    </div>
                    <div className="text-xs text-gray-500">
                      Balance: {tx.balance.toLocaleString()} GP
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
