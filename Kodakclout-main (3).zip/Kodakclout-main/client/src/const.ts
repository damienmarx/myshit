export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Login URL points to the OAuth callback route on the same origin.
export const getLoginUrl = () => {
  return "/api/oauth/callback";
};
