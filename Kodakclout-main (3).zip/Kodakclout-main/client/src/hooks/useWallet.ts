import { trpc } from '@/lib/trpc';
import { useCallback } from 'react';

export function useWallet() {
  const utils = trpc.useUtils();
  const balanceQuery = trpc.wallet.getBalance.useQuery();
  const statsQuery = trpc.wallet.getStats.useQuery();
  const historyQuery = trpc.wallet.getHistory.useQuery({ limit: 20, offset: 0 });

  const placeBetMutation = trpc.wallet.placeBet.useMutation();
  const recordWinMutation = trpc.wallet.recordWin.useMutation();
  const recordLossMutation = trpc.wallet.recordLoss.useMutation();

  const placeBet = useCallback(
    async (gameType: string | 'flower_poker' | 'hot_cold' | 'dice' | 'crash', betAmount: number) => {
      try {
        const result = await placeBetMutation.mutateAsync({
          gameType: gameType as 'flower_poker' | 'hot_cold' | 'dice' | 'crash',
          betAmount,
        });
        return result;
      } catch (error) {
        console.error('Failed to place bet:', error);
        throw error;
      }
    },
    [placeBetMutation]
  );

  const recordWin = useCallback(
    async (gameType: string | 'flower_poker' | 'hot_cold' | 'dice' | 'crash', betAmount: number, multiplier: number, winAmount: number, gameResult?: Record<string, any>) => {
      try {
        const result = await recordWinMutation.mutateAsync({
          gameType: gameType as 'flower_poker' | 'hot_cold' | 'dice' | 'crash',
          betAmount,
          multiplier,
          winAmount,
          gameResult,
        });
        // Invalidate balance and stats queries
        await utils.wallet.getBalance.invalidate();
        await utils.wallet.getStats.invalidate();
        await utils.wallet.getHistory.invalidate();
        return result;
      } catch (error) {
        console.error('Failed to record win:', error);
        throw error;
      }
    },
    [recordWinMutation, utils]
  );

  const recordLoss = useCallback(
    async (gameType: string | 'flower_poker' | 'hot_cold' | 'dice' | 'crash', betAmount: number, gameResult?: Record<string, any>) => {
      try {
        const result = await recordLossMutation.mutateAsync({
          gameType: gameType as 'flower_poker' | 'hot_cold' | 'dice' | 'crash',
          betAmount,
          gameResult,
        });
        // Invalidate balance and stats queries
        await utils.wallet.getBalance.invalidate();
        await utils.wallet.getStats.invalidate();
        await utils.wallet.getHistory.invalidate();
        return result;
      } catch (error) {
        console.error('Failed to record loss:', error);
        throw error;
      }
    },
    [recordLossMutation, utils]
  );

  return {
    balance: balanceQuery.data?.balance || 0,
    totalWagered: balanceQuery.data?.totalWagered || 0,
    totalWon: balanceQuery.data?.totalWon || 0,
    stats: statsQuery.data,
    history: historyQuery.data || [],
    isLoadingBalance: balanceQuery.isLoading,
    isLoadingStats: statsQuery.isLoading,
    placeBet,
    recordWin,
    recordLoss,
    placeBetLoading: placeBetMutation.isPending,
    recordWinLoading: recordWinMutation.isPending,
    recordLossLoading: recordLossMutation.isPending,
  };
}
