import { useState } from 'react';
import { trpc } from '../lib/trpc';
import { Button } from '../components/ui/button';

export default function FlowerPoker() {
  const [result, setResult] = useState<any>(null);
  const playMutation = trpc.poker.play.useMutation();

  const handlePlant = async () => {
    try {
      const res = await playMutation.mutateAsync({ betAmount: 1000000 });
      setResult(res);
    } catch (e) {
      console.error("Bet failed", e);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#d4af37] p-8 font-mono flex flex-col items-center">
      <h1 className="text-4xl border-b-2 border-[#990000] mb-8 shadow-[0_0_15px_rgba(153,0,0,0.5)]">HOSTED FLOWER POKER</h1>
      <div className="bg-[#0a0a0a] border-2 border-[#d4af37] p-12 rounded-lg text-center max-w-2xl w-full">
        <div className="flex justify-center gap-4 mb-8">
          {result?.flowers ? result.flowers.map((f: string, i: number) => (
            <div key={i} className="w-16 h-16 bg-[#1a1a1a] border border-[#990000] rounded flex items-center justify-center text-2xl shadow-glow">
              {f === 'Red' ? '🔴' : f === 'Blue' ? '🔵' : '🌻'}
            </div>
          )) : <div className="text-gray-500 italic">Ready to Plant...</div>}
        </div>
        <Button 
          onClick={handlePlant} 
          disabled={playMutation.isPending}
          className="bg-[#990000] hover:bg-[#d4af37] text-white px-12 py-8 text-2xl font-bold rounded-none border-b-4 border-black active:translate-y-1 transition-all"
        >
          {playMutation.isPending ? 'PLANTING...' : 'PLANT FLOWERS (1.0M)'}
        </Button>
        {result && (
          <div className={`mt-8 text-3xl font-bold animate-pulse ${result.win ? 'text-green-500' : 'text-[#990000]'}`}>
            {result.win ? 'WINNER!' : 'LOST'}
          </div>
        )}
      </div>
    </div>
  );
}
