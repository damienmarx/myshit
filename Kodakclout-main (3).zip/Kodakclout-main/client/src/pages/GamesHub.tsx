/**
 * Games Hub Page
 * Central hub for all available games with descriptions and quick access
 */

import React, { useState } from 'react';
import { FlowerPokerGame } from '@/components/FlowerPokerGame';
import { HotColdGame } from '@/components/HotColdGame';
import { RouletteGameEnhanced } from '@/components/RouletteGameEnhanced';
import { KenoGameEnhanced } from '@/components/KenoGameEnhanced';
import { PlinkoGameEnhanced } from '@/components/PlinkoGameEnhanced';
import { DiceGamePolished } from '@/components/DiceGamePolished';
import { CrashGamePolished } from '@/components/CrashGamePolished';
import { DiceGame } from '@/components/DiceGame';
import { CrashGame } from '@/components/CrashGame';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const GAMES = [
  {
    id: 'flower-poker',
    name: 'Flower Poker',
    emoji: '🌹',
    description: '5x5 grid matching game with 8 flower types',
    maxMultiplier: '2x',
    rtp: '98%',
    component: FlowerPokerGame,
  },
  {
    id: 'hot-cold',
    name: 'Hot & Cold',
    emoji: '🔥',
    description: 'Simple 50/50 prediction game',
    maxMultiplier: '2x',
    rtp: '99%',
    component: HotColdGame,
  },
  {
    id: 'roulette',
    name: 'Roulette',
    emoji: '🎡',
    description: 'Classic roulette wheel with 37 numbers',
    maxMultiplier: '36x',
    rtp: '97%',
    component: RouletteGameEnhanced,
  },
  {
    id: 'keno',
    name: 'Keno',
    emoji: '🎯',
    description: 'Select up to 10 numbers from 80',
    maxMultiplier: '500x',
    rtp: '96%',
    component: KenoGameEnhanced,
  },
  {
    id: 'plinko',
    name: 'Plinko',
    emoji: '⚪',
    description: 'Ball drops through pegs into buckets',
    maxMultiplier: '3x',
    rtp: '98%',
    component: PlinkoGameEnhanced,
  },
  {
    id: 'dice',
    name: 'Dice',
    emoji: '🎲',
    description: 'Roll the dice and match your number',
    maxMultiplier: '6x',
    rtp: '98%',
    component: DiceGamePolished,
  },
  {
    id: 'crash',
    name: 'Crash',
    emoji: '💥',
    description: 'Watch the multiplier climb, cash out before it crashes',
    maxMultiplier: '∞',
    rtp: '97%',
    component: CrashGamePolished,
  },
];

export function GamesHub() {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  if (selectedGame) {
    const game = GAMES.find((g) => g.id === selectedGame);
    if (game) {
      const GameComponent = game.component;
      return (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gradient-gold">{game.emoji} {game.name}</h1>
              <p className="text-gray-400 mt-2">{game.description}</p>
            </div>
            <button
              onClick={() => setSelectedGame(null)}
              className="btn-luxury-crimson"
            >
              ← Back to Games
            </button>
          </div>

          <div className="glass-panel p-6 grid grid-cols-3 gap-6">
            <div>
              <div className="text-xs uppercase tracking-widest text-gray-400 mb-2">Max Multiplier</div>
              <div className="text-2xl font-bold text-yellow-600">{game.maxMultiplier}</div>
            </div>
            <div>
              <div className="text-xs uppercase tracking-widest text-gray-400 mb-2">RTP</div>
              <div className="text-2xl font-bold text-yellow-600">{game.rtp}</div>
            </div>
            <div>
              <div className="text-xs uppercase tracking-widest text-gray-400 mb-2">Status</div>
              <div className="text-2xl font-bold text-green-500">LIVE</div>
            </div>
          </div>

          <GameComponent />
        </div>
      );
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="glass-panel-gold p-12 text-center">
        <h1 className="text-4xl font-bold text-gradient-gold mb-4">🎮 GAMES HUB</h1>
        <p className="text-gray-400 text-lg">
          Choose from our collection of provably fair games with instant payouts
        </p>
      </div>

      {/* Games Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {GAMES.map((game) => {
          return (
            <div
              key={game.id}
              onClick={() => setSelectedGame(game.id)}
              className="card-luxury cursor-pointer group"
            >
              <div className="text-6xl mb-4 group-hover:scale-125 transition-transform">
                {game.emoji}
              </div>
              <h3 className="text-xl font-bold text-yellow-600 mb-2">{game.name}</h3>
              <p className="text-sm text-gray-400 mb-4 line-clamp-2">{game.description}</p>

              <div className="space-y-2 mb-4 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-500">Max Multiplier:</span>
                  <span className="text-yellow-600 font-bold">{game.maxMultiplier}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">RTP:</span>
                  <span className="text-yellow-600 font-bold">{game.rtp}</span>
                </div>
              </div>

              <button className="btn-luxury w-full text-sm">
                PLAY NOW
              </button>
            </div>
          );
        })}
      </div>

      {/* Features */}
      <div className="glass-panel-gold p-12">
        <h2 className="text-2xl font-bold text-gradient-gold mb-6">Why Our Games?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div className="text-3xl mb-3">✅</div>
            <h3 className="font-bold text-yellow-600 mb-2">Provably Fair</h3>
            <p className="text-sm text-gray-400">
              Every game result is cryptographically verified. Check the proof anytime.
            </p>
          </div>
          <div>
            <div className="text-3xl mb-3">⚡</div>
            <h3 className="font-bold text-yellow-600 mb-2">Instant Payouts</h3>
            <p className="text-sm text-gray-400">
              Win and get paid instantly. No delays, no complications.
            </p>
          </div>
          <div>
            <div className="text-3xl mb-3">🎯</div>
            <h3 className="font-bold text-yellow-600 mb-2">High RTP</h3>
            <p className="text-sm text-gray-400">
              Industry-leading return to player rates on all games.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
