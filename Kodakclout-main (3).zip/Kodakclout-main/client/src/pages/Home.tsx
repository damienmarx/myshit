import React, { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { useLocation } from 'wouter';
import { LoginDialog } from '@/components/LoginDialog';
import {
  Flower2,
  Dices,
  Zap,
  Flame,
  Trophy,
  Users,
  Crown,
  TrendingUp,
  LogOut,
  Wallet,
  Settings,
} from 'lucide-react';

interface Game {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  minBet: number;
  maxBet: number;
  rtp: number;
  status: 'available' | 'coming-soon' | 'maintenance';
  color: string;
}

const GAMES: Game[] = [
  {
    id: 'flower-poker',
    name: 'Flower Poker',
    icon: <Flower2 className="w-8 h-8" />,
    description: '5x5 grid game. Plant flowers and match 5 in a row to win.',
    minBet: 100,
    maxBet: 50000,
    rtp: 96.5,
    status: 'available',
    color: 'from-rose-600 to-pink-600',
  },
  {
    id: 'keno',
    name: 'Keno',
    icon: <Trophy className="w-8 h-8" />,
    description: 'Pick numbers and watch them draw. Classic 80-ball Keno.',
    minBet: 50,
    maxBet: 100000,
    rtp: 95.0,
    status: 'available',
    color: 'from-blue-600 to-cyan-600',
  },
  {
    id: 'roulette',
    name: 'Roulette',
    icon: <Zap className="w-8 h-8" />,
    description: 'Spin the wheel. Bet on numbers, colors, or ranges.',
    minBet: 100,
    maxBet: 100000,
    rtp: 97.3,
    status: 'available',
    color: 'from-red-600 to-orange-600',
  },
  {
    id: 'plinko',
    name: 'Plinko',
    icon: <Dices className="w-8 h-8" />,
    description: 'Drop balls down the board. Land on multipliers to win big.',
    minBet: 100,
    maxBet: 50000,
    rtp: 96.0,
    status: 'available',
    color: 'from-purple-600 to-indigo-600',
  },
  {
    id: 'lucky-wheel',
    name: 'Lucky Wheel',
    icon: <Crown className="w-8 h-8" />,
    description: 'Spin the lucky wheel. Win instant prizes and multipliers.',
    minBet: 100,
    maxBet: 50000,
    rtp: 94.5,
    status: 'available',
    color: 'from-yellow-600 to-amber-600',
  },
  {
    id: 'dice',
    name: 'Dice',
    icon: <Dices className="w-8 h-8" />,
    description: 'Roll the dice. Guess high or low, odd or even.',
    minBet: 50,
    maxBet: 100000,
    rtp: 98.0,
    status: 'available',
    color: 'from-green-600 to-emerald-600',
  },
  {
    id: 'crash',
    name: 'Crash',
    icon: <TrendingUp className="w-8 h-8" />,
    description: 'Watch the multiplier climb. Cash out before it crashes!',
    minBet: 100,
    maxBet: 100000,
    rtp: 97.0,
    status: 'available',
    color: 'from-teal-600 to-cyan-600',
  },
  {
    id: 'hot-cold',
    name: 'Hot/Cold',
    icon: <Flame className="w-8 h-8" />,
    description: '50/50 chance. Pick hot or cold and double your bet.',
    minBet: 100,
    maxBet: 50000,
    rtp: 95.0,
    status: 'coming-soon',
    color: 'from-orange-600 to-red-600',
  },
];

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-obsidian flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <Crown className="w-12 h-12 text-osrs-gold" />
          </div>
          <p className="text-gray-400">Loading CloutScape Engine...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-obsidian flex flex-col items-center justify-center p-4">
        <div className="text-center max-w-2xl">
          <div className="mb-8">
            <Crown className="w-20 h-20 text-osrs-gold mx-auto mb-6 animate-glow-pulse" />
                <h1 className="brand-text mb-4">CLOUTSCAPE</h1>
            <p className="brand-subtitle text-2xl mb-4">Premium OSRS-Inspired Casino</p>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-8">
              Experience the ultimate luxury gaming platform with provably fair games, instant payouts, and exclusive rain events.
            </p>
            <button
              onClick={() => navigate('/login')}
              className="btn-luxury"
            >
              START PLAYING NOW
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-panel-dark/50 border border-osrs-gold/20 rounded p-4">
              <Zap className="w-6 h-6 text-osrs-gold mx-auto mb-2" />
              <p className="text-gray-300 font-semibold">Instant Payouts</p>
            </div>
            <div className="bg-panel-dark/50 border border-osrs-gold/20 rounded p-4">
              <Trophy className="w-6 h-6 text-osrs-gold mx-auto mb-2" />
              <p className="text-gray-300 font-semibold">Provably Fair</p>
            </div>
            <div className="bg-panel-dark/50 border border-osrs-gold/20 rounded p-4">
              <Users className="w-6 h-6 text-osrs-gold mx-auto mb-2" />
              <p className="text-gray-300 font-semibold">Live Community</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-obsidian">
      {/* Header */}
      <header className="bg-panel-dark border-b-2 border-osrs-gold/30 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Crown className="w-8 h-8 text-osrs-gold" />
            <h1 className="text-2xl font-black text-osrs-gold tracking-wider">CLOUTSCAPE</h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-black/50 rounded-sm border border-osrs-gold/20">
              <Wallet className="w-4 h-4 text-osrs-gold" />
              <span className="text-osrs-gold font-bold">{user?.name || 'Player'}</span>
            </div>

            <button
              onClick={() => logout()}
              className="p-2 hover:bg-black/50 rounded-sm transition-colors text-gray-400 hover:text-osrs-gold"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-black text-osrs-gold mb-4 tracking-wider">
            WELCOME BACK, {user?.name?.toUpperCase() || 'PLAYER'}
          </h2>
          <p className="text-gray-400 text-lg">
            Select a game below and start playing. All games are provably fair.
          </p>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {GAMES.map((game) => (
            <div
              key={game.id}
              onClick={() => {
                if (game.status === 'available') {
                  window.location.href = `/game/${game.id}`;
                }
              }}
              className={`relative overflow-hidden rounded-lg border-2 transition-all cursor-pointer group ${
                game.status === 'available'
                  ? 'border-osrs-gold/50 hover:border-osrs-gold hover:shadow-lg hover:shadow-osrs-gold/30'
                  : 'border-gray-600/50 opacity-60 cursor-not-allowed'
              }`}
            >
              {/* Background Gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${game.color} opacity-10 group-hover:opacity-20 transition-opacity`} />

              {/* Content */}
              <div className="relative p-6 bg-panel-dark/80 backdrop-blur-sm h-full flex flex-col">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-osrs-gold group-hover:scale-110 transition-transform">
                    {game.icon}
                  </div>
                  {game.status === 'coming-soon' && (
                    <span className="text-xs font-bold text-crimson-red bg-crimson-red/20 px-2 py-1 rounded">
                      COMING SOON
                    </span>
                  )}
                </div>

                <h3 className="text-xl font-black text-white mb-2 group-hover:text-osrs-gold transition-colors">
                  {game.name}
                </h3>

                <p className="text-sm text-gray-400 mb-4 flex-grow">{game.description}</p>

                <div className="space-y-2 text-xs text-gray-500 mb-4 border-t border-osrs-gold/20 pt-4">
                  <div className="flex justify-between">
                    <span>Min Bet:</span>
                    <span className="text-osrs-gold font-bold">{game.minBet.toLocaleString()} GP</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Max Bet:</span>
                    <span className="text-osrs-gold font-bold">{game.maxBet.toLocaleString()} GP</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RTP:</span>
                    <span className="text-osrs-gold font-bold">{game.rtp}%</span>
                  </div>
                </div>

                {game.status === 'available' && (
                  <button className="w-full py-2 bg-osrs-gold text-black font-bold uppercase tracking-widest rounded-sm hover:bg-yellow-500 transition-colors text-sm">
                    PLAY NOW
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-panel-dark border-2 border-osrs-gold/30 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-osrs-gold font-bold uppercase tracking-wider">Your Balance</h3>
              <Wallet className="w-5 h-5 text-osrs-gold" />
            </div>
            <p className="text-3xl font-black text-white">100,000 GP</p>
            <p className="text-xs text-gray-500 mt-2">Total wagered: 50,000 GP</p>
          </div>

          <div className="bg-panel-dark border-2 border-osrs-gold/30 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-osrs-gold font-bold uppercase tracking-wider">Lifetime Wins</h3>
              <Trophy className="w-5 h-5 text-osrs-gold" />
            </div>
            <p className="text-3xl font-black text-white">24</p>
            <p className="text-xs text-gray-500 mt-2">Win rate: 48%</p>
          </div>

          <div className="bg-panel-dark border-2 border-osrs-gold/30 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-osrs-gold font-bold uppercase tracking-wider">Leaderboard Rank</h3>
              <Crown className="w-5 h-5 text-osrs-gold" />
            </div>
            <p className="text-3xl font-black text-white">#1,234</p>
            <p className="text-xs text-gray-500 mt-2">Earnings: 250,000 GP</p>
          </div>
        </div>
      </main>
    </div>
  );
}
