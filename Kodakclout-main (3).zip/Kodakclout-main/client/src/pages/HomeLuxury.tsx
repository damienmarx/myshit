/**
 * Luxury Home Page
 * Stake/Runehall-inspired dashboard with glassmorphism design
 */

import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Flame, Trophy, Zap, Users, Cloud, TrendingUp } from 'lucide-react';

export function HomeLuxury() {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="glass-panel-gold p-12 text-center">
        <div className="brand-text mb-4">7DEGEN7DEN7</div>
        <div className="brand-subtitle text-2xl mb-4">DEGENS DEN - Where Legends Are Made</div>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-8">
          Experience the ultimate luxury gaming platform with provably fair games, instant payouts, and exclusive rain events.
        </p>
        <button className="btn-luxury">
          START PLAYING NOW
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="stat-box">
          <div className="stat-box-label">🎮 Games Available</div>
          <div className="stat-box-value">8+</div>
          <div className="text-xs text-gray-500 mt-2">Flower Poker, Roulette, Keno, Plinko & More</div>
        </div>
        <div className="stat-box">
          <div className="stat-box-label">💰 Total Distributed</div>
          <div className="stat-box-value">5M+ GP</div>
          <div className="text-xs text-gray-500 mt-2">To active players this month</div>
        </div>
        <div className="stat-box">
          <div className="stat-box-label">👥 Active Players</div>
          <div className="stat-box-value">1.2K</div>
          <div className="text-xs text-gray-500 mt-2">Playing right now</div>
        </div>
        <div className="stat-box">
          <div className="stat-box-label">🌧️ Rain Events</div>
          <div className="stat-box-value">24/7</div>
          <div className="text-xs text-gray-500 mt-2">Continuous rewards</div>
        </div>
      </div>

      {/* Featured Games */}
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-gradient-gold">Featured Games</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { name: 'Flower Poker', emoji: '🌹', description: '5x5 grid matching game', multiplier: '2x' },
            { name: 'Hot & Cold', emoji: '🔥', description: '50/50 prediction game', multiplier: '2x' },
            { name: 'Roulette', emoji: '🎡', description: 'Classic roulette wheel', multiplier: '36x' },
            { name: 'Keno', emoji: '🎯', description: 'Select & match numbers', multiplier: '500x' },
          ].map((game) => (
            <div key={game.name} className="card-luxury group">
              <div className="text-5xl mb-4 group-hover:scale-110 transition-transform">{game.emoji}</div>
              <h3 className="text-lg font-bold text-yellow-600 mb-2">{game.name}</h3>
              <p className="text-sm text-gray-400 mb-4">{game.description}</p>
              <div className="flex items-center justify-between">
                <span className="badge-luxury">Max {game.multiplier}</span>
                <button className="btn-luxury text-xs px-3 py-1">Play</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-gradient-gold">Why Choose DegensDen?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            {
              icon: Flame,
              title: 'Provably Fair',
              description: 'Every game is cryptographically verified for fairness. Check the proof anytime.',
            },
            {
              icon: Zap,
              title: 'Instant Payouts',
              description: 'Win big and get paid instantly. No delays, no complications.',
            },
            {
              icon: Cloud,
              title: 'Rain Events',
              description: 'Participate in random rain events and earn passive rewards just for playing.',
            },
            {
              icon: Trophy,
              title: 'Leaderboards',
              description: 'Compete with other players and earn exclusive rewards for top rankings.',
            },
            {
              icon: Users,
              title: 'Live Chat',
              description: 'Connect with the community in real-time. Share wins, strategies, and celebrate together.',
            },
            {
              icon: TrendingUp,
              title: 'OSRS Integration',
              description: 'Seamless integration with OSRS gold. Deposit and withdraw with ease.',
            },
          ].map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="glass-panel p-6 flex gap-4">
                <Icon className="w-8 h-8 text-yellow-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg font-bold text-yellow-600 mb-2">{feature.title}</h3>
                  <p className="text-sm text-gray-400">{feature.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* CTA Section */}
      <div className="glass-panel-crimson p-12 text-center">
        <h2 className="text-3xl font-bold text-red-500 mb-4">Ready to Join the Degens?</h2>
        <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
          Sign up now and get instant access to all games, exclusive rain events, and the vibrant DegensDen community.
        </p>
        <button className="btn-luxury-crimson">
          CREATE ACCOUNT
        </button>
      </div>
    </div>
  );
}
