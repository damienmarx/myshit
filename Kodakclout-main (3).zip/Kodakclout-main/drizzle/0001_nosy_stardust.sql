CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`username` varchar(64) NOT NULL,
	`message` text NOT NULL,
	`channel` enum('lobby','game') NOT NULL DEFAULT 'lobby',
	`gameId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fairnessSeeds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameId` int NOT NULL,
	`clientSeed` varchar(255) NOT NULL,
	`serverSeed` varchar(255) NOT NULL,
	`serverSeedHash` varchar(255) NOT NULL,
	`nonce` int NOT NULL DEFAULT 0,
	`finalHash` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fairnessSeeds_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `games` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` enum('flower_poker','hot_cold','dice','crash') NOT NULL,
	`betAmount` int NOT NULL,
	`winAmount` int NOT NULL DEFAULT 0,
	`result` text,
	`seed` varchar(255),
	`hash` varchar(255),
	`status` enum('pending','won','lost','draw') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `games_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leaderboardStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalWins` int NOT NULL DEFAULT 0,
	`totalEarnings` int NOT NULL DEFAULT 0,
	`totalGamesPlayed` int NOT NULL DEFAULT 0,
	`winRate` int NOT NULL DEFAULT 0,
	`rainParticipations` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leaderboardStats_id` PRIMARY KEY(`id`),
	CONSTRAINT `leaderboardStats_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `rainEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`totalAmount` int NOT NULL,
	`participantCount` int NOT NULL DEFAULT 0,
	`amountPerParticipant` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `rainEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rainParticipation` (
	`id` int AUTO_INCREMENT NOT NULL,
	`rainEventId` int NOT NULL,
	`userId` int NOT NULL,
	`amountReceived` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `rainParticipation_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('deposit','withdrawal','bet','win','rain','refund') NOT NULL,
	`amount` int NOT NULL,
	`gameId` int,
	`description` text,
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wallets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`balance` int NOT NULL DEFAULT 0,
	`totalWagered` int NOT NULL DEFAULT 0,
	`totalWon` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wallets_id` PRIMARY KEY(`id`),
	CONSTRAINT `wallets_userId_unique` UNIQUE(`userId`)
);
