CREATE TABLE `discordAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`discordId` varchar(64) NOT NULL,
	`discordUsername` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `discordAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `discordAccounts_userId_unique` UNIQUE(`userId`),
	CONSTRAINT `discordAccounts_discordId_unique` UNIQUE(`discordId`)
);
--> statement-breakpoint
CREATE TABLE `osrsTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('deposit_gp','withdrawal_gp','item_trade_in','item_trade_out') NOT NULL,
	`amount` int NOT NULL,
	`itemId` int,
	`itemName` varchar(255),
	`osrsPlayerName` varchar(255),
	`transactionHash` varchar(255),
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `osrsTransactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `osrsTransactions_transactionHash_unique` UNIQUE(`transactionHash`)
);
