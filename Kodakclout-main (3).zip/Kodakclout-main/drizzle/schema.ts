import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Unique user identifier (openId) set during the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  password: varchar("password", { length: 255 }),
  hashedPassword: varchar("hashedPassword", { length: 255 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const usersRelations = relations(users, ({ one, many }) => ({
  wallet: one(wallets, { fields: [users.id], references: [wallets.userId] }),
  transactions: many(transactions),
  games: many(games),
  chatMessages: many(chatMessages),
  rainParticipation: many(rainParticipation),
  leaderboardStats: one(leaderboardStats, { fields: [users.id], references: [leaderboardStats.userId] }),
  discordAccount: one(discordAccounts, { fields: [users.id], references: [discordAccounts.userId] }),
  osrsTransactions: many(osrsTransactions),
}));

/**
 * Wallet table for tracking user balances and currency
 */
export const wallets = mysqlTable("wallets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  balance: int("balance").default(0).notNull(),
  totalWagered: int("totalWagered").default(0).notNull(),
  totalWon: int("totalWon").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = typeof wallets.$inferInsert;

export const walletsRelations = relations(wallets, ({ one }) => ({
  user: one(users, { fields: [wallets.userId], references: [users.id] }),
}));

/**
 * Transactions table for tracking all wallet movements
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "bet", "win", "rain", "refund"]).notNull(),
  amount: int("amount").notNull(),
  gameId: int("gameId"),
  description: text("description"),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("completed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, { fields: [transactions.userId], references: [users.id] }),
  game: one(games, { fields: [transactions.gameId], references: [games.id] }),
}));

/**
 * Games table for tracking game records and results
 */
export const games = mysqlTable("games", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameType: mysqlEnum("gameType", ["flower_poker", "hot_cold", "dice", "crash"]).notNull(),
  betAmount: int("betAmount").notNull(),
  winAmount: int("winAmount").default(0).notNull(),
  result: text("result"),
  seed: varchar("seed", { length: 255 }),
  hash: varchar("hash", { length: 255 }),
  status: mysqlEnum("status", ["pending", "won", "lost", "draw"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Game = typeof games.$inferSelect;
export type InsertGame = typeof games.$inferInsert;

export const gamesRelations = relations(games, ({ one, many }) => ({
  user: one(users, { fields: [games.userId], references: [users.id] }),
  transactions: many(transactions),
  fairnessSeeds: one(fairnessSeeds, { fields: [games.id], references: [fairnessSeeds.gameId] }),
}));

/**
 * Chat messages table for real-time chat persistence
 */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  username: varchar("username", { length: 64 }).notNull(),
  message: text("message").notNull(),
  channel: mysqlEnum("channel", ["lobby", "game"]).default("lobby").notNull(),
  gameId: int("gameId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, { fields: [chatMessages.userId], references: [users.id] }),
  game: one(games, { fields: [chatMessages.gameId], references: [games.id] }),
}));

/**
 * Rain distribution records
 */
export const rainEvents = mysqlTable("rainEvents", {
  id: int("id").autoincrement().primaryKey(),
  totalAmount: int("totalAmount").notNull(),
  participantCount: int("participantCount").default(0).notNull(),
  amountPerParticipant: int("amountPerParticipant").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RainEvent = typeof rainEvents.$inferSelect;
export type InsertRainEvent = typeof rainEvents.$inferInsert;

export const rainEventsRelations = relations(rainEvents, ({ many }) => ({
  rainParticipation: many(rainParticipation),
}));

/**
 * Rain participation tracking
 */
export const rainParticipation = mysqlTable("rainParticipation", {
  id: int("id").autoincrement().primaryKey(),
  rainEventId: int("rainEventId").notNull(),
  userId: int("userId").notNull(),
  amountReceived: int("amountReceived").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RainParticipation = typeof rainParticipation.$inferSelect;
export type InsertRainParticipation = typeof rainParticipation.$inferInsert;

export const rainParticipationRelations = relations(rainParticipation, ({ one }) => ({
  user: one(users, { fields: [rainParticipation.userId], references: [users.id] }),
  rainEvent: one(rainEvents, { fields: [rainParticipation.rainEventId], references: [rainEvents.id] }),
}));

/**
 * Provably fair seeds and verification
 */
export const fairnessSeeds = mysqlTable("fairnessSeeds", {
  id: int("id").autoincrement().primaryKey(),
  gameId: int("gameId").notNull(),
  clientSeed: varchar("clientSeed", { length: 255 }).notNull(),
  serverSeed: varchar("serverSeed", { length: 255 }).notNull(),
  serverSeedHash: varchar("serverSeedHash", { length: 255 }).notNull(),
  nonce: int("nonce").default(0).notNull(),
  finalHash: varchar("finalHash", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FairnessSeeds = typeof fairnessSeeds.$inferSelect;
export type InsertFairnessSeeds = typeof fairnessSeeds.$inferInsert;

export const fairnessSeedsRelations = relations(fairnessSeeds, ({ one }) => ({
  game: one(games, { fields: [fairnessSeeds.gameId], references: [games.id] }),
}));

/**
 * Leaderboard stats (denormalized for performance)
 */
export const leaderboardStats = mysqlTable("leaderboardStats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  totalWins: int("totalWins").default(0).notNull(),
  totalEarnings: int("totalEarnings").default(0).notNull(),
  totalGamesPlayed: int("totalGamesPlayed").default(0).notNull(),
  winRate: int("winRate").default(0).notNull(),
  rainParticipations: int("rainParticipations").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LeaderboardStats = typeof leaderboardStats.$inferSelect;
export type InsertLeaderboardStats = typeof leaderboardStats.$inferInsert;

export const leaderboardStatsRelations = relations(leaderboardStats, ({ one }) => ({
  user: one(users, { fields: [leaderboardStats.userId], references: [users.id] }),
}));

/**
 * Discord Accounts table for linking user Discord identities
 */
export const discordAccounts = mysqlTable("discordAccounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(), // Foreign key to users table
  discordId: varchar("discordId", { length: 64 }).notNull().unique(), // Unique Discord user ID
  discordUsername: varchar("discordUsername", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DiscordAccount = typeof discordAccounts.$inferSelect;
export type InsertDiscordAccount = typeof discordAccounts.$inferInsert;

export const discordAccountsRelations = relations(discordAccounts, ({ one }) => ({
  user: one(users, { fields: [discordAccounts.userId], references: [users.id] }),
}));

/**
 * OSRS Transactions table for granular OSRS-specific movements
 */
export const osrsTransactions = mysqlTable("osrsTransactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // Foreign key to users table
  type: mysqlEnum("type", ["deposit_gp", "withdrawal_gp", "item_trade_in", "item_trade_out"]).notNull(),
  amount: int("amount").notNull(), // Amount of GP or value of items
  itemId: int("itemId"), // Optional: if tracking specific OSRS items
  itemName: varchar("itemName", { length: 255 }), // Optional: if tracking specific OSRS items
  osrsPlayerName: varchar("osrsPlayerName", { length: 255 }), // OSRS player involved in the transaction
  transactionHash: varchar("transactionHash", { length: 255 }).unique(), // Unique identifier for OSRS transaction
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("completed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OsrsTransaction = typeof osrsTransactions.$inferSelect;
export type InsertOsrsTransaction = typeof osrsTransactions.$inferInsert;

export const osrsTransactionsRelations = relations(osrsTransactions, ({ one }) => ({
  user: one(users, { fields: [osrsTransactions.userId], references: [users.id] }),
}));
