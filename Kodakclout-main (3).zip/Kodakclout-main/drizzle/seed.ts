import type { MySql2Database } from "drizzle-orm/mysql2";
import { users } from "../drizzle/schema";
import bcrypt from "bcrypt";
import { eq } from "drizzle-orm";

export async function seedDatabase(db: MySql2Database) {
  console.log("🌱 Checking for seed data...");

  // Check if any users exist
  const existingUsers = await db.select().from(users).limit(1);

  if (existingUsers.length === 0) {
    console.log("Creating default admin user...");
    const hashedPassword = await bcrypt.hash("password", 10);

    await db.insert(users).values({
      openId: "local-admin",
      name: "admin",
      email: "admin@cloutscape.org",
      hashedPassword: hashedPassword,
      loginMethod: "local",
      role: "admin",
    });
    console.log("✅ Default admin user created: admin/password");
  } else {
    console.log("🌱 Seed data already exists, skipping.");
  }
}
