-- ==============================================================================
-- NIGHTFURY ENGINE - Database Schema
-- Auto-generated for Cloutscape / Degens.Den
-- ==============================================================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS kodakclout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kodakclout;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    openId VARCHAR(64) NOT NULL UNIQUE,
    name TEXT,
    email VARCHAR(320),
    password VARCHAR(255),
    hashedPassword VARCHAR(255),
    loginMethod VARCHAR(64),
    role ENUM('user', 'admin') DEFAULT 'user' NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    lastSignedIn TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_openId (openId),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Wallets table
CREATE TABLE IF NOT EXISTS wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL UNIQUE,
    balance INT DEFAULT 0 NOT NULL,
    totalWagered INT DEFAULT 0 NOT NULL,
    totalWon INT DEFAULT 0 NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    type ENUM('deposit', 'withdrawal', 'bet', 'win', 'rain', 'refund') NOT NULL,
    amount INT NOT NULL,
    gameId INT,
    description TEXT,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'completed' NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    INDEX idx_gameId (gameId),
    INDEX idx_type (type),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Games table
CREATE TABLE IF NOT EXISTS games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    gameType ENUM('flower_poker', 'hot_cold', 'dice', 'crash', 'keno', 'roulette', 'plinko') NOT NULL,
    betAmount INT NOT NULL,
    winAmount INT DEFAULT 0 NOT NULL,
    result TEXT,
    seed VARCHAR(255),
    hash VARCHAR(255),
    status ENUM('pending', 'won', 'lost', 'draw') NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    INDEX idx_gameType (gameType),
    INDEX idx_status (status),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Chat messages table
CREATE TABLE IF NOT EXISTS chatMessages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    username VARCHAR(64) NOT NULL,
    message TEXT NOT NULL,
    channel ENUM('lobby', 'game') DEFAULT 'lobby' NOT NULL,
    gameId INT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    INDEX idx_channel (channel),
    INDEX idx_createdAt (createdAt),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rain events table
CREATE TABLE IF NOT EXISTS rainEvents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    totalAmount INT NOT NULL,
    participantCount INT DEFAULT 0 NOT NULL,
    amountPerParticipant INT NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_createdAt (createdAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rain participation table
CREATE TABLE IF NOT EXISTS rainParticipation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rainEventId INT NOT NULL,
    userId INT NOT NULL,
    amountReceived INT NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_rainEventId (rainEventId),
    INDEX idx_userId (userId),
    FOREIGN KEY (rainEventId) REFERENCES rainEvents(id) ON DELETE CASCADE,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Fairness seeds table (provably fair)
CREATE TABLE IF NOT EXISTS fairnessSeeds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gameId INT NOT NULL,
    clientSeed VARCHAR(255) NOT NULL,
    serverSeed VARCHAR(255) NOT NULL,
    serverSeedHash VARCHAR(255) NOT NULL,
    nonce INT DEFAULT 0 NOT NULL,
    finalHash VARCHAR(255),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_gameId (gameId),
    FOREIGN KEY (gameId) REFERENCES games(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Leaderboard stats table
CREATE TABLE IF NOT EXISTS leaderboardStats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL UNIQUE,
    totalWins INT DEFAULT 0 NOT NULL,
    totalEarnings INT DEFAULT 0 NOT NULL,
    totalGamesPlayed INT DEFAULT 0 NOT NULL,
    winRate INT DEFAULT 0 NOT NULL,
    rainParticipations INT DEFAULT 0 NOT NULL,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    INDEX idx_totalEarnings (totalEarnings),
    INDEX idx_totalWins (totalWins),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Discord accounts table
CREATE TABLE IF NOT EXISTS discordAccounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL UNIQUE,
    discordId VARCHAR(64) NOT NULL UNIQUE,
    discordUsername VARCHAR(255) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    INDEX idx_discordId (discordId),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- OSRS transactions table
CREATE TABLE IF NOT EXISTS osrsTransactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    type ENUM('deposit_gp', 'withdrawal_gp', 'item_trade_in', 'item_trade_out') NOT NULL,
    amount INT NOT NULL,
    itemId INT,
    itemName VARCHAR(255),
    osrsPlayerName VARCHAR(255),
    transactionHash VARCHAR(255) UNIQUE,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'completed' NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_userId (userId),
    INDEX idx_type (type),
    INDEX idx_status (status),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Session table for auth (if needed)
CREATE TABLE IF NOT EXISTS sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    token VARCHAR(512) NOT NULL UNIQUE,
    expiresAt TIMESTAMP NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_token (token),
    INDEX idx_userId (userId),
    INDEX idx_expiresAt (expiresAt),
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'Database schema created successfully!' AS status;
