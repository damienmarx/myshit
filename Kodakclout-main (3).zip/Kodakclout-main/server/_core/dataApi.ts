/**
 * Data API Integration
 *
 * The Manus Forge API integration has been removed.
 * Wire up your own data API provider here if needed.
 */

export type DataApiCallOptions = {
  query?: Record<string, unknown>;
  body?: Record<string, unknown>;
  pathParams?: Record<string, unknown>;
  formData?: Record<string, unknown>;
};

export async function callDataApi(
  apiId: string,
  options: DataApiCallOptions = {}
): Promise<unknown> {
  throw new Error(
    "Data API not configured. Please set up your own data API integration in server/_core/dataApi.ts"
  );
}
