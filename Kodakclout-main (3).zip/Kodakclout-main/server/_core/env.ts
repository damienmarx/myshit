import { z } from "zod";

const envSchema = z.object({
  // Application Environment
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().default(8080),
  HOST: z.string().default("0.0.0.0"),

  // Database Configuration
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),

  // Session Management
  COOKIE_SECRET: z.string().min(1, "COOKIE_SECRET is required for session security"),

  // Admin Configuration (for initial setup or specific admin actions)
  ADMIN_EMAIL: z.string().email().optional(),
  OWNER_OPEN_ID: z.string().optional(),

  // Discord OAuth Configuration
  DISCORD_CLIENT_ID: z.string().optional(),
  DISCORD_CLIENT_SECRET: z.string().optional(),
  DISCORD_REDIRECT_URI: z.string().optional(),
  DISCORD_WEBHOOK_URL: z.string().url().optional(),

  // App ID
  APP_ID: z.string().default("cloutscape-app"),
  
  // OAuth Base URL
  OAUTH_BASE_URL: z.string().default("https://cloutscape.org"),
});

// Load environment variables from .env file in development
// In production, these should be set directly in the environment.
const parsedEnv = envSchema.safeParse(process.env);

if (!parsedEnv.success) {
  console.error(
    "❌ Invalid environment variables:",
    parsedEnv.error.flatten().fieldErrors
  );
  throw new Error("Invalid environment variables");
}

export const ENV = parsedEnv.data;
