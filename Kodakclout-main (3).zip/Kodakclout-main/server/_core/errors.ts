import { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import axios from 'axios';

// ----------------------------------------------------------------------------
// 1. Centralized Logger & Discord Webhook Integration
// ----------------------------------------------------------------------------
const LOG_FILE = path.join('/opt/degens-den/logs', 'error.log');

// Optional: Provide a Discord Webhook URL via environment variables for the "Silent" Error Logger
const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL || '';

/**
 * Fires a "Recon Report" directly to Discord for critical errors.
 */
const sendDiscordReconReport = async (err: any) => {
    if (!DISCORD_WEBHOOK_URL) return;

    try {
        const timestamp = new Date().toISOString();
        const payload = {
            username: "CloutScape Recon",
            avatar_url: "https://i.imgur.com/4M34hiw.png", // Replace with actual avatar if desired
            embeds: [
                {
                    title: "🚨 Critical System Failure Detected",
                    color: 16711680, // Red
                    fields: [
                        { name: "Time", value: timestamp, inline: true },
                        { name: "Error Code", value: err.code || 'UNKNOWN', inline: true },
                        { name: "Message", value: err.message || 'No message provided', inline: false },
                        { name: "Stack Trace", value: `\`\`\`${(err.stack || '').substring(0, 1000)}\`\`\``, inline: false }
                    ],
                    footer: { text: "Degens Den Progressive Reconnaissance" }
                }
            ]
        };

        await axios.post(DISCORD_WEBHOOK_URL, payload);
    } catch (webhookErr) {
        console.error("Failed to send Discord Recon Report:", webhookErr);
    }
};

/**
 * Logs errors locally to /opt/degens-den/logs/error.log and triggers Discord alerts for critical issues.
 */
export const logError = (err: any) => {
    const timestamp = new Date().toISOString();
    const message = `[${timestamp}] ${err.stack || err.message || err}\n`;

    // Ensure logs directory exists
    const logDir = path.dirname(LOG_FILE);
    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }

    // Append to local log file
    fs.appendFileSync(LOG_FILE, message);
    console.error(`🚨 [CloutScape Recon]: ${err.message || err}`);

    // If it's a database connection drop or critical system failure, fire the webhook
    const isCritical = err.code?.startsWith('ER_') || 
                       err.code === 'PROTOCOL_CONNECTION_LOST' || 
                       err.statusCode >= 500 || 
                       !err.statusCode;
                       
    if (isCritical) {
        sendDiscordReconReport(err);
    }
};

// ----------------------------------------------------------------------------
// 2. Global Express Error Middleware (Layer 1 Defense)
// ----------------------------------------------------------------------------
export const globalErrorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
    logError(err);

    const isDbError = err.code?.startsWith('ER_') || err.code === 'PROTOCOL_CONNECTION_LOST';
    const statusCode = err.statusCode || (isDbError ? 503 : 500);
    const isDev = process.env.NODE_ENV === 'development';

    // Fallback response so the tunnel doesn't hang. Maps complex errors to user-friendly JSON.
    res.status(statusCode).json({
        success: false,
        error: {
            message: isDbError ? 'Database Handshake Interrupted' : (statusCode === 500 ? 'Internal Den Error: Handshake Failed' : err.message),
            code: err.code || 'SYSTEM_FAILURE',
            ...(isDev && { stack: err.stack })
        },
        retry_after: isDbError ? "5s" : undefined
    });
};

// ----------------------------------------------------------------------------
// 3. Process-Level Protection (Layer 3 Defense: The Safety Net)
// ----------------------------------------------------------------------------
export const initProcessHandlers = () => {
    process.on('unhandledRejection', (reason: any) => {
        logError(new Error(`Unhandled Rejection: ${reason.message || reason}`));
        // Do not kill the process immediately; let PM2 handle the health check via progressive restart if needed
    });

    process.on('uncaughtException', (err: Error) => {
        logError(err);
        // Clean exit so PM2 can perform a "Progressive Restart"
        // Give the logger a second to write before exiting
        setTimeout(() => process.exit(1), 1000);
    });
};

// ----------------------------------------------------------------------------
// 4. MySQL/Drizzle Connection Health Check (Layer 2 Defense)
// ----------------------------------------------------------------------------
export const handleDbConnectionError = (dbName: string) => {
    return (err: any) => {
        logError(new Error(`Database [${dbName}] Connection Failure: ${err.message}`));
        // Note: Drizzle with mysql2 pool will automatically attempt to reconnect.
        // We throw the error here so it can be caught by the global handler or process safety net if it occurs during a query.
        throw err;
    };
};
