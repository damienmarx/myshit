/**
 * Image Generation Helper
 *
 * The Manus Forge API integration has been removed.
 * Wire up your own image generation provider here (e.g., OpenAI DALL-E, Stability AI, etc.).
 */

export type GenerateImageOptions = {
  prompt: string;
  originalImages?: Array<{
    url?: string;
    b64Json?: string;
    mimeType?: string;
  }>;
};

export type GenerateImageResponse = {
  url?: string;
};

export async function generateImage(
  options: GenerateImageOptions
): Promise<GenerateImageResponse> {
  throw new Error(
    "Image generation not configured. Please set up your own image generation provider in server/_core/imageGeneration.ts"
  );
}
