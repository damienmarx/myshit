import "dotenv/config";
import { migrate } from "drizzle-orm/mysql2/migrator";
import { getDb } from "../db";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { globalErrorHandler, initProcessHandlers } from "./errors";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 8080): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  // Initialize the process-level safety net for the cluster
  initProcessHandlers();

  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  
  // Run database migrations
  const db = await getDb();
  if (db) {
    console.log("🚀 Running database migrations...");
    await migrate(db, { migrationsFolder: "./drizzle" });
    console.log("✅ Database migrations complete.");
  } else {
    console.error("❌ Database connection not available for migrations.");
  }

  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // MUST BE THE LAST MIDDLEWARE - Global error handler
  app.use(globalErrorHandler);

  // Enforce strict port binding (no fallback)
  const PORT = parseInt(process.env.PORT || "8080");

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`🎰 Kodakclout Casino Server running on http://localhost:${PORT}/`);
    console.log(`🌐 Accessible via Cloudflare tunnel at https://cloutscape.org`);
  });
}

startServer().catch(console.error);
