import type { Express, Request, Response } from "express";
import { ENV } from "./env";
import { sdk } from "./sdk";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./cookies";
import * as db from "../db";
import { customAlphabet } from "nanoid";

const nanoid = customAlphabet("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 10);

const DISCORD_API_BASE = "https://discord.com/api/v10";

/**
 * OAuth / Authentication Routes
 * Supports Discord OAuth2 login flow
 */
export function registerOAuthRoutes(app: Express) {
  // Discord OAuth login redirect
  app.get("/api/oauth/discord/login", (_req: Request, res: Response) => {
    if (!ENV.DISCORD_CLIENT_ID || !ENV.DISCORD_REDIRECT_URI) {
      return res.status(501).json({
        error: "Discord OAuth not configured. Set DISCORD_CLIENT_ID and DISCORD_REDIRECT_URI.",
      });
    }

    const params = new URLSearchParams({
      client_id: ENV.DISCORD_CLIENT_ID,
      redirect_uri: ENV.DISCORD_REDIRECT_URI,
      response_type: "code",
      scope: "identify email",
    });

    const discordAuthUrl = `https://discord.com/api/oauth2/authorize?${params.toString()}`;
    res.redirect(discordAuthUrl);
  });

  // Discord OAuth callback handler
  app.get("/api/oauth/discord/callback", async (req: Request, res: Response) => {
    const { code, error } = req.query;

    if (error || !code) {
      return res.redirect("/?error=discord_auth_failed");
    }

    if (!ENV.DISCORD_CLIENT_ID || !ENV.DISCORD_CLIENT_SECRET || !ENV.DISCORD_REDIRECT_URI) {
      return res.redirect("/?error=discord_not_configured");
    }

    try {
      // Exchange code for access token
      const tokenResponse = await fetch(`${DISCORD_API_BASE}/oauth2/token`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          client_id: ENV.DISCORD_CLIENT_ID,
          client_secret: ENV.DISCORD_CLIENT_SECRET,
          grant_type: "authorization_code",
          code: code as string,
          redirect_uri: ENV.DISCORD_REDIRECT_URI,
        }),
      });

      if (!tokenResponse.ok) {
        console.error("Discord token exchange failed:", await tokenResponse.text());
        return res.redirect("/?error=token_exchange_failed");
      }

      const tokenData = await tokenResponse.json();
      const accessToken = tokenData.access_token;

      // Fetch user info from Discord
      const userResponse = await fetch(`${DISCORD_API_BASE}/users/@me`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (!userResponse.ok) {
        console.error("Discord user fetch failed:", await userResponse.text());
        return res.redirect("/?error=user_fetch_failed");
      }

      const discordUser = await userResponse.json();
      const openId = `discord-${discordUser.id}`;
      const username = discordUser.username || discordUser.global_name || `Player${nanoid(4)}`;
      const email = discordUser.email || null;

      // Upsert user in database
      await db.upsertUser({
        openId,
        name: username,
        email,
        loginMethod: "discord",
        lastSignedIn: new Date(),
      });

      // Create session token
      const sessionToken = await sdk.createSessionToken(openId, {
        name: username,
        expiresInMs: ONE_YEAR_MS,
      });

      // Set cookie and redirect
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect("/");
    } catch (err) {
      console.error("Discord OAuth error:", err);
      res.redirect("/?error=oauth_error");
    }
  });

  // Legacy callback route (redirect to home with error)
  app.get("/api/oauth/callback", (_req: Request, res: Response) => {
    res.redirect("/login");
  });
}
