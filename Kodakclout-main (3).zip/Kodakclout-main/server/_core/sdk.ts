import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { ENV } from "./env";
import { TRPCError } from "@trpc/server";
import bcrypt from "bcrypt";

// Utility function
const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.length > 0;

export type SessionPayload = {
  openId: string;
  appId: string;
  name: string;
};

class SDKServer {
  async login(username: string, password: string): Promise<SessionPayload> {
    const user = await db.getUserByUsername(username);
    if (!user || !user.hashedPassword) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Invalid credentials" });
    }

    const passwordMatch = await bcrypt.compare(password, user.hashedPassword);
    if (!passwordMatch) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Invalid credentials" });
    }

    // Update last signed in time
    await db.upsertUser({ openId: user.openId, lastSignedIn: new Date() });

    return {
      openId: user.openId,
      appId: ENV.APP_ID,
      name: user.name || "CloutScape User",
    };
  }

  private parseCookies(cookieHeader: string | undefined) {
    if (!cookieHeader) {
      return new Map<string, string>();
    }

    const cookies = new Map<string, string>();
    cookieHeader.split(";").forEach((cookie) => {
      const [key, value] = cookie.split("=").map((s) => s.trim());
      if (key && value) {
        cookies.set(key, value);
      }
    });
    return cookies;
  }

  async createSessionToken(
    openId: string,
    options: { expiresInMs?: number; name?: string } = {}
  ): Promise<string> {
    return this.signSession(
      {
        openId,
        appId: ENV.APP_ID,
        name: options.name || "",
      },
      options
    );
  }

  async verifySessionToken(token: string): Promise<SessionPayload | undefined> {
    try {
      const { payload } = await jwtVerify(token, this.getJwtSecret());
      return payload as SessionPayload;
    } catch (error) {
      console.warn("Session token verification failed:", error);
      return undefined;
    }
  }

  async getSession(req: Request): Promise<SessionPayload | undefined> {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionToken = cookies.get("cloutscape-session"); // Assuming a cookie name

    if (!sessionToken) {
      return undefined;
    }

    return this.verifySessionToken(sessionToken);
  }

  private getJwtSecret(): Uint8Array {
    if (!ENV.COOKIE_SECRET) {
      throw new Error("COOKIE_SECRET environment variable is not set.");
    }
    return new TextEncoder().encode(ENV.COOKIE_SECRET);
  }

  private async signSession(
    payload: SessionPayload,
    options: { expiresInMs?: number } = {}
  ): Promise<string> {
    const expiresIn = options.expiresInMs || 1000 * 60 * 60 * 24 * 7; // 7 days
    const jwt = await new SignJWT(payload)
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime(Math.floor(Date.now() / 1000) + expiresIn / 1000)
      .sign(this.getJwtSecret());
    return jwt;
  }
}

export const sdk = new SDKServer();
