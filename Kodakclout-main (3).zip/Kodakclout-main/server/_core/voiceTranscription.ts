/**
 * Voice Transcription Module - Disabled for Local Setup
 * 
 * This module requires the Manus Forge API which is not available in local setups.
 * 
 * To enable voice transcription:
 * 1. Use a third-party service like OpenAI Whisper API
 * 2. Or integrate with your own speech-to-text service
 * 
 * Example with OpenAI Whisper:
 * ```ts
 * import { openai } from "@ai-sdk/openai";
 * 
 * export async function transcribeAudio(audioUrl: string) {
 *   const response = await openai.audio.transcriptions.create({
 *     file: audioUrl,
 *     model: "whisper-1",
 *   });
 *   return response;
 * }
 * ```
 */

export type TranscribeOptions = {
  audioUrl: string;
  language?: string;
  prompt?: string;
};

export type TranscriptionResponse = {
  text: string;
  language: string;
};

export type TranscriptionError = {
  error: string;
  code: string;
};

/**
 * Placeholder function - not implemented for local setup
 */
export async function transcribeAudio(
  options: TranscribeOptions
): Promise<TranscriptionResponse | TranscriptionError> {
  return {
    error: "Voice transcription is not available in local setup",
    code: "SERVICE_DISABLED",
  };
}
