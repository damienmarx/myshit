/**
 * Casino Database Helpers
 * Query helpers for wallets, games, transactions, leaderboard, and rain
 */

import { eq, desc, and, gte } from "drizzle-orm";
import { getDb } from "./db";
import {
  wallets,
  transactions,
  games,
  leaderboardStats,
  rainEvents,
  rainParticipation,
  fairnessSeeds,
  chatMessages,
} from "../drizzle/schema";

/**
 * Get or create a wallet for a user
 */
export async function getOrCreateWallet(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db.select().from(wallets).where(eq(wallets.userId, userId)).limit(1);

  if (existing.length > 0) {
    return existing[0];
  }

  // Create new wallet
  await db.insert(wallets).values({
    userId,
    balance: 0,
    totalWagered: 0,
    totalWon: 0,
  });

  const created = await db.select().from(wallets).where(eq(wallets.userId, userId)).limit(1);
  return created[0];
}

/**
 * Get wallet balance for a user
 */
export async function getWalletBalance(userId: number) {
  const wallet = await getOrCreateWallet(userId);
  return wallet.balance;
}

/**
 * Update wallet balance
 */
export async function updateWalletBalance(userId: number, amount: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await getOrCreateWallet(userId);
  const newBalance = wallet.balance + amount;

  await db
    .update(wallets)
    .set({
      balance: newBalance,
      totalWagered: wallet.totalWagered + (amount < 0 ? Math.abs(amount) : 0),
      totalWon: wallet.totalWon + (amount > 0 ? amount : 0),
    })
    .where(eq(wallets.userId, userId));

  return newBalance;
}

/**
 * Record a transaction
 */
export async function recordTransaction(
  userId: number,
  type: "deposit" | "withdrawal" | "bet" | "win" | "rain" | "refund",
  amount: number,
  gameId?: number,
  description?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(transactions).values({
    userId,
    type,
    amount,
    gameId,
    description,
    status: "completed",
  });
}

/**
 * Create a game record
 */
export async function createGameRecord(
  userId: number,
  gameType: "flower_poker" | "hot_cold" | "dice" | "crash",
  betAmount: number,
  status: "pending" | "won" | "lost" | "draw",
  winAmount: number = 0,
  result?: string,
  seed?: string,
  hash?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .insert(games)
    .values({
      userId,
      gameType,
      betAmount,
      winAmount,
      result,
      seed,
      hash,
      status,
    });

  // Return the created game (MySQL doesn't support returning in insert)
  const gameRecords = await db
    .select()
    .from(games)
    .where(eq(games.userId, userId))
    .orderBy(desc(games.createdAt))
    .limit(1);

  return gameRecords[0];
}

/**
 * Get game history for a user
 */
export async function getGameHistory(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(games)
    .where(eq(games.userId, userId))
    .orderBy(desc(games.createdAt))
    .limit(limit);
}

/**
 * Get or create leaderboard stats for a user
 */
export async function getOrCreateLeaderboardStats(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(leaderboardStats)
    .where(eq(leaderboardStats.userId, userId))
    .limit(1);

  if (existing.length > 0) {
    return existing[0];
  }

  await db.insert(leaderboardStats).values({
    userId,
    totalWins: 0,
    totalEarnings: 0,
    totalGamesPlayed: 0,
    winRate: 0,
    rainParticipations: 0,
  });

  const created = await db
    .select()
    .from(leaderboardStats)
    .where(eq(leaderboardStats.userId, userId))
    .limit(1);

  return created[0];
}

/**
 * Update leaderboard stats after a game
 */
export async function updateLeaderboardStats(
  userId: number,
  won: boolean,
  earnings: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const stats = await getOrCreateLeaderboardStats(userId);

  const newWins = stats.totalWins + (won ? 1 : 0);
  const newGamesPlayed = stats.totalGamesPlayed + 1;
  const newEarnings = stats.totalEarnings + earnings;
  const newWinRate = Math.round((newWins / newGamesPlayed) * 10000);

  await db
    .update(leaderboardStats)
    .set({
      totalWins: newWins,
      totalEarnings: newEarnings,
      totalGamesPlayed: newGamesPlayed,
      winRate: newWinRate,
    })
    .where(eq(leaderboardStats.userId, userId));
}

/**
 * Get top players for leaderboard
 */
export async function getTopPlayers(metric: "wins" | "earnings" | "participation", limit: number = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const orderByField = {
    wins: leaderboardStats.totalWins,
    earnings: leaderboardStats.totalEarnings,
    participation: leaderboardStats.rainParticipations,
  }[metric];

  return db
    .select()
    .from(leaderboardStats)
    .orderBy(desc(orderByField))
    .limit(limit);
}

/**
 * Create a rain event
 */
export async function createRainEvent(totalAmount: number, participantCount: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const amountPerParticipant = Math.floor(totalAmount / participantCount);

  await db
    .insert(rainEvents)
    .values({
      totalAmount,
      participantCount,
      amountPerParticipant,
    });

  // Return the created rain event
  const rainEventRecords = await db
    .select()
    .from(rainEvents)
    .orderBy(desc(rainEvents.createdAt))
    .limit(1);

  return rainEventRecords[0];
}

/**
 * Record rain participation
 */
export async function recordRainParticipation(rainEventId: number, userId: number, amountReceived: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(rainParticipation).values({
    rainEventId,
    userId,
    amountReceived,
  });

  // Update leaderboard stats
  const stats = await getOrCreateLeaderboardStats(userId);
  await db
    .update(leaderboardStats)
    .set({
      rainParticipations: stats.rainParticipations + 1,
    })
    .where(eq(leaderboardStats.userId, userId));
}

/**
 * Create fairness seed record
 */
export async function createFairnessRecord(
  gameId: number,
  clientSeed: string,
  serverSeed: string,
  serverSeedHash: string,
  nonce: number = 0
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .insert(fairnessSeeds)
    .values({
      gameId,
      clientSeed,
      serverSeed,
      serverSeedHash,
      nonce,
    });

  // Return the created fairness record
  const records = await db
    .select()
    .from(fairnessSeeds)
    .where(eq(fairnessSeeds.gameId, gameId))
    .orderBy(desc(fairnessSeeds.createdAt))
    .limit(1);

  return records[0];
}

/**
 * Get transaction history for a user
 */
export async function getTransactionHistory(userId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

/**
 * Get recent chat messages
 */
export async function getRecentChatMessages(channel: "lobby" | "game", limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.channel, channel))
    .orderBy(desc(chatMessages.createdAt))
    .limit(limit);
}

/**
 * Save chat message
 */
export async function saveChatMessage(
  userId: number,
  username: string,
  message: string,
  channel: "lobby" | "game",
  gameId?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(chatMessages).values({
    userId,
    username,
    message,
    channel,
    gameId,
  });
}
