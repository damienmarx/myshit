/**
 * Discord Bot Integration Module
 * Handles Discord bot commands, webhooks, and notifications
 */

import axios from 'axios';

interface DiscordWebhookPayload {
  content?: string;
  embeds?: Array<{
    title?: string;
    description?: string;
    color?: number;
    fields?: Array<{
      name: string;
      value: string;
      inline?: boolean;
    }>;
    thumbnail?: {
      url: string;
    };
  }>;
}

export class DiscordBotManager {
  private webhookUrl: string;

  constructor(webhookUrl?: string) {
    this.webhookUrl = webhookUrl || process.env.DISCORD_WEBHOOK_URL || '';
  }

  /**
   * Send a big win notification to Discord
   */
  async notifyBigWin(username: string, gameType: string, winAmount: number, multiplier: number): Promise<void> {
    if (!this.webhookUrl) return;

    const payload: DiscordWebhookPayload = {
      embeds: [
        {
          title: '🎉 BIG WIN ALERT!',
          description: `${username} just won big on ${gameType}!`,
          color: 0xffd700, // Gold
          fields: [
            {
              name: 'Game',
              value: gameType.toUpperCase().replace('_', ' '),
              inline: true,
            },
            {
              name: 'Multiplier',
              value: `${multiplier}x`,
              inline: true,
            },
            {
              name: 'Winnings',
              value: `${winAmount} GP`,
              inline: false,
            },
            {
              name: 'Player',
              value: username,
              inline: true,
            },
            {
              name: 'Time',
              value: new Date().toLocaleString(),
              inline: true,
            },
          ],
          thumbnail: {
            url: 'https://via.placeholder.com/100?text=WIN',
          },
        },
      ],
    };

    try {
      await axios.post(this.webhookUrl, payload);
    } catch (error) {
      console.error('Failed to send Discord notification:', error);
    }
  }

  /**
   * Send a rain event notification to Discord
   */
  async notifyRainEvent(totalAmount: number, participantCount: number, amountPerParticipant: number): Promise<void> {
    if (!this.webhookUrl) return;

    const payload: DiscordWebhookPayload = {
      embeds: [
        {
          title: '🌧️ RAIN EVENT!',
          description: `A rain event has been triggered! Everyone is getting paid!`,
          color: 0x4169e1, // Blue
          fields: [
            {
              name: 'Total Amount',
              value: `${totalAmount} GP`,
              inline: true,
            },
            {
              name: 'Participants',
              value: `${participantCount}`,
              inline: true,
            },
            {
              name: 'Per Participant',
              value: `${amountPerParticipant} GP`,
              inline: false,
            },
            {
              name: 'Time',
              value: new Date().toLocaleString(),
              inline: true,
            },
          ],
        },
      ],
    };

    try {
      await axios.post(this.webhookUrl, payload);
    } catch (error) {
      console.error('Failed to send rain notification:', error);
    }
  }

  /**
   * Send a leaderboard update notification
   */
  async notifyLeaderboardUpdate(topPlayers: Array<{ username: string; earnings: number; rank: number }>): Promise<void> {
    if (!this.webhookUrl) return;

    const fields = topPlayers.map((player) => ({
      name: `#${player.rank} - ${player.username}`,
      value: `${player.earnings} GP`,
      inline: false,
    }));

    const payload: DiscordWebhookPayload = {
      embeds: [
        {
          title: '🏆 LEADERBOARD UPDATE',
          description: 'Top earners this week',
          color: 0xffd700, // Gold
          fields,
        },
      ],
    };

    try {
      await axios.post(this.webhookUrl, payload);
    } catch (error) {
      console.error('Failed to send leaderboard notification:', error);
    }
  }

  /**
   * Send a custom message to Discord
   */
  async sendMessage(title: string, description: string, color: number = 0xffd700): Promise<void> {
    if (!this.webhookUrl) return;

    const payload: DiscordWebhookPayload = {
      embeds: [
        {
          title,
          description,
          color,
        },
      ],
    };

    try {
      await axios.post(this.webhookUrl, payload);
    } catch (error) {
      console.error('Failed to send Discord message:', error);
    }
  }
}

// Export singleton instance
export const discordBot = new DiscordBotManager();
