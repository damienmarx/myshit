/**
 * Discord Bot Configuration for Degens Den
 * Handles webhooks and notifications
 */

export const DISCORD_CONFIG = {
  // Webhook URL - set in environment or here
  webhookUrl: process.env.DISCORD_WEBHOOK_URL || '',
  
  // Bot settings
  botName: '7DEGEN7DEN7 Bot',
  botAvatar: 'https://i.imgur.com/your-avatar.png',
  
  // Embed colors (Discord color integers)
  colors: {
    gold: 0xFFD700,
    green: 0x00FF00,
    red: 0xFF0000,
    blue: 0x4169E1,
    purple: 0x9B59B6,
    orange: 0xFF8C00,
  },
  
  // Notification thresholds
  thresholds: {
    bigWin: 100000, // GP threshold for big win notification
    megaWin: 1000000, // GP threshold for mega win notification
    rainMinimum: 10000, // Minimum rain amount to notify
  },
  
  // Channel IDs (if using bot API instead of webhooks)
  channels: {
    announcements: '',
    bigWins: '',
    rain: '',
    chat: '',
  },
};

/**
 * Discord Embed Templates
 */
export const EMBED_TEMPLATES = {
  bigWin: (username: string, game: string, amount: number, multiplier: number) => ({
    title: '🎉 BIG WIN ALERT!',
    description: `**${username}** just won big on **${game}**!`,
    color: DISCORD_CONFIG.colors.gold,
    fields: [
      { name: 'Game', value: game, inline: true },
      { name: 'Multiplier', value: `${multiplier}x`, inline: true },
      { name: 'Winnings', value: `${amount.toLocaleString()} GP`, inline: false },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: '7DEGEN7DEN7 - Where Legends Are Made' },
  }),
  
  rain: (total: number, participants: number, perPerson: number) => ({
    title: '🌧️ RAIN EVENT!',
    description: 'Gold is raining from the sky!',
    color: DISCORD_CONFIG.colors.blue,
    fields: [
      { name: 'Total Amount', value: `${total.toLocaleString()} GP`, inline: true },
      { name: 'Participants', value: `${participants}`, inline: true },
      { name: 'Per Person', value: `${perPerson.toLocaleString()} GP`, inline: true },
    ],
    timestamp: new Date().toISOString(),
    footer: { text: '7DEGEN7DEN7 - Where Legends Are Made' },
  }),
  
  serverStatus: (status: 'online' | 'offline' | 'maintenance') => {
    const statusConfig = {
      online: { emoji: '✅', color: DISCORD_CONFIG.colors.green, text: 'Online' },
      offline: { emoji: '❌', color: DISCORD_CONFIG.colors.red, text: 'Offline' },
      maintenance: { emoji: '🛠️', color: DISCORD_CONFIG.colors.orange, text: 'Maintenance' },
    };
    const config = statusConfig[status];
    return {
      title: `${config.emoji} Server Status: ${config.text}`,
      description: `The server is currently **${config.text.toLowerCase()}**.`,
      color: config.color,
      timestamp: new Date().toISOString(),
      footer: { text: '7DEGEN7DEN7 - Where Legends Are Made' },
    };
  },
};
