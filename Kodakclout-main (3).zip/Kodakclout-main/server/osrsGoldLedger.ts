/**
 * OSRS Gold Ledger System
 * Manages unique deposit codes, mule verification, and centralized OSRS gold transactions
 * Integrates with wallet system for USD/CAD conversion
 */

import { getDb } from "./db";
import { osrsTransactions, wallets, transactions } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface DepositCode {
  code: string;
  userId: number;
  status: "active" | "used" | "expired";
  amountGP: number;
  amountUSD: number;
  createdAt: string;
  expiresAt: string;
  usedAt?: string;
  verifiedAt?: string;
}

export interface WalletTransaction {
  id: number;
  userId: number;
  type: "deposit" | "withdrawal";
  amountGP: number;
  amountUSD: number;
  status: "pending" | "verified" | "completed" | "rejected";
  osrsRsn: string;
  createdAt: string;
  verifiedAt?: string;
  completedAt?: string;
  adminNote?: string;
}

/**
 * Generate a unique deposit code (e.g., CL-4921)
 * Format: CL-{4 random digits}
 */
export function generateDepositCode(): string {
  const randomNum = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0");
  return `CL-${randomNum}`;
}

/**
 * Create a new deposit code for a user
 * Codes are valid for 24 hours
 */
export async function createDepositCode(
  userId: number,
  amountGP: number,
  amountUSD: number
): Promise<DepositCode> {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");

  const code = generateDepositCode();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours

  // Store in osrsTransactions with deposit_code type
  const result = await db
    .insert(osrsTransactions)
    .values({
      userId,
      type: "deposit_gp",
      amount: 0,
      osrsPlayerName: code, // Store deposit code in osrsPlayerName
    })
    .execute();

  return {
    code,
    userId,
    status: "active",
    amountGP,
    amountUSD,
    createdAt: now.toISOString(),
    expiresAt: expiresAt.toISOString(),
  };
}

/**
 * Verify and use a deposit code
 * Called when mule confirms deposit in-game
 */
export async function verifyDepositCode(
  code: string,
  osrsRsn: string
): Promise<{ success: boolean; message: string; userId?: number; amountUSD?: number }> {
  const db = await getDb();
  if (!db) return { success: false, message: "Database unavailable" };

  try {
    // Find the deposit code record
    const [codeRecord] = await db
      .select()
      .from(osrsTransactions)
      .where(
        and(
          eq(osrsTransactions.osrsPlayerName, code),
          eq(osrsTransactions.type, "deposit_gp")
        )
      )
      .execute() as any;

    if (!codeRecord) {
      return { success: false, message: "Invalid or expired deposit code" };
    }

    const now = new Date();
    const createdAt = new Date(codeRecord.createdAt);
    const expiresAt = new Date(createdAt.getTime() + 24 * 60 * 60 * 1000);

    if (now > expiresAt) {
      // Mark as expired
      await db
        .update(osrsTransactions)
        .set({ status: "failed" })
        .where(eq(osrsTransactions.id, codeRecord.id))
        .execute();

      return { success: false, message: "Deposit code has expired" };
    }

    // Mark code as verified
    await db
      .update(osrsTransactions)
      .set({
        status: "completed",
      })
      .where(eq(osrsTransactions.id, codeRecord.id))
      .execute();

    return {
      success: true,
      message: "Deposit code verified successfully",
      userId: codeRecord.userId,
    };
  } catch (error) {
    console.error("[OSRS Gold Ledger] Verify code error:", error);
    return { success: false, message: "Failed to verify deposit code" };
  }
}

/**
 * Complete a deposit after mule verification
 * Credits user wallet and records transaction
 */
export async function completeDeposit(
  userId: number,
  amountGP: number,
  amountUSD: number,
  osrsRsn: string
): Promise<{ success: boolean; message: string; newBalance?: number }> {
  const db = await getDb();
  if (!db) return { success: false, message: "Database unavailable" };

  try {
    // Get user wallet
    const [wallet] = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, userId))
      .execute() as any;

    if (!wallet) {
      return { success: false, message: "User wallet not found" };
    }

    const currentBalance = parseFloat(wallet.balance);
    const newBalance = currentBalance + amountUSD;

    // Update wallet
    await db
      .update(wallets)
      .set({
        balance: Math.floor(newBalance),
        updatedAt: new Date(),
      })
      .where(eq(wallets.userId, userId))
      .execute();

    // Record transaction
    await db
      .insert(transactions)
      .values({
        userId,
        type: "deposit",
        amount: Math.floor(amountUSD),
        description: `OSRS Gold Deposit: ${amountGP.toLocaleString()} GP (${amountUSD.toFixed(2)} USD) - RSN: ${osrsRsn}`,
      })
      .execute();

    return {
      success: true,
      message: "Deposit completed successfully",
      newBalance,
    };
  } catch (error) {
    console.error("[OSRS Gold Ledger] Complete deposit error:", error);
    return { success: false, message: "Failed to complete deposit" };
  }
}

/**
 * Initiate a withdrawal request
 * Deducts from wallet immediately (reserved for withdrawal)
 */
export async function initiateWithdrawal(
  userId: number,
  amountGP: number,
  amountUSD: number,
  osrsRsn: string
): Promise<{ success: boolean; message: string; withdrawalId?: string; newBalance?: number }> {
  const db = await getDb();
  if (!db) return { success: false, message: "Database unavailable" };

  try {
    // Get user wallet
    const [wallet] = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, userId))
      .execute() as any;

    if (!wallet) {
      return { success: false, message: "User wallet not found" };
    }

    const currentBalance = parseFloat(wallet.balance);

    // Check sufficient balance
    if (currentBalance < amountUSD) {
      return {
        success: false,
        message: `Insufficient balance. Required: $${amountUSD.toFixed(2)}, Available: $${currentBalance.toFixed(2)}`,
      };
    }

    const newBalance = currentBalance - amountUSD;

    // Deduct from wallet immediately
    await db
      .update(wallets)
      .set({
        balance: Math.floor(newBalance),
        updatedAt: new Date(),
      })
      .where(eq(wallets.userId, userId))
      .execute();

    // Create withdrawal transaction
    const withdrawalId = `OSRS_WD_${Date.now()}`;
    await db
      .insert(osrsTransactions)
      .values({
        userId,
        type: "withdrawal_gp",
        amount: Math.floor(amountUSD),
        osrsPlayerName: osrsRsn,
      })
      .execute();

    // Record transaction
    await db
      .insert(transactions)
      .values({
        userId,
        type: "withdrawal",
        amount: Math.floor(amountUSD),
        description: `OSRS Gold Withdrawal: ${amountGP.toLocaleString()} GP (${amountUSD.toFixed(2)} USD) - RSN: ${osrsRsn}`,
      })
      .execute();

    return {
      success: true,
      message: "Withdrawal initiated. Admin will process within 24-48 hours.",
      withdrawalId,
      newBalance,
    };
  } catch (error) {
    console.error("[OSRS Gold Ledger] Initiate withdrawal error:", error);
    return { success: false, message: "Failed to initiate withdrawal" };
  }
}

/**
 * Get user's wallet transaction history
 */
export async function getWalletHistory(
  userId: number,
  limit: number = 50
): Promise<WalletTransaction[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    const results = await db
      .select()
      .from(osrsTransactions)
      .where(eq(osrsTransactions.userId, userId))
      .orderBy(desc(osrsTransactions.createdAt))
      .limit(limit)
      .execute() as any;

    return results.map((row: any) => ({
      id: row.id,
      userId: row.userId,
      type: row.type,
      amountGP: row.amountGp || 0,
      amountUSD: row.amountUsd || 0,
      status: row.status,
      osrsRsn: row.osrsRsn,
      createdAt: row.createdAt,
      verifiedAt: row.verifiedAt,
      completedAt: row.completedAt,
      adminNote: row.adminNote,
    }));
  } catch (error) {
    console.error("[OSRS Gold Ledger] Get history error:", error);
    return [];
  }
}

/**
 * Get current wallet balance for user
 */
export async function getWalletBalance(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;

  try {
    const [wallet] = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, userId))
      .execute() as any;

    return wallet ? parseFloat(wallet.balance) : 0;
  } catch (error) {
    console.error("[OSRS Gold Ledger] Get balance error:", error);
    return 0;
  }
}
