/**
 * Provably Fair System
 * HMAC-SHA256 seed generation, verification, and transparency
 */

import crypto from 'crypto';

/**
 * Generate a random server seed
 */
export function generateServerSeed(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Generate a random client seed
 */
export function generateClientSeed(): string {
  return crypto.randomBytes(16).toString('hex');
}

/**
 * Hash a server seed (server seed hash is revealed before game)
 */
export function hashServerSeed(serverSeed: string): string {
  return crypto.createHash('sha256').update(serverSeed).digest('hex');
}

/**
 * Generate final hash from client seed, server seed, and nonce
 */
export function generateFinalHash(clientSeed: string, serverSeed: string, nonce: number): string {
  const combined = `${clientSeed}:${serverSeed}:${nonce}`;
  return crypto.createHmac('sha256', serverSeed).update(combined).digest('hex');
}

/**
 * Verify fairness - check if the final hash matches
 */
export function verifyFairness(
  clientSeed: string,
  serverSeed: string,
  serverSeedHash: string,
  nonce: number,
  finalHash: string
): boolean {
  // Verify server seed hash
  const computedServerHash = hashServerSeed(serverSeed);
  if (computedServerHash !== serverSeedHash) {
    return false;
  }

  // Verify final hash
  const computedFinalHash = generateFinalHash(clientSeed, serverSeed, nonce);
  return computedFinalHash === finalHash;
}

/**
 * Convert hash to a number between 0 and 1 for game outcomes
 */
export function hashToNumber(hash: string): number {
  // Take first 8 characters of hash and convert to number
  const hex = hash.substring(0, 8);
  const num = parseInt(hex, 16);
  return (num % 10000) / 10000; // Returns 0-1
}

/**
 * Determine Flower Poker outcome based on hash
 * Returns the flower type that will win
 */
export function determineFlowerPokerOutcome(hash: string): 'red' | 'blue' | 'yellow' | 'purple' | 'orange' | 'rainbow' | 'black' | 'white' {
  const num = hashToNumber(hash);
  const flowers = ['red', 'blue', 'yellow', 'purple', 'orange', 'rainbow', 'black', 'white'] as const;
  const index = Math.floor(num * flowers.length);
  return flowers[index];
}

/**
 * Determine Hot/Cold game outcome
 */
export function determineHotColdOutcome(hash: string): boolean {
  const num = hashToNumber(hash);
  return num > 0.5; // 50/50 chance
}

/**
 * Determine Dice outcome (1-6)
 */
export function determineDiceOutcome(hash: string): number {
  const num = hashToNumber(hash);
  return Math.floor(num * 6) + 1;
}

/**
 * Determine Crash game multiplier
 */
export function determineCrashMultiplier(hash: string): number {
  const num = hashToNumber(hash);
  // Exponential distribution: 1.01x to 10x
  return 1 + Math.exp(num * 2.3) / 10;
}

/**
 * Create a fairness proof object for transparency
 */
export interface FairnessProof {
  clientSeed: string;
  serverSeed: string;
  serverSeedHash: string;
  nonce: number;
  finalHash: string;
  gameOutcome: string;
  timestamp: number;
}

/**
 * Generate a complete fairness proof
 */
export function generateFairnessProof(
  clientSeed: string,
  serverSeed: string,
  nonce: number,
  gameOutcome: string
): FairnessProof {
  const serverSeedHash = hashServerSeed(serverSeed);
  const finalHash = generateFinalHash(clientSeed, serverSeed, nonce);

  return {
    clientSeed,
    serverSeed,
    serverSeedHash,
    nonce,
    finalHash,
    gameOutcome,
    timestamp: Date.now(),
  };
}

/**
 * Verify a fairness proof
 */
export function verifyFairnessProof(proof: FairnessProof): boolean {
  return verifyFairness(
    proof.clientSeed,
    proof.serverSeed,
    proof.serverSeedHash,
    proof.nonce,
    proof.finalHash
  );
}
