import { pokerRouter } from "./routers/poker";
import { discordRouter } from "./routers/discord";
import { osrsRouter } from "./routers/osrs";
import { rainRouter } from "./routers/rain";
import { chatRouter } from "./routers/chat";
import { leaderboardRouter } from "./routers/leaderboard";
import { vipRouter } from "./routers/vip";
import { rewardsRouter } from "./routers/rewards";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { authRouter } from "./routers/auth";
import { walletRouter } from "./routers/wallet";
import { publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
  poker: pokerRouter,
  discord: discordRouter,
  osrs: osrsRouter,
  rain: rainRouter,
  chat: chatRouter,
  leaderboard: leaderboardRouter,
  vip: vipRouter,
  rewards: rewardsRouter,
  system: systemRouter,
  auth: authRouter,
  wallet: walletRouter,
});

export type AppRouter = typeof appRouter;
