import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { sdk } from "../_core/sdk";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "../_core/cookies";
import * as db from "../db";
import bcrypt from "bcrypt";
import { customAlphabet } from "nanoid";

const nanoid = customAlphabet("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 10);

export const authRouter = router({
  // Register new user
  register: publicProcedure
    .input(
      z.object({
        username: z.string().min(3, "Username must be at least 3 characters"),
        email: z.string().email("Invalid email address").optional(),
        password: z.string().min(6, "Password must be at least 6 characters"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { username, email, password } = input;
      
      // Check if username already exists
      const existingUser = await db.getUserByUsername(username);
      if (existingUser) {
        throw new Error("Username already taken");
      }

      // Check if email already exists (if provided)
      if (email) {
        const existingEmail = await db.getUserByEmail(email);
        if (existingEmail) {
          throw new Error("Email already registered");
        }
      }

      // Create new user
      const openId = `local-${nanoid()}`;
      await db.upsertUser({
        openId,
        name: username,
        email: email || null,
        password: password, // Will be hashed in upsertUser
        loginMethod: "local",
        lastSignedIn: new Date(),
      });

      const user = await db.getUserByUsername(username);
      if (!user) {
        throw new Error("Failed to create user");
      }

      // Create session token
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || username,
        expiresInMs: ONE_YEAR_MS,
      });

      // Set cookie
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      return { 
        success: true,
        user: { 
          openId: user.openId, 
          name: user.name, 
          appId: process.env.APP_ID || 'cloutscape-app' 
        } 
      };
    }),

  // Login existing user
  login: publicProcedure
    .input(
      z.object({
        username: z.string().min(1, "Username or email is required"),
        password: z.string().min(1, "Password is required"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { username, password } = input;
      
      // Try to find user by username or email
      let user = await db.getUserByUsername(username);
      if (!user && username.includes('@')) {
        user = await db.getUserByEmail(username);
      }

      if (!user) {
        throw new Error("Invalid username/email or password");
      }

      // Verify password
      if (!user.hashedPassword) {
        throw new Error("Account requires password reset or was created via OAuth");
      }

      const passwordMatch = await bcrypt.compare(password, user.hashedPassword);
      if (!passwordMatch) {
        throw new Error("Invalid username/email or password");
      }

      // Update last signed in time
      await db.upsertUser({ openId: user.openId, lastSignedIn: new Date() });

      // Create session token
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      // Set cookie
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      return { 
        success: true,
        user: { 
          openId: user.openId, 
          name: user.name, 
          appId: process.env.APP_ID || 'cloutscape-app' 
        } 
      };
    }),

  // Get current user
  me: publicProcedure.query(opts => opts.ctx.user),

  // Logout
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),
});
