import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { chatMessages } from "../../drizzle/schema";
import { eq, desc, and, sql } from "drizzle-orm";

export const chatRouter = router({
  /**
   * Send a chat message
   */
  sendMessage: protectedProcedure
    .input(z.object({
      message: z.string().min(1).max(500),
      channel: z.enum(["lobby", "game"]).default("lobby"),
      gameId: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Validate message content (no spam, no excessive length)
      if (input.message.trim().length === 0) {
        throw new Error("Message cannot be empty");
      }

      const newMessage = await db.insert(chatMessages).values({
        userId: ctx.user.id,
        username: ctx.user.name || `User${ctx.user.id}`,
        message: input.message.trim(),
        channel: input.channel,
        gameId: input.gameId,
      });

      return {
        success: true,
        messageId: newMessage[0],
      };
    }),

  /**
   * Get chat messages for a channel
   */
  getMessages: publicProcedure
    .input(z.object({
      channel: z.enum(["lobby", "game"]).default("lobby"),
      gameId: z.number().optional(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      let whereConditions = eq(chatMessages.channel, input.channel);
      
      if (input.gameId) {
        whereConditions = and(whereConditions, eq(chatMessages.gameId, input.gameId)) as any;
      }

      const messages = await db
        .select()
        .from(chatMessages)
        .where(whereConditions)
        .orderBy(desc(chatMessages.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      return messages.reverse(); // Return in chronological order
    }),

  /**
   * Get recent messages (for real-time updates)
   */
  getRecentMessages: publicProcedure
    .input(z.object({
      channel: z.enum(["lobby", "game"]).default("lobby"),
      sinceTimestamp: z.number().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const sinceDate = input.sinceTimestamp ? new Date(input.sinceTimestamp) : new Date(Date.now() - 60000); // Last minute

      let whereConditions = eq(chatMessages.channel, input.channel);
      
      // Filter by timestamp if provided
      if (input.sinceTimestamp) {
        whereConditions = and(whereConditions, sql`${chatMessages.createdAt} > ${sinceDate}`) as any;
      }

      const messages = await db
        .select()
        .from(chatMessages)
        .where(whereConditions)
        .orderBy(desc(chatMessages.createdAt))
        .limit(100);

      return messages.reverse();
    }),

  /**
   * Delete a message (admin or message owner)
   */
  deleteMessage: protectedProcedure
    .input(z.object({
      messageId: z.number(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const message = await db.select().from(chatMessages).where(eq(chatMessages.id, input.messageId)).limit(1);

      if (message.length === 0) {
        throw new Error("Message not found");
      }

      // Check if user is the message owner or admin
      if (message[0].userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new Error("You can only delete your own messages");
      }

      // For now, we'll just return success (soft delete could be implemented)
      return { success: true };
    }),

  /**
   * Get chat statistics
   */
  getChatStats: publicProcedure
    .input(z.object({
      channel: z.enum(["lobby", "game"]).default("lobby"),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const messages = await db.select().from(chatMessages).where(eq(chatMessages.channel, input.channel));

      const uniqueUsers = new Set(messages.map((m) => m.userId)).size;
      const totalMessages = messages.length;

      return {
        channel: input.channel,
        totalMessages,
        uniqueUsers,
        averageMessagesPerUser: uniqueUsers > 0 ? (totalMessages / uniqueUsers).toFixed(2) : 0,
      };
    }),
});
