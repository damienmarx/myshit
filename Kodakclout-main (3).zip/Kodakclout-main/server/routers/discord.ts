import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { discordAccounts } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const discordRouter = router({
  linkAccount: protectedProcedure
    .input(z.object({
      discordId: z.string(),
      discordUsername: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const existingAccount = await db.select().from(discordAccounts).where(eq(discordAccounts.userId, ctx.user.id)).limit(1);

      if (existingAccount.length > 0) {
        throw new Error("Discord account already linked to this user.");
      }

      const existingDiscordId = await db.select().from(discordAccounts).where(eq(discordAccounts.discordId, input.discordId)).limit(1);

      if (existingDiscordId.length > 0) {
        throw new Error("This Discord account is already linked to another user.");
      }

      await db.insert(discordAccounts).values({
        userId: ctx.user.id,
        discordId: input.discordId,
        discordUsername: input.discordUsername,
      });

      return { success: true, message: "Discord account linked successfully." };
    }),

  getLinkedAccount: protectedProcedure
    .query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const account = await db.select().from(discordAccounts).where(eq(discordAccounts.userId, ctx.user.id)).limit(1);

      return account.length > 0 ? account[0] : null;
    }),
});
