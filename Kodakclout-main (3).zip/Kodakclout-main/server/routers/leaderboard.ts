import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { leaderboardStats, users } from "../../drizzle/schema";
import { desc, sql } from "drizzle-orm";

export const leaderboardRouter = router({
  /**
   * Get top earners leaderboard
   */
  getTopEarners: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const topEarners = await db
        .select({
          rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${leaderboardStats.totalEarnings} DESC)`,
          userId: leaderboardStats.userId,
          username: users.name,
          totalEarnings: leaderboardStats.totalEarnings,
          totalWins: leaderboardStats.totalWins,
          totalGamesPlayed: leaderboardStats.totalGamesPlayed,
          winRate: leaderboardStats.winRate,
        })
        .from(leaderboardStats)
        .innerJoin(users, sql`${leaderboardStats.userId} = ${users.id}`)
        .orderBy(desc(leaderboardStats.totalEarnings))
        .limit(input.limit)
        .offset(input.offset);

      return topEarners;
    }),

  /**
   * Get top winners leaderboard (by win count)
   */
  getTopWinners: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const topWinners = await db
        .select({
          rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${leaderboardStats.totalWins} DESC)`,
          userId: leaderboardStats.userId,
          username: users.name,
          totalWins: leaderboardStats.totalWins,
          totalEarnings: leaderboardStats.totalEarnings,
          totalGamesPlayed: leaderboardStats.totalGamesPlayed,
          winRate: leaderboardStats.winRate,
        })
        .from(leaderboardStats)
        .innerJoin(users, sql`${leaderboardStats.userId} = ${users.id}`)
        .orderBy(desc(leaderboardStats.totalWins))
        .limit(input.limit)
        .offset(input.offset);

      return topWinners;
    }),

  /**
   * Get highest win rate leaderboard
   */
  getHighestWinRate: publicProcedure
    .input(z.object({
      minGamesPlayed: z.number().min(1).default(10),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const highestWinRate = await db
        .select({
          rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${leaderboardStats.winRate} DESC)`,
          userId: leaderboardStats.userId,
          username: users.name,
          winRate: leaderboardStats.winRate,
          totalGamesPlayed: leaderboardStats.totalGamesPlayed,
          totalWins: leaderboardStats.totalWins,
          totalEarnings: leaderboardStats.totalEarnings,
        })
        .from(leaderboardStats)
        .innerJoin(users, sql`${leaderboardStats.userId} = ${users.id}`)
        .where(sql`${leaderboardStats.totalGamesPlayed} >= ${input.minGamesPlayed}`)
        .orderBy(desc(leaderboardStats.winRate))
        .limit(input.limit)
        .offset(input.offset);

      return highestWinRate;
    }),

  /**
   * Get most active players (by games played)
   */
  getMostActivePlayers: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const mostActive = await db
        .select({
          rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${leaderboardStats.totalGamesPlayed} DESC)`,
          userId: leaderboardStats.userId,
          username: users.name,
          totalGamesPlayed: leaderboardStats.totalGamesPlayed,
          totalWins: leaderboardStats.totalWins,
          totalEarnings: leaderboardStats.totalEarnings,
          winRate: leaderboardStats.winRate,
        })
        .from(leaderboardStats)
        .innerJoin(users, sql`${leaderboardStats.userId} = ${users.id}`)
        .orderBy(desc(leaderboardStats.totalGamesPlayed))
        .limit(input.limit)
        .offset(input.offset);

      return mostActive;
    }),

  /**
   * Get rain participation leaderboard
   */
  getRainLeaderboard: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rainLeaderboard = await db
        .select({
          rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${leaderboardStats.rainParticipations} DESC)`,
          userId: leaderboardStats.userId,
          username: users.name,
          rainParticipations: leaderboardStats.rainParticipations,
          totalEarnings: leaderboardStats.totalEarnings,
        })
        .from(leaderboardStats)
        .innerJoin(users, sql`${leaderboardStats.userId} = ${users.id}`)
        .where(sql`${leaderboardStats.rainParticipations} > 0`)
        .orderBy(desc(leaderboardStats.rainParticipations))
        .limit(input.limit)
        .offset(input.offset);

      return rainLeaderboard;
    }),

  /**
   * Get global statistics
   */
  getGlobalStats: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const stats = await db
      .select({
        totalPlayers: sql<number>`COUNT(DISTINCT ${leaderboardStats.userId})`,
        totalGamesPlayed: sql<number>`SUM(${leaderboardStats.totalGamesPlayed})`,
        totalEarningsDistributed: sql<number>`SUM(${leaderboardStats.totalEarnings})`,
        averageWinRate: sql<number>`AVG(${leaderboardStats.winRate})`,
      })
      .from(leaderboardStats);

    return stats[0] || {
      totalPlayers: 0,
      totalGamesPlayed: 0,
      totalEarningsDistributed: 0,
      averageWinRate: 0,
    };
  }),
});
