import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { osrsTransactions, wallets, transactions, users } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { createDepositCode, verifyDepositCode, generateDepositCode } from "../osrsGoldLedger";
import { ENV } from "../_core/env";

/**
 * Send Discord notification to mule channel
 */
async function notifyMuleChannel(message: string): Promise<void> {
  if (!ENV.DISCORD_WEBHOOK_URL) return;

  try {
    await fetch(ENV.DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: message,
        username: "CloutScape Mule System",
        avatar_url: "https://cloutscape.org/logo.png",
      }),
    });
  } catch (error) {
    console.error("[Mule Notify] Discord webhook failed:", error);
  }
}

export const osrsRouter = router({
  /**
   * Generate a new deposit code for the user
   * Notifies mules via Discord and stores the code in the database
   */
  generateDepositCode: protectedProcedure
    .input(
      z.object({
        amountGP: z.number().min(100000).max(500000000), // 100k to 500M GP
        amountUSD: z.number().min(1).max(10000), // $1 to $10k
        muleRsn: z.string().optional(), // Optional: specify which mule to target
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get user info for Discord notification
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (!user) throw new Error("User not found");

      // Create the deposit code
      const depositCode = await createDepositCode(
        ctx.user.id,
        input.amountGP,
        input.amountUSD
      );

      // Notify mules via Discord
      const discordMessage = `
🎰 **NEW DEPOSIT CODE GENERATED** 🎰
\`\`\`
Code: ${depositCode.code}
Amount: ${input.amountGP.toLocaleString()} GP (${input.amountUSD.toFixed(2)} USD)
Player: ${user.name || `User #${ctx.user.id}`}
Expires: 24 hours
\`\`\`
React when trade is confirmed in-game!
      `.trim();

      await notifyMuleChannel(discordMessage);

      return {
        success: true,
        code: depositCode.code,
        expiresAt: depositCode.expiresAt,
        amountGP: input.amountGP,
        amountUSD: input.amountUSD,
      };
    }),

  /**
   * Verify a deposit code (called by mule after confirming in-game trade)
   * Updates wallet balance and marks transaction as completed
   */
  verifyDepositCode: publicProcedure
    .input(
      z.object({
        code: z.string(),
        osrsRsn: z.string(), // Mule's RSN for verification
        adminKey: z.string().optional(), // Optional admin verification key
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Verify the code
      const result = await verifyDepositCode(input.code, input.osrsRsn);

      if (!result.success) {
        return { success: false, message: result.message };
      }

      // Update wallet balance
      if (result.userId) {
        const wallet = await db
          .select()
          .from(wallets)
          .where(eq(wallets.userId, result.userId))
          .limit(1);

        if (wallet.length > 0) {
          const currentBalance = wallet[0].balance;
          const newBalance = currentBalance + (result.amountUSD || 0);

          await db
            .update(wallets)
            .set({
              balance: Math.floor(newBalance),
              updatedAt: new Date(),
            })
            .where(eq(wallets.userId, result.userId));

          // Record transaction
          await db.insert(transactions).values({
            userId: result.userId,
            type: "deposit",
            amount: Math.floor(result.amountUSD || 0),
            description: `OSRS Deposit verified by mule ${input.osrsRsn}`,
          });

          // Notify user via Discord (if webhook available)
          const [user] = await db
            .select()
            .from(users)
            .where(eq(users.id, result.userId))
            .limit(1);

          const userNotification = `
✅ **DEPOSIT CONFIRMED** ✅
\`\`\`
Player: ${user?.name || `User #${result.userId}`}
Amount: ${result.amountUSD?.toFixed(2)} USD
Mule: ${input.osrsRsn}
Status: COMPLETED
\`\`\`
Balance updated! Ready to play.
          `.trim();

          await notifyMuleChannel(userNotification);
        }
      }

      return {
        success: true,
        message: "Deposit verified and wallet updated",
        userId: result.userId,
      };
    }),

  /**
   * Get pending deposits for admin/mule dashboard
   */
  getPendingDeposits: publicProcedure
    .input(
      z.object({
        adminKey: z.string(), // Simple auth for mule dashboard
      })
    )
    .query(async ({ input }) => {
      // In production, validate adminKey against ENV variable
      if (input.adminKey !== process.env.MULE_ADMIN_KEY) {
        throw new Error("Unauthorized");
      }

      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get all pending deposit transactions
      const pending = await db
        .select()
        .from(osrsTransactions)
        .where(eq(osrsTransactions.type, "deposit_gp"))
        .orderBy(desc(osrsTransactions.createdAt));

      return pending.map((tx) => ({
        id: tx.id,
        code: tx.osrsPlayerName, // The deposit code is stored here
        userId: tx.userId,
        amount: tx.amount,
        createdAt: tx.createdAt,
      }));
    }),

  /**
   * Record a manual OSRS transaction (for item trades, withdrawals, etc.)
   */
  recordOsrsTransaction: protectedProcedure
    .input(
      z.object({
        type: z.enum(["withdrawal_gp", "item_trade_in", "item_trade_out"]),
        amount: z.number().min(1),
        itemId: z.number().optional(),
        itemName: z.string().optional(),
        osrsPlayerName: z.string(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Record in osrsTransactions
      const newOsrsTransaction = await db.insert(osrsTransactions).values({
        userId: ctx.user.id,
        type: input.type,
        amount: input.amount,
        itemId: input.itemId,
        itemName: input.itemName,
        osrsPlayerName: input.osrsPlayerName,
      });

      // For withdrawals, deduct from wallet
      if (input.type === "withdrawal_gp") {
        const wallet = await db
          .select()
          .from(wallets)
          .where(eq(wallets.userId, ctx.user.id))
          .limit(1);

        if (wallet.length === 0) {
          throw new Error("Wallet not found");
        }

        const currentBalance = wallet[0].balance;
        const newBalance = currentBalance - input.amount;

        if (newBalance < 0) {
          throw new Error("Insufficient balance");
        }

        await db
          .update(wallets)
          .set({
            balance: Math.floor(newBalance),
            updatedAt: new Date(),
          })
          .where(eq(wallets.userId, ctx.user.id));

        // Record transaction
        await db.insert(transactions).values({
          userId: ctx.user.id,
          type: "withdrawal",
          amount: input.amount,
          description: input.description || `OSRS Withdrawal to ${input.osrsPlayerName}`,
        });
      }

      return { success: true, transaction: newOsrsTransaction };
    }),

  /**
   * Get OSRS transaction history for a user
   */
  getOsrsTransactionHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const history = await db
        .select()
        .from(osrsTransactions)
        .where(eq(osrsTransactions.userId, ctx.user.id))
        .orderBy(desc(osrsTransactions.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      return history;
    }),

  /**
   * Get deposit code status
   */
  getDepositCodeStatus: protectedProcedure
    .input(z.object({ code: z.string() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const [codeRecord] = await db
        .select()
        .from(osrsTransactions)
        .where(eq(osrsTransactions.osrsPlayerName, input.code))
        .limit(1);

      if (!codeRecord) {
        return { success: false, message: "Code not found" };
      }

      return {
        success: true,
        code: input.code,
        status: codeRecord.createdAt ? "pending" : "unknown",
        createdAt: codeRecord.createdAt,
      };
    }),
});
