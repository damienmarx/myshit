import { router, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import { playFlowerPoker } from "../osrsSystem";

export const pokerRouter = router({
  play: publicProcedure
    .input(z.object({ betAmount: z.number().min(100000) }))
    .mutation(async ({ input, ctx }) => {
      const userId = ctx.user?.id;
      if (!userId) throw new Error("UNAUTHORIZED");
      return await playFlowerPoker(userId, input.betAmount);
    }),
});
