import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { rainEvents, rainParticipation, wallets, transactions, leaderboardStats } from "../../drizzle/schema";
import { eq, desc, sql } from "drizzle-orm";

export const rainRouter = router({
  /**
   * Trigger a rain event (admin only)
   */
  triggerRain: protectedProcedure
    .input(z.object({
      totalAmount: z.number().min(1000).max(10000000),
      participantThreshold: z.number().min(1).max(1000).default(10), // Minimum active players to qualify
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Check if user is admin
      if (ctx.user.role !== "admin") {
        throw new Error("Only admins can trigger rain");
      }

      // Get active players (those with recent activity)
      const activeUsers = await db
        .select({ userId: wallets.userId })
        .from(wallets)
        .where(sql`${wallets.balance} > 0`)
        .limit(input.participantThreshold);

      if (activeUsers.length === 0) {
        throw new Error("No active players to distribute rain to");
      }

      // Create rain event
      const amountPerParticipant = Math.floor(input.totalAmount / activeUsers.length);

      const rainEventResult = await db.insert(rainEvents).values({
        totalAmount: input.totalAmount,
        participantCount: activeUsers.length,
        amountPerParticipant,
      });

      // Get the rainEventId from the result (use any type to bypass type checking)
      const rainEventId = (rainEventResult as any).insertId || 1;

      // Distribute rain to each participant
      for (const user of activeUsers) {
        // Record participation
        await db.insert(rainParticipation).values({
          rainEventId: rainEventId as number,
          userId: user.userId,
          amountReceived: amountPerParticipant,
        });

        // Update wallet balance
        const wallet = await db.select().from(wallets).where(eq(wallets.userId, user.userId)).limit(1);
        if (wallet.length > 0) {
          await db.update(wallets).set({
            balance: wallet[0].balance + amountPerParticipant,
          }).where(eq(wallets.userId, user.userId));

          // Record transaction
          await db.insert(transactions).values({
            userId: user.userId,
            type: "rain",
            amount: amountPerParticipant,
            description: `Rain distribution: ${amountPerParticipant} GP`,
          });

          // Update leaderboard stats
          const stats = await db.select().from(leaderboardStats).where(eq(leaderboardStats.userId, user.userId)).limit(1);
          if (stats.length > 0) {
            await db.update(leaderboardStats).set({
              rainParticipations: stats[0].rainParticipations + 1,
            }).where(eq(leaderboardStats.userId, user.userId));
          }
        }
      }

      return {
        success: true,
        rainEventId: rainEventId,
        totalDistributed: input.totalAmount,
        participantsCount: activeUsers.length,
        amountPerParticipant,
      };
    }),

  /**
   * Get recent rain events
   */
  getRainEvents: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(50).default(10),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const events = await db
        .select()
        .from(rainEvents)
        .orderBy(desc(rainEvents.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      return events;
    }),

  /**
   * Get user's rain participation history
   */
  getUserRainHistory: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(50).default(20),
      offset: z.number().min(0).default(0),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const history = await db
        .select()
        .from(rainParticipation)
        .where(eq(rainParticipation.userId, ctx.user.id))
        .limit(input.limit)
        .offset(input.offset);

      return history;
    }),

  /**
   * Get total rain received by user
   */
  getTotalRainReceived: protectedProcedure
    .query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const result = await db
        .select({
          total: sql<number>`SUM(${rainParticipation.amountReceived})`,
          count: sql<number>`COUNT(*)`,
        })
        .from(rainParticipation)
        .where(eq(rainParticipation.userId, ctx.user.id));

      return {
        totalReceived: result[0]?.total || 0,
        rainEventsParticipated: result[0]?.count || 0,
      };
    }),
});
