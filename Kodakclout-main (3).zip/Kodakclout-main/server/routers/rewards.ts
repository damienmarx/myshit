import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { wallets, transactions } from "../../drizzle/schema";
import { eq, sql } from "drizzle-orm";

/**
 * Reward System Router
 * Manages daily bonuses, streaks, and achievement rewards
 */

export const DAILY_BONUSES = {
  DAY_1: 1000,
  DAY_2: 2000,
  DAY_3: 3000,
  DAY_4: 4000,
  DAY_5: 5000,
  DAY_6: 7500,
  DAY_7: 10000,
};

export const rewardsRouter = router({
  /**
   * Claim daily bonus
   */
  claimDailyBonus: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    // Check if user already claimed today
    const today = new Date().toDateString();
    const lastClaim = await db
      .select()
      .from(transactions)
      .where(
        sql`${transactions.userId} = ${ctx.user.id} AND ${transactions.type} = 'daily_bonus' AND DATE(${transactions.createdAt}) = ${today}`
      )
      .limit(1);

    if (lastClaim.length > 0) {
      throw new Error("Daily bonus already claimed today");
    }

    // Calculate streak and bonus amount
    const allBonuses = await db
      .select()
      .from(transactions)
      .where(
        sql`${transactions.userId} = ${ctx.user.id} AND ${transactions.type} = 'daily_bonus'`
      )
      .orderBy(sql`${transactions.createdAt} DESC`)
      .limit(30);

    let streak = 0;
    let lastDate = new Date();

    for (const bonus of allBonuses) {
      const bonusDate = new Date(bonus.createdAt!);
      const daysDiff = Math.floor(
        (lastDate.getTime() - bonusDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (daysDiff === 1) {
        streak++;
        lastDate = bonusDate;
      } else if (daysDiff === 0) {
        continue;
      } else {
        break;
      }
    }

    streak = Math.min(streak + 1, 7); // Cap at 7 days

    const bonusAmount =
      DAILY_BONUSES[`DAY_${streak}` as keyof typeof DAILY_BONUSES] || 10000;

    // Update wallet
    const wallet = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, ctx.user.id))
      .limit(1);

    if (wallet.length > 0) {
      await db.update(wallets).set({
        balance: wallet[0].balance + bonusAmount,
      }).where(eq(wallets.userId, ctx.user.id));

      // Record transaction
      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "refund",
        amount: bonusAmount,
        description: `Daily Bonus Day ${streak}: ${bonusAmount} GP`,
      });
    }

    return {
      success: true,
      bonusAmount,
      streak,
      nextBonus: streak < 7 ? DAILY_BONUSES[`DAY_${streak + 1}` as keyof typeof DAILY_BONUSES] : bonusAmount,
    };
  }),

  /**
   * Get daily bonus status
   */
  getDailyBonusStatus: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const today = new Date().toDateString();
    const lastClaim = await db
      .select()
      .from(transactions)
      .where(
        sql`${transactions.userId} = ${ctx.user.id} AND ${transactions.type} = 'daily_bonus' AND DATE(${transactions.createdAt}) = ${today}`
      )
      .limit(1);

    const allBonuses = await db
      .select()
      .from(transactions)
      .where(
        sql`${transactions.userId} = ${ctx.user.id} AND ${transactions.type} = 'daily_bonus'`
      )
      .orderBy(sql`${transactions.createdAt} DESC`)
      .limit(30);

    let streak = 0;
    let lastDate = new Date();

    for (const bonus of allBonuses) {
      const bonusDate = new Date(bonus.createdAt!);
      const daysDiff = Math.floor(
        (lastDate.getTime() - bonusDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (daysDiff === 1) {
        streak++;
        lastDate = bonusDate;
      } else if (daysDiff === 0) {
        continue;
      } else {
        break;
      }
    }

    return {
      claimed: lastClaim.length > 0,
      streak: Math.min(streak + 1, 7),
      nextBonus: streak < 6 ? DAILY_BONUSES[`DAY_${streak + 2}` as keyof typeof DAILY_BONUSES] : 10000,
      bonusSchedule: DAILY_BONUSES,
    };
  }),

  /**
   * Get achievement rewards
   */
  getAchievements: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const stats = await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, ctx.user.id));

    const achievements = [
      {
        id: "first_bet",
        name: "First Bet",
        description: "Place your first bet",
        reward: 500,
        unlocked: stats.some((t) => t.type === "bet"),
      },
      {
        id: "first_win",
        name: "First Win",
        description: "Win your first game",
        reward: 1000,
        unlocked: stats.some((t) => t.type === "win"),
      },
      {
        id: "big_winner",
        name: "Big Winner",
        description: "Win 100,000 GP in a single game",
        reward: 5000,
        unlocked: stats.some((t) => t.type === "win" && (t.amount || 0) >= 100000),
      },
      {
        id: "lucky_seven",
        name: "Lucky Seven",
        description: "Win 7 games in a row",
        reward: 10000,
        unlocked: false, // Would need streak tracking
      },
      {
        id: "high_roller",
        name: "High Roller",
        description: "Wager 1,000,000 GP total",
        reward: 15000,
        unlocked: stats.reduce((sum, t) => sum + (t.type === "bet" ? Math.abs(t.amount || 0) : 0), 0) >= 1000000,
      },
      {
        id: "rain_dancer",
        name: "Rain Dancer",
        description: "Participate in 10 rain events",
        reward: 5000,
        unlocked: stats.filter((t) => t.type === "rain").length >= 10,
      },

    ];

    return achievements;
  }),

  /**
   * Claim achievement reward
   */
  claimAchievementReward: protectedProcedure
    .input(z.object({ achievementId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Verify achievement is unlocked
      const achievements = await db
        .select()
        .from(transactions)
        .where(eq(transactions.userId, ctx.user.id));

      let reward = 0;

      switch (input.achievementId) {
        case "first_bet":
          reward = achievements.some((t) => t.type === "bet") ? 500 : 0;
          break;
        case "first_win":
          reward = achievements.some((t) => t.type === "win") ? 1000 : 0;
          break;
        case "big_winner":
          reward = achievements.some((t) => t.type === "win" && (t.amount || 0) >= 100000) ? 5000 : 0;
          break;
        case "high_roller":
          reward = achievements.reduce((sum, t) => sum + (t.type === "bet" ? Math.abs(t.amount || 0) : 0), 0) >= 1000000 ? 15000 : 0;
          break;
        case "rain_dancer":
          reward = achievements.filter((t) => t.type === "rain").length >= 10 ? 5000 : 0;
          break;

      }

      if (reward === 0) {
        throw new Error("Achievement not unlocked");
      }

      // Check if already claimed
      const claimed = await db
        .select()
        .from(transactions)
        .where(
          sql`${transactions.userId} = ${ctx.user.id} AND ${transactions.type} = 'achievement' AND ${transactions.description} LIKE ${'%' + input.achievementId + '%'}`
        )
        .limit(1);

      if (claimed.length > 0) {
        throw new Error("Achievement reward already claimed");
      }

      // Update wallet
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.userId, ctx.user.id))
        .limit(1);

      if (wallet.length > 0) {
        await db.update(wallets).set({
          balance: wallet[0].balance + reward,
        }).where(eq(wallets.userId, ctx.user.id));

        // Record transaction
        await db.insert(transactions).values({
          userId: ctx.user.id,
          type: "win",
          amount: reward,
          description: `Achievement Reward: ${input.achievementId} - ${reward} GP`,
        });
      }

      return { success: true, reward };
    }),

  /**
   * Get referral rewards
   */
  getReferralStatus: protectedProcedure.query(async ({ ctx }) => {
    return {
      referralCode: `REF_${ctx.user.id}_${Math.random().toString(36).substring(7).toUpperCase()}`,
      totalReferrals: 0,
      totalReferralRewards: 0,
      pendingRewards: 0,
      referralBonusPerFriend: 5000,
      description: "Earn 5000 GP for each friend who joins and makes their first deposit",
    };
  }),
});
