import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { wallets, transactions, leaderboardStats } from "../../drizzle/schema";
import { eq, sql } from "drizzle-orm";

/**
 * VIP System Router
 * Manages VIP tiers, benefits, and exclusive rewards
 */

export const VIP_TIERS = {
  BRONZE: { tier: 1, name: "Bronze", minEarnings: 0, cashback: 0.5, lossback: 0.1 },
  SILVER: { tier: 2, name: "Silver", minEarnings: 100000, cashback: 1, lossback: 0.15 },
  GOLD: { tier: 3, name: "Gold", minEarnings: 500000, cashback: 1.5, lossback: 0.2 },
  PLATINUM: { tier: 4, name: "Platinum", minEarnings: 1000000, cashback: 2, lossback: 0.25 },
  DIAMOND: { tier: 5, name: "Diamond", minEarnings: 5000000, cashback: 3, lossback: 0.3 },
};

export const vipRouter = router({
  /**
   * Get user's VIP tier and benefits
   */
  getUserVipStatus: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const stats = await db
      .select()
      .from(leaderboardStats)
      .where(eq(leaderboardStats.userId, ctx.user.id))
      .limit(1);

    if (stats.length === 0) {
      return {
        userId: ctx.user.id,
        tier: VIP_TIERS.BRONZE,
        totalEarnings: 0,
        nextTierEarnings: VIP_TIERS.SILVER.minEarnings,
        progressToNextTier: 0,
        benefits: {
          cashback: VIP_TIERS.BRONZE.cashback,
          lossback: VIP_TIERS.BRONZE.lossback,
          rainBonus: 1,
          withdrawalFee: 0,
        },
      };
    }

    const totalEarnings = stats[0].totalEarnings || 0;

    // Determine VIP tier
    let currentTier = VIP_TIERS.BRONZE;
    for (const tier of Object.values(VIP_TIERS)) {
      if (totalEarnings >= tier.minEarnings) {
        currentTier = tier;
      }
    }

    // Calculate progress to next tier
    const nextTier = Object.values(VIP_TIERS).find(
      (t) => t.minEarnings > currentTier.minEarnings
    );
    const nextTierEarnings = nextTier?.minEarnings || currentTier.minEarnings;
    const progressToNextTier = nextTier
      ? Math.min(
          ((totalEarnings - currentTier.minEarnings) /
            (nextTierEarnings - currentTier.minEarnings)) *
            100,
          100
        )
      : 100;

    return {
      userId: ctx.user.id,
      tier: currentTier,
      totalEarnings,
      nextTierEarnings,
      progressToNextTier,
      benefits: {
        cashback: currentTier.cashback,
        lossback: currentTier.lossback,
        rainBonus: 1 + (currentTier.tier - 1) * 0.1,
        withdrawalFee: Math.max(0, 1 - (currentTier.tier - 1) * 0.1),
      },
    };
  }),

  /**
   * Apply cashback reward
   */
  applyCashback: protectedProcedure
    .input(z.object({ winAmount: z.number().min(0) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get VIP status
      const stats = await db
        .select()
        .from(leaderboardStats)
        .where(eq(leaderboardStats.userId, ctx.user.id))
        .limit(1);

      let cashbackPercentage = VIP_TIERS.BRONZE.cashback;
      if (stats.length > 0) {
        const totalEarnings = stats[0].totalEarnings || 0;
        for (const tier of Object.values(VIP_TIERS)) {
          if (totalEarnings >= tier.minEarnings) {
            cashbackPercentage = tier.cashback;
          }
        }
      }

      const cashbackAmount = Math.floor((input.winAmount * cashbackPercentage) / 100);

      if (cashbackAmount > 0) {
        // Update wallet
        const wallet = await db
          .select()
          .from(wallets)
          .where(eq(wallets.userId, ctx.user.id))
          .limit(1);

        if (wallet.length > 0) {
          await db.update(wallets).set({
            balance: wallet[0].balance + cashbackAmount,
          }).where(eq(wallets.userId, ctx.user.id));

          // Record transaction
          await db.insert(transactions).values({
            userId: ctx.user.id,
            type: "refund",
            amount: cashbackAmount,
            description: `VIP Cashback: ${cashbackPercentage}% of ${input.winAmount} GP`,
          });
        }
      }

      return { cashbackAmount, cashbackPercentage };
    }),

  /**
   * Apply lossback reward
   */
  applyLossback: protectedProcedure
    .input(z.object({ lossAmount: z.number().min(0) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get VIP status
      const stats = await db
        .select()
        .from(leaderboardStats)
        .where(eq(leaderboardStats.userId, ctx.user.id))
        .limit(1);

      let lossbackPercentage = VIP_TIERS.BRONZE.lossback;
      if (stats.length > 0) {
        const totalEarnings = stats[0].totalEarnings || 0;
        for (const tier of Object.values(VIP_TIERS)) {
          if (totalEarnings >= tier.minEarnings) {
            lossbackPercentage = tier.lossback;
          }
        }
      }

      const lossbackAmount = Math.floor((input.lossAmount * lossbackPercentage) / 100);

      if (lossbackAmount > 0) {
        // Update wallet
        const wallet = await db
          .select()
          .from(wallets)
          .where(eq(wallets.userId, ctx.user.id))
          .limit(1);

        if (wallet.length > 0) {
          await db.update(wallets).set({
            balance: wallet[0].balance + lossbackAmount,
          }).where(eq(wallets.userId, ctx.user.id));

          // Record transaction
          await db.insert(transactions).values({
            userId: ctx.user.id,
            type: "refund",
            amount: lossbackAmount,
            description: `VIP Lossback: ${lossbackPercentage}% of ${input.lossAmount} GP loss recovered`,
          });
        }
      }

      return { lossbackAmount, lossbackPercentage };
    }),

  /**
   * Get VIP leaderboard
   */
  getVipLeaderboard: protectedProcedure
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const topVips = await db
        .select({
          userId: leaderboardStats.userId,
          totalEarnings: leaderboardStats.totalEarnings,
          totalWins: leaderboardStats.totalWins,
        })
        .from(leaderboardStats)
        .orderBy(sql`${leaderboardStats.totalEarnings} DESC`)
        .limit(input.limit);

      return topVips.map((user, idx) => {
        let tier = VIP_TIERS.BRONZE;
        for (const t of Object.values(VIP_TIERS)) {
          if ((user.totalEarnings || 0) >= t.minEarnings) {
            tier = t;
          }
        }

        return {
          rank: idx + 1,
          userId: user.userId,
          tier,
          totalEarnings: user.totalEarnings || 0,
          totalWins: user.totalWins || 0,
        };
      });
    }),

  /**
   * Get VIP benefits summary
   */
  getVipBenefits: protectedProcedure.query(async () => {
    return {
      tiers: Object.values(VIP_TIERS),
      benefits: {
        BRONZE: {
          cashback: "0.5%",
          lossback: "10%",
          rainBonus: "1x",
          withdrawalFee: "0%",
          description: "Entry level VIP with basic rewards",
        },
        SILVER: {
          cashback: "1%",
          lossback: "15%",
          rainBonus: "1.1x",
          withdrawalFee: "0%",
          description: "Enhanced rewards and rain bonuses",
        },
        GOLD: {
          cashback: "1.5%",
          lossback: "20%",
          rainBonus: "1.2x",
          withdrawalFee: "0%",
          description: "Premium benefits with significant cashback",
        },
        PLATINUM: {
          cashback: "2%",
          lossback: "25%",
          rainBonus: "1.3x",
          withdrawalFee: "0%",
          description: "Elite tier with maximum rewards",
        },
        DIAMOND: {
          cashback: "3%",
          lossback: "30%",
          rainBonus: "1.4x",
          withdrawalFee: "0%",
          description: "Legendary status with exclusive perks",
        },
      },
    };
  }),
});
