import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { wallets, transactions, games } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const walletRouter = router({
  /**
   * Get user's current wallet balance
   */
  getBalance: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const wallet = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, ctx.user.id))
      .limit(1);

    if (wallet.length === 0) {
      // Create wallet if doesn't exist (starting balance: 100,000 GP)
      await db.insert(wallets).values({
        userId: ctx.user.id,
        balance: 100000,
        totalWagered: 0,
        totalWon: 0,
      });

      return {
        balance: 100000,
        totalWagered: 0,
        totalWon: 0,
      };
    }

    return {
      balance: wallet[0].balance,
      totalWagered: wallet[0].totalWagered,
      totalWon: wallet[0].totalWon,
    };
  }),

  /**
   * Place a bet (deduct from balance)
   */
  placeBet: protectedProcedure
    .input(
      z.object({
        gameType: z.string(),
        betAmount: z.number().min(10).max(100000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get current balance
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.userId, ctx.user.id))
        .limit(1);

      if (wallet.length === 0) {
        throw new Error("Wallet not found");
      }

      const currentBalance = wallet[0].balance;

      // Check if user has sufficient balance
      if (currentBalance < input.betAmount) {
        throw new Error("Insufficient balance");
      }

      // Deduct bet from balance
      const newBalance = currentBalance - input.betAmount;

      await db
        .update(wallets)
        .set({
          balance: newBalance,
          totalWagered: wallet[0].totalWagered + input.betAmount,
        })
        .where(eq(wallets.userId, ctx.user.id));

      // Record transaction
      await db.insert(transactions).values([{
        userId: ctx.user.id,
        type: "bet",
        amount: input.betAmount,
        description: `Bet placed on ${input.gameType}`,
      }]);

      return {
        success: true,
        newBalance,
      };
    }),

  /**
   * Record a win and credit the user
   */
  recordWin: protectedProcedure
    .input(
      z.object({
        gameType: z.enum(["flower_poker", "hot_cold", "dice", "crash"]),
        betAmount: z.number().min(10).max(100000),
        multiplier: z.number().min(0.5).max(1000),
        winAmount: z.number().min(0).max(10000000),
        gameResult: z.record(z.string(), z.any()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get current balance
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.userId, ctx.user.id))
        .limit(1);

      if (wallet.length === 0) {
        throw new Error("Wallet not found");
      }

      const currentBalance = wallet[0].balance;
      const newBalance = currentBalance + input.winAmount;

      // Update wallet
      await db
        .update(wallets)
        .set({
          balance: newBalance,
          totalWon: wallet[0].totalWon + input.winAmount,
        })
        .where(eq(wallets.userId, ctx.user.id));

      // Record game result
      await db.insert(games).values({
        userId: ctx.user.id,
        gameType: input.gameType as "flower_poker" | "hot_cold" | "dice" | "crash",
        betAmount: input.betAmount,
        winAmount: input.winAmount,
        result: JSON.stringify(input.gameResult || {}),
        status: input.winAmount > 0 ? "won" : "lost",
      });

      // Record transaction
      await db.insert(transactions).values([{
        userId: ctx.user.id,
        type: "win",
        amount: input.winAmount,
        description: `Won ${input.winAmount} GP on ${input.gameType} (${input.multiplier}x)`,
      }]);

      return {
        success: true,
        newBalance,
      };
    }),

  /**
   * Record a loss (game lost, no winnings)
   */
  recordLoss: protectedProcedure
    .input(
      z.object({
        gameType: z.string(),
        betAmount: z.number().min(10).max(100000),
        gameResult: z.record(z.string(), z.any()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get current balance
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.userId, ctx.user.id))
        .limit(1);

      if (wallet.length === 0) {
        throw new Error("Wallet not found");
      }

      const currentBalance = wallet[0].balance;

      // Record game result
      await db.insert(games).values({
        userId: ctx.user.id,
        gameType: input.gameType as "flower_poker" | "hot_cold" | "dice" | "crash",
        betAmount: input.betAmount,
        winAmount: 0,
        result: JSON.stringify(input.gameResult || {}),
        status: "lost",
      });

      return {
        success: true,
        newBalance: currentBalance,
      };
    }),

  /**
   * Get transaction history
   */
  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const history = await db
        .select()
        .from(transactions)
        .where(eq(transactions.userId, ctx.user.id));

      return history.slice(input.offset, input.offset + input.limit);
    }),

  /**
   * Get game statistics
   */
  getStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const gameRecords = await db
      .select()
      .from(games)
      .where(eq(games.userId, ctx.user.id));

    const totalGames = gameRecords.length;
    const totalWins = gameRecords.filter((g) => g.status === "won").length;
    const totalLosses = gameRecords.filter((g) => g.status === "lost").length;
    const totalWagered = gameRecords.reduce((sum, g) => sum + g.betAmount, 0);
    const totalEarnings = gameRecords.reduce((sum, g) => sum + g.winAmount, 0);
    const winRate = totalGames > 0 ? ((totalWins / totalGames) * 100).toFixed(2) : "0.00";

    // Group by game type
    const gameTypeStats = gameRecords.reduce(
      (acc, game) => {
        if (!acc[game.gameType]) {
          acc[game.gameType] = {
            plays: 0,
            wins: 0,
            losses: 0,
            totalWagered: 0,
            totalWon: 0,
          };
        }
        acc[game.gameType].plays++;
        if (game.status === "won") acc[game.gameType].wins++;
        else acc[game.gameType].losses++;
        acc[game.gameType].totalWagered += game.betAmount;
        acc[game.gameType].totalWon += game.winAmount;
        return acc;
      },
      {} as Record<string, { plays: number; wins: number; losses: number; totalWagered: number; totalWon: number }>
    );

    return {
      totalGames,
      totalWins,
      totalLosses,
      winRate,
      totalWagered,
      totalEarnings,
      gameTypeStats,
    };
  }),
});
