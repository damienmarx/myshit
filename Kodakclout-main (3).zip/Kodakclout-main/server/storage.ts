/**
 * Local File Storage for Kodakclout Casino
 * 
 * For production, replace with AWS S3, Google Cloud Storage, or similar.
 * 
 * Example AWS S3 integration:
 * ```ts
 * import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
 * import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
 * 
 * const s3 = new S3Client({ region: "us-east-1" });
 * 
 * export async function storagePut(relKey: string, data: Buffer | Uint8Array | string, contentType = "application/octet-stream") {
 *   const command = new PutObjectCommand({
 *     Bucket: process.env.AWS_S3_BUCKET!,
 *     Key: relKey,
 *     Body: data,
 *     ContentType: contentType,
 *   });
 *   await s3.send(command);
 *   return { key: relKey, url: `https://${process.env.AWS_S3_BUCKET}.s3.amazonaws.com/${relKey}` };
 * }
 * ```
 */

import fs from "fs";
import path from "path";

// Local storage directory
const STORAGE_DIR = path.join(process.cwd(), ".storage");

// Ensure storage directory exists
if (!fs.existsSync(STORAGE_DIR)) {
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
}

/**
 * Store file locally
 * For production, implement AWS S3 or similar cloud storage
 */
export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType = "application/octet-stream"
): Promise<{ key: string; url: string }> {
  try {
    const key = relKey.replace(/^\/+/, "");
    const filePath = path.join(STORAGE_DIR, key);
    
    // Create directory if it doesn't exist
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    // Write file
    const buffer = typeof data === "string" ? Buffer.from(data) : Buffer.from(data);
    fs.writeFileSync(filePath, buffer);
    
    // Return local URL (in production, this would be a CDN URL)
    const url = `/storage/${key}`;
    
    return { key, url };
  } catch (error) {
    throw new Error(
      `Storage upload failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}

/**
 * Get file URL
 * For production, implement AWS S3 presigned URLs or similar
 */
export async function storageGet(relKey: string): Promise<{ key: string; url: string }> {
  try {
    const key = relKey.replace(/^\/+/, "");
    const filePath = path.join(STORAGE_DIR, key);
    
    // Check if file exists
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${key}`);
    }
    
    // Return local URL (in production, this would be a presigned CDN URL)
    const url = `/storage/${key}`;
    
    return { key, url };
  } catch (error) {
    throw new Error(
      `Storage retrieval failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}

/**
 * Delete file (optional)
 */
export async function storageDelete(relKey: string): Promise<void> {
  try {
    const key = relKey.replace(/^\/+/, "");
    const filePath = path.join(STORAGE_DIR, key);
    
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (error) {
    throw new Error(
      `Storage deletion failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
