/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

export interface FairnessSeed {
  id: number;
  userId: number;
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  hash: string;
}
