#!/bin/bash
# ==============================================================================
# CLOUTSCAPE CASINO - Cloudflare Tunnel Launcher
# ==============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PORT=${PORT:-8080}
TUNNEL_NAME=${CLOUDFLARE_TUNNEL_NAME:-"cloutscape"}

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}   CLOUDFLARE TUNNEL SETUP${NC}"
echo -e "${BLUE}=====================================${NC}"

# Check if cloudflared is installed
if ! command -v cloudflared &> /dev/null; then
    echo -e "${YELLOW}Cloudflared not found. Installing...${NC}"
    
    # Detect OS and install
    if [ -f /etc/debian_version ]; then
        # Debian/Ubuntu
        curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o cloudflared.deb
        sudo dpkg -i cloudflared.deb
        rm cloudflared.deb
    elif [ -f /etc/redhat-release ]; then
        # RHEL/CentOS/Fedora
        curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.rpm -o cloudflared.rpm
        sudo rpm -i cloudflared.rpm
        rm cloudflared.rpm
    else
        echo -e "${RED}Unsupported OS. Please install cloudflared manually:${NC}"
        echo -e "${BLUE}https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/installation/${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}✓ Cloudflared installed${NC}"

# Check if logged in
if ! cloudflared tunnel list &> /dev/null; then
    echo -e "${YELLOW}Not logged in to Cloudflare. Running login...${NC}"
    cloudflared tunnel login
fi

# Check if tunnel exists, create if not
if ! cloudflared tunnel list | grep -q "$TUNNEL_NAME"; then
    echo -e "${BLUE}Creating tunnel: $TUNNEL_NAME${NC}"
    cloudflared tunnel create $TUNNEL_NAME
fi

TUNNEL_ID=$(cloudflared tunnel list | grep "$TUNNEL_NAME" | awk '{print $1}')
echo -e "${GREEN}✓ Tunnel ID: $TUNNEL_ID${NC}"

# Create/update config
mkdir -p ~/.cloudflared
cat > ~/.cloudflared/config.yml << EOF
tunnel: $TUNNEL_ID
credentials-file: ~/.cloudflared/${TUNNEL_ID}.json

ingress:
  - hostname: cloutscape.org
    service: http://localhost:$PORT
  - hostname: "*.cloutscape.org"
    service: http://localhost:$PORT
  - service: http_status:404
EOF

echo -e "${GREEN}✓ Config file created${NC}"

# Show DNS setup instructions
echo -e "${YELLOW}=====================================${NC}"
echo -e "${YELLOW}DNS SETUP REQUIRED:${NC}"
echo -e "${YELLOW}=====================================${NC}"
echo -e "Run this command to setup DNS:"
echo -e "${BLUE}cloudflared tunnel route dns $TUNNEL_NAME cloutscape.org${NC}"
echo ""

# Start tunnel
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}   Starting Cloudflare Tunnel...${NC}"
echo -e "${GREEN}   Exposing localhost:$PORT${NC}"
echo -e "${GREEN}   Domain: https://cloutscape.org${NC}"
echo -e "${GREEN}=====================================${NC}"

cloudflared tunnel run $TUNNEL_NAME
