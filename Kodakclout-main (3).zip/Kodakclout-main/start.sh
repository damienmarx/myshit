#!/bin/bash
# ==============================================================================
# CLOUTSCAPE CASINO - Local Deployment Script
# ==============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}   CLOUTSCAPE CASINO LAUNCHER${NC}"
echo -e "${BLUE}=====================================${NC}"

# Check for required tools
command -v node >/dev/null 2>&1 || { echo -e "${RED}Node.js is required but not installed.${NC}" >&2; exit 1; }
command -v pnpm >/dev/null 2>&1 || { echo -e "${YELLOW}Installing pnpm...${NC}"; npm install -g pnpm; }
command -v mysql >/dev/null 2>&1 || echo -e "${YELLOW}Warning: MySQL client not found. Database commands may fail.${NC}"

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
    echo -e "${GREEN}✓ Environment variables loaded${NC}"
else
    echo -e "${RED}Error: .env file not found. Please create one from .env.example${NC}"
    exit 1
fi

# Install dependencies
echo -e "${BLUE}Installing dependencies...${NC}"
pnpm install

# Run database migrations
echo -e "${BLUE}Running database migrations...${NC}"
if [ ! -z "$DATABASE_URL" ]; then
    pnpm db:push 2>/dev/null || echo -e "${YELLOW}Warning: Database migration skipped (check DATABASE_URL)${NC}"
else
    echo -e "${YELLOW}Warning: DATABASE_URL not set, skipping migrations${NC}"
fi

# Build for production
if [ "$NODE_ENV" = "production" ]; then
    echo -e "${BLUE}Building for production...${NC}"
    pnpm build
fi

# Start the server
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}   Starting Cloutscape Casino...${NC}"
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}   Local: http://localhost:${PORT:-8080}${NC}"
echo -e "${GREEN}=====================================${NC}"

if [ "$NODE_ENV" = "production" ]; then
    pnpm start
else
    pnpm dev
fi
